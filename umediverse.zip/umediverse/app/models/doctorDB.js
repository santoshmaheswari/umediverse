// load the things we need
var mongoose = require('mongoose');
var bcrypt   = require('bcrypt-nodejs');

// define the schema for patie
var doctorSchema = mongoose.Schema({

    did : {type : String},
    isActive : Boolean,
    name : { fname : {type : String, required : true},
                     mname : {type : String, required : true},
                     lname : {type : String, required : true}},
    username : {type : String, lowercase : true, unique : true},
    password : String,
    bod : Date,
    qualification : [String],
    category : [String],
    marital_status : String,
    gender : String,
    blood_group : String,
    p_contact : [Number],
    o_contact : [Number],
    email : String,
    url : {type : String, match : /^http:\/\//i},
    add : { street : String,
                 l_mark : String,
                 city : String,
                 pincode : Number,
                 taluka : String,
                 dist : String,
                 state : String,
                 country : String
               },
    img : {type : String, match : /^http:\/\//i},
    achivements : [String],
    treatment : {
                  co : [{name : String, additional : [String]}],
                  examination : [{name : String,status : [String]}],
                  history : {
                              family : [String],
                              personal : [String]
                            },
                  report : [String],
                  dignosis : [String],
                  advise : [String],
                  medicine : [String]
                },
    hospital : [String],
    dir_name: String,
    last_login : Date
  },
{
  collection : 'Doctor_Data'
});

// methods ======================
// generating a hash
doctorSchema.methods.generateHash = function(password) {
    return bcrypt.hashSync(password, bcrypt.genSaltSync(8), null);
};

// checking if password is valid
doctorSchema.methods.validPassword = function(password) {
    return bcrypt.compareSync(password, this.password);
};

// create the model for users and expose it to our app
module.exports = mongoose.model('Doctordata', doctorSchema);
