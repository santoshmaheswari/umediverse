// load the things we need
var mongoose = require('mongoose');
var bcrypt   = require('bcrypt-nodejs');
// define the schema for patie
var hospitalSchema = mongoose.Schema({

    hid : {type : String},
    isActive : Boolean,
    name : {type : String, required : true},
    username : {type : String, lowercase : true, unique : true},
    password : String,
    paramlink : String,
    Trust : String,
    est_date : Date,
    category : [String],
    description : String,
    url : {type : String, match : /^http:\/\//i},
    contact : [Number],
    e_contact : [Number],
    fax : [Number],
    email : String,
    add : { street : String,
                 l_mark : String,
                 city : String,
                 pincode : Number,
                 taluka : String,
                 dist : String,
                 state : String,
                 country : String
               },
    location : {x : Number,y : Number},
    title : String,
    logo : {type : String, match : /^http:\/\//i},
    galary : [{type : String, match : /^http:\/\//i}],
    type : String,
    achivements : [String],
    doctor : [{
                _id : String,
                name : { fname : {type : String, required : true},
                                 mname : {type : String, required : true},
                                 lname : {type : String, required : true}},
                doj : Date,
                dol : Date,
                salary : Number,
                designation : String,
                is_present : Boolean,
                special_fees : Number,
                shift : [{start : String,end: String,session:String,day:[String],patient_count : Number}]

            }],
    staff : [{_id : String,
              doj : Date,
              dol : Date,
              salary : Number,
              designation : String,
              is_present : Boolean,
              days : [String],
              shift : [{Start : String,End: String,shift:String,day:[String]}]
            }],
    case_fees : {
                new : Number,
                old : Number,
                emergency : Number,
                special : Number
    },
    rooms : [{room_cat : String,
              room_no : [String],
              total_bed : Number,
              bed_no : [Number],
              fees : Number,
              facility : [String]
            }],
    auth : [
      {staff_id : String,
        username : {type : String, lowercase : true, unique : true, sparse: true},
      password : String,
      role : String,
      last_login : Date}
    ],
    dir_name: String,
    formula : String,
    resetPasswordToken : String,
    resetPasswordExpires : Date,
    last_login : Date

},
{
  collection : 'Hospital_Data'
});
// methods ======================
// generating a hash
hospitalSchema.methods.generateHash = function(password) {
    return bcrypt.hashSync(password, bcrypt.genSaltSync(8), null);
};

// checking if password is valid
hospitalSchema.methods.validPassword = function(password) {
    return bcrypt.compareSync(password, this.password);
};

// checking if password is valid
hospitalSchema.methods.validStaffPassword = function(user,password) {

    return bcrypt.compareSync(password, user.auth.password);
};


// create the model for users and expose it to our app
module.exports = mongoose.model('Hospitaldata', hospitalSchema);
