// load the things we need
var mongoose = require('mongoose');
var bcrypt   = require('bcrypt-nodejs');
// define the schema for patie
var laboratorySchema = mongoose.Schema({

    lid : {type : String, lowercase : true},
    isActive : Boolean,
    name : {type : String, required : true},
    username : {type : String, lowercase : true, unique : true},
    password : String,
    type : String,
    description : String,
    est_date : Date,
    category : [String],
    investigation_list : [{
                            name : String,
                            fees : Number
                        }],
    emergency_fees : Number,
    contact : [Number],
    fax : [Number],
    email : String,
    add : { street : String,
                 l_mark : String,
                 city : String,
                 pincode : Number,
                 taluka : String,
                 dist : String,
                 state : String,
                 country : String
               },
    location : {x : Number,y : Number},
    title : String,
    logo : {type : String, match : /^http:\/\//i},
    dir_name: {type : String, match : /^http:\/\//i},
    hospital : String,
    last_login : Date
  },
  {
    collection : 'Laboratory_Data'
  }
);
// methods ======================
// generating a hash
laboratorySchema.methods.generateHash = function(password) {
    return bcrypt.hashSync(password, bcrypt.genSaltSync(8), null);
};

// checking if password is valid
laboratorySchema.methods.validPassword = function(password) {
    return bcrypt.compareSync(password, this.password);
};

// create the model for users and expose it to our app
module.exports = mongoose.model('Laboratorydata', laboratorySchema);
