// load the things we need
var mongoose = require('mongoose');
var bcrypt   = require('bcrypt-nodejs');
// define the schema for patient

var patientSchema = mongoose.Schema({

    //_id : {type : String, lowercase : true},

    name : { fname : {type : String, required : true},
                     mname : {type : String, required : true},
                     lname : {type : String, required : true}},
    username : {type : String, lowercase : true, unique : true,index:true},
    isActive : Boolean,
    adhar : Number,
    password : String,
    bod : Date,
    gender : String,
    marital_status : String,
    blood_group : String,
    contact : {type : Number, unique : true,sparse: true},
    email : String,
    weight : Number,
    height : Number,
    occupation : String,
    income : Number,
    history : {
                past : [{name : String, duration : Number}],
                family : [{name : String, relation : String, duration : Number}],
                drug : [{name : String, duration : Number}],
                personal : [{name : String, status : String ,duration : Number}]
              },
    add : { street : String,
                 l_mark : String,
                 city : String,
                 pincode : Number,
                 taluka : String,
                 dist : String,
                 state : String,
                 country : String
               },
    img : {type : String,match : /^http:\/\//i},
    emergency : {
                  ename : String,
                  contact : Number,
                  relation : String
                },
   case_detail : [{
                    doctor_id : String,
                    hospital_id : String,
                    visit_detail : [{
                                  visit_no : Number,
                                  app_id : String,
                                  app_date : Date,
                                  applydate : {type: Date, default: Date.now},
                                  case_type : String,
                                  case_fees : Number,
                                  treatment : {  co : [{name : String,duration : Number,additional : [String]}],
                                                examination : [{name : String,status : [String]}],
                                                report : [{name : String,
                                                           img :{type : String,match : /^http:\/\//i},
                                                            laboratory_id : String,
                                                            laboratory_name : String,
                                                            fees : Number,
                                                            date : Date
                                                          }],
                                                dignosis : [String],
                                                advise : [String],
                                                medicine : [{name : String,time : [String],food : String,days : Number}],
                                                comment : [String]
                                            },
                                  next_visit : Date,
                                  is_visited : String
                                  }],
                    status : String
                  }],
      dir_name: String,
      resetPasswordToken : String,
      resetPasswordExpires : Date,
      last_login : Date

},
{
  collection : 'Patient_Data'
});
// methods ======================
// generating a hash
patientSchema.methods.generateHash = function(password) {
    return bcrypt.hashSync(password, bcrypt.genSaltSync(8), null);
};

// checking if password is valid
patientSchema.methods.validPassword = function(password) {
    return bcrypt.compareSync(password, this.password);
};

patientSchema.virtual('fullname').get(function() {
    return this.name.fname + ' ' + this.name.mname + ' ' + this.name.lname;
});

// create the model for patient and expose it to our app
module.exports = mongoose.model('Patientdata', patientSchema);
patientSchema.index({'case_detail._id':1,_id:1});
mongoose.set('debug',true);
