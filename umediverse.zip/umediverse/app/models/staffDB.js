
var mongoose = require('mongoose');
var bcrypt   = require('bcrypt-nodejs');
// define the schema for patie
var staffSchema = mongoose.Schema({

      //  _id : {type : String, lowercase : true},
        name : { fname : {type : String, required : true},
                 mname : {type : String, required : true},
                 lname : {type : String, required : true}},
          dob : Date,
          qualification : [String],
          gender : String,
          marital_status : String,
          blood_group : String,
          contact : [Number],
          email : String,
          add : { street : String,
                  l_mark : String,
                  city : String,
                  pincode : Number,
                  taluka : String,
                  dist : String,
                  state : String,
                  country : String
                },
          img : {type : String, match : /^http:\/\//i},
          reference : {
                        name : String,
                        contact : Number,
                        relation : String
                      },
          hospital_id : String,
          dir_name: String

      },
      {
      collection : 'staff_Data'
      });
      // methods ======================
      // generating a hash
      staffSchema.methods.generateHash = function(password) {
          return bcrypt.hashSync(password, bcrypt.genSaltSync(8), null);
      };

      // checking if password is valid
      staffSchema.methods.validPassword = function(password) {
          return bcrypt.compareSync(password, this.local.password);
      };

      // create the model for users and expose it to our app
      module.exports = mongoose.model('Staffdata', staffSchema);
