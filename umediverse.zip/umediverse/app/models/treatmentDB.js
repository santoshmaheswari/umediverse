// load the things we need
var mongoose = require('mongoose');

// define the schema for treatment
var treatmentSchema = mongoose.Schema({
    //_id : {type : String, lowercase : true},
    category : String,
    treatment : {
                  co : [{name : String}],
                  examination : [{name : String,status : [String]}],
                  history : {
                              family : [String],
                              personal : [String]
                            },
                  report : [String],
                  dignosis : [String],
                  advise : [String],
                }
  },
{
  collection : 'Treatment_Data'
});
// create the model for users and expose it to our app
module.exports = mongoose.model('Treatmentdata', treatmentSchema);
