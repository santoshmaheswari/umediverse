
var Auth = require('./auth');
var tc = require('./hub');

module.exports = function(router){
//localhost:8000/patient
    var Admindata            = require('../models/admin');
    var Hospitaldata            = require('../models/hospitalDB');
    var Pharmacydata            = require('../models/pharmacyDB');
    var Doctordata            = require('../models/doctorDB');
    var Laboratorydata            = require('../models/laboratoryDB');


    router.get('/all',function(req,res){
        //res.render('Patient_Registration.html');
            Admindata.find(function(err, data) {
                    if (err)
                        res.send(err);

                    res.json(data);
                });
    });

    router.post('/registration',function(req, res) {
      try {
        var admindata  = new Admindata();
            //patientdata._id
            admindata.username = req.body.AUName;
            admindata.password =  admindata.generateHash(req.body.APass);
              admindata.role = req.body.ARole;
                        admindata.save(function(err) {
                if (err)
                    {res.send(err);}
                res.redirect('/login');

            });
          } catch (e) {
                tc.try_catch(e,res);
          }
    });

    router.post('/change_password',Auth.loginAdmin,function(req,res){
        try {
              var admindata  = new Admindata();
                        Admindata.findOne({"_id" : req.session.user._id},function(err, user) {
                                      if (err)
                                            res.send(err);
                                        if (!user.validPassword(req.body.CPassword))
                                        {
                                          res.json({       'status': 500,
                                                          'error': 'Incorrect Password Entered'
                                                      });
                                        }
                                        else {

                                          Admindata.update({"_id" : req.session.user._id},{$set : {'password' : admindata.generateHash(req.body.NPassword)}},
                                                                                                    function(err, data) {
                                                                                                              if (err)
                                                                                                              {res.send(err);}
                                                                                                              else {
                                                                                                                res.json({       'status': 200,
                                                                                                                                'error': 'Password successfully Changed...',
                                                                                                                                'user_data': {}
                                                                                                                            });
                                                                                                            }

                                                  });

                                        }
                                        //res.json(data);
                                    });
                } catch (e) {
                              tc.try_catch(e,res);
                }
    });

    router.get('/session',function(req, res) {
        try {
                if(!req.session.role)
                {
                  req.session.role = "";
                }
                var hid="";
                var pid="";
                var lid="";

                var data =[{logo:"/logo/logo.jpg",title:"UMediverse Care"}];

                if(req.session.role === "Doctor")
                {
                  hid = req.session.hid;
                }
                else if(req.session.role === "Hospital")
                {
                  hid = req.session.user.hid;
                }
                else if(req.session.role === "Staff")
                {
                  hid = req.session.user[0].hid;
                }
                else if(req.session.role === "Pharmacy")
                {
                  pid = req.session.user.pid;
                }
                else if(req.session.role === "Laboratory")
                {
                  lid = req.session.user.lid;
                }

            if(hid)
            {
              Hospitaldata.find({hid:hid},{_id:0,logo:1,title:1,formula:1,last_login:1},function(err, data) {
                        if (err)
                        {
                          res.send(err);
                        }
                        else {
                                if(data[0].formula==='Clinic')
                                {

                                  Doctordata.find({"hospital":req.session.user._id},{_id:0,did:1,name:1,img:1},function(err, drdata) {
                                            if (err)
                                            {
                                              res.send(err);
                                            }
                                            else if(drdata != ""){
                                              req.session.hid = req.session.user.hid;
                                              req.session.user.did = drdata[0].did;

                                              res.json({
                                                        'session': req.session.role,
                                                        'user_data': data,
                                                        'dr_data' : drdata
                                              });
                                            }
                                            else {
                                              res.json({
                                                        'session': req.session.role,
                                                        'user_data': data
                                              });
                                            }

                                  })
                                }
                                else {
                                  res.json({
                                            'session': req.session.role,
                                            'user_data': data
                                  });
                                }

                          }
                });
              }
              else if(pid){
                Pharmacydata.find({pid:pid},{_id:0,logo:1,title:1,last_login:1},function(err, data) {

                          if (err)
                          {
                            res.send(err);
                          }
                          else {

                            res.json({    'session': req.session.role,
                                          'user_data': data
                                });
                          }
                  });
              }
              else if(lid){
                Laboratorydata.find({lid:lid},{_id:0,logo:1,title:1,last_login:1},function(err, data) {

                          if (err)
                          {
                            res.send(err);
                          }
                          else {

                            res.json({    'session': req.session.role,
                                          'user_data': data
                                });
                          }
                  });
              }
              else {
                          res.json({    'session': req.session.role,
                                        'user_data': data
                                  });
                      }

                    } catch (e) {
                                  tc.try_catch(e,res);
                    }
        });


}
