var Auth = require('./auth');
var mongoose = require('mongoose');
var tc = require('./hub');

module.exports = function(router){
//localhost:8000/appointment
    var Patientdata            = require('../models/patientDB');
    var Hospitaldata            = require('../models/hospitalDB');

    router.get('/fees',Auth.DoctorStaff,function(req,res){
        try{
              var hid;

              if(req.session.hid)
                {
                  hid = req.session.hid;
                }
              else if(req.session.user[0].hid) {
                hid = req.session.user[0].hid;
              }
                          Hospitaldata.find({"hid" : hid},{_id : 0,case_fees : 1},function(err, data) {
                            if (err){
                                res.send(err);}

                                res.json({'status':200,'data':data});

                        });
          } catch (e) {
              tc.try_catch(e,res);
          }

    });
    router.post('/',Auth.DoctorStaff,function(req,res){
      try{


              var did,hid;
              if(req.session.user.did)
              {
                did = req.session.user.did;
                hid = req.session.hid;
              }
              else if(req.body.did) {
                did = req.body.did;
                hid = req.session.user[0].hid;
              }
                      if(req.body.acaseT === "New" || req.body.acaseT === "Emergency")
                      {

                       Patientdata.update({"_id" : req.body.pid},{$addToSet : {"case_detail" : { "visit_detail" :
                                                                                                     {"visit_no" : 1,
                                                                                                       "app_date" : req.body.adate,
                                                                                                     "case_type" : req.body.acaseT,
                                                                                                     "case_fees" : req.body.Fees,
                                                                                                     "is_visited" : "No"
                                                                                                     },
                                                                                                  "doctor_id":did,
                                                                                                  "hospital_id":hid}

                                                                                 }
                                                                               },function(err, data) {
                                                                                  if (err){
                                                                                  res.send(err);}

                                                                                  else {

                                                                                              res.json({       'status': 200,
                                                                                                    'error': 'Appointment Submitted...',
                                                                                                    'user_data': {}
                                                                                                });
                                                                                  }
                                                                                });
                        }
                        else if(req.body.acaseT === "Old")
                        {
                            id = mongoose.Types.ObjectId(req.body.pid);
                          Patientdata.aggregate( [{ $match: {_id : id}},
                                                    {$project : {_id : 0,case_detail:1}},
                                                  { $unwind: "$case_detail" },
                                                  { $match: { "case_detail.doctor_id":did,"case_detail.hospital_id":hid,$or : [{"case_detail.visit_detail.case_type" : "New"},{"case_detail.visit_detail.case_type" : "Old"}]}},
                                                  { $sort: {"case_detail.visit_detail.app_date": -1 }},
                                                  {$limit : 1}],
                                                function(err, data) {
                                                   if (err){
                                                    res.send(err);
                                                  }
                                                  else {
                                                      if(data != "")
                                                      {
                                                        data.forEach(function(d)
                                                        {
                                                          Patientdata.update({"_id" : req.body.pid,"case_detail._id" : d.case_detail._id},{$push : {"case_detail.$.visit_detail" :
                                                                                                                                      { $each : [{
                                                                                                                                        "app_date" : req.body.adate,
                                                                                                                                        "case_type" : req.body.acaseT,
                                                                                                                                      "case_fees" : req.body.Fees,
                                                                                                                                      "is_visited" : "No"}],
                                                                                                                                        $position: 0
                                                                                                                                      }
                                                                                                                                      }
                                                                                                                                   },{ upsert: true }


                                                                                                                ,function(err, data) {
                                                                                                                   if (err){
                                                                                                                   res.send(err);}
                                                                                                                   else {
                                                                                                                     res.json({       'status': 200,
                                                                                                                                     'error': 'Appointment Submitted...',
                                                                                                                                     'user_data': {}
                                                                                                                                 });
                                                                                                                   }
                                                                                                               });
                                                      })
                                                    }
                                                    else {
                                                      res.json({       'status': 500,
                                                                      'error': 'Old Appointment not available...',
                                                                      'user_data': {}
                                                                  });
                                                    }
                                                 }}
                                              );
                       }
            } catch (e) {
                 tc.try_catch(e,res);
            }

      });

          router.post('/data',function(req,res){
            try{

                Patientdata.find({"_id" : req.body.pid},{_id:1,name:1,add:1,img:1,bod:1,gender:1},function(err, data) {
                          if (err)
                              res.send(err);

                              res.json({'status':200,'data':data});

                      });

                    } catch (e) {
                        tc.try_catch(e,res);

                    }
                });
}
