/**
 * Admin Login
 */
module.exports.loginAdmin = function (req, res, next) {

   if (req.session.role === 'Admin') return next();

       res.redirect('/login');
}

/**
 * Patient Login
 */

module.exports.loginPatient = function (req, res, next) {

  if (req.session.role === 'Patient') return next();

      res.redirect('/');
}

/**
 * Doctor Login
 */

module.exports.loginDoctor = function (req, res, next) {

  if (req.session.role === 'Doctor' || req.session.user.formula === 'Clinic' ) return next();

      res.redirect('/');
}


/**
 * Hospital Login
 */

module.exports.loginHospital = function (req, res, next) {

   if (req.session.role === 'Hospital') return next();

       res.redirect('/');
}

/**
 * pharmacy Login
 */

module.exports.loginPharmacy = function (req, res, next) {

   if (req.session.role === 'Pharmacy') return next();

       res.redirect('/');
}

/**
 * Staff Login
 */

module.exports.loginStaff = function (req, res, next) {

   if (req.session.role === 'Staff') return next();

       res.redirect('/');
}

/**
 * Laboratory Login
 */

module.exports.loginLaboratory = function (req, res, next) {

   if (req.session.role === 'Laboratory') return next();

       res.redirect('/');
}

/**
 * Appointment Login
 */

module.exports.HospitalStaff = function (req, res, next) {

   if (req.session.role === 'Hospital' || req.session.role === 'Staff') return next();

       res.redirect('/');
}

module.exports.DoctorStaff = function (req, res, next) {

   if (req.session.role === 'Doctor' || req.session.role === 'Staff' || req.session.user.formula === 'Clinic') return next();

       res.redirect('/');
}

module.exports.Patientpharmacy = function (req, res, next) {

   if (req.session.role === 'Patient' || req.session.role === 'Pharmacy') return next();

       res.redirect('/');
}
module.exports.PatientPharmacyLaboratory = function (req, res, next) {

   if (req.session.role === 'Patient' || req.session.role === 'Pharmacy' || req.session.role === 'Laboratory') return next();

       res.redirect('/');
}

module.exports.HospitalAdmin = function (req, res, next) {

   if (req.session.role === 'Hospital' || req.session.role === 'Admin') return next();

       res.redirect('/');
}
