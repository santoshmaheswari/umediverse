var Auth = require('./auth');
var mongoose = require('mongoose');
var mkDir = require('./mkdir');
var formidable = require('formidable');
var fs = require('fs');
var tc = require('./hub');

module.exports = function(router){
//localhost:8000/doctor
    var Doctordata            = require('../models/doctorDB');
    var Hospitaldata            = require('../models/hospitalDB');
    var Patientdata            = require('../models/patientDB');

  router.get('/all',function(req,res){
    try{
            Doctordata.find(function(err, data) {
                    if (err)
                        res.send(err);

                        res.json({'status':200,'data':data});
                    });
              } catch (e) {
                  tc.try_catch(e,res);
                }
              });

    router.get('/data',Auth.loginDoctor,function(req,res){
    try{
            Doctordata.find({"did" : req.session.user.did},{_id:0,password:0,hospital:0},function(err, data) {
                    if (err)
                        res.send(err);
                        res.json({'status':200,'data':data});
                    });
              } catch (e) {
                  tc.try_catch(e,res);
                }
    });

    router.get('/treatment',Auth.loginDoctor,function(req,res){
      try{
            Doctordata.find({"did" : req.session.user.did},{_id : 0,treatment : 1},function(err, data) {
                    if (err)
                        res.send(err);
                        res.json({'status':200,'data':data});
                    });
              } catch (e) {
                  tc.try_catch(e,res);
                }

    });

    router.get('/hospital',Auth.loginDoctor,function(req,res){
      try{
            var HID = req.session.user.hospital;

                  Hospitaldata.find({"_id" : {$in:HID}},{_id : 0,hid : 1,title : 1,logo : 1},function(err, data) {
                          if (err){
                              res.send(err);}
                              res.json({'status':200,'data':data});
                          });
                    } catch (e) {
                        tc.try_catch(e,res);
                      }    });

    router.post('/case_history/data/',Auth.PatientPharmacyLaboratory,function(req,res){
      try{

            Doctordata.find({"did" : {$in:req.body.did}},{_id : 0,name : 1,add : 1,o_contact : 1,did:1},function(err, data) {
                    if (err){
                        res.send(err);}
                        res.json({'status':200,'data':data});
                    });
              } catch (e) {
                  tc.try_catch(e,res);
                }
    });

    router.post('/hospital/data/',Auth.loginHospital,function(req,res){
      try{

            Doctordata.find({"did" : {$in:req.body.did}},{_id : 0,name : 1,did:1,img:1,email:1,o_contact:1},function(err, data) {
                    if (err){
                        res.send(err);}
                        res.json({'status':200,'data':data});
                    });
              } catch (e) {
                  tc.try_catch(e,res);
                }
    });

    router.get('/case_report',Auth.loginDoctor,function(req,res){
      try{

          var yesterday = new Date();
          yesterday.setDate(yesterday.getDate()-1);
          yesterday.setHours(0,0,0,0);
          var tomorrow = new Date();
          tomorrow.setDate(tomorrow.getDate()+1);
          tomorrow.setHours(0,0,0,1);
          var did=req.session.user.did;
          var hid=req.session.hid;
          Patientdata.aggregate( [{ $match: {"case_detail.doctor_id" : did,"case_detail.hospital_id" : hid}},
                                    {$project : {_id : 0,case_detail:1,name:1,gender : 1}},
                                  { $unwind: "$case_detail" },
                                  { $unwind: { path: "$case_detail.visit_detail", includeArrayIndex: "Index" }},
                                  {$project : {_id : 0, "case_detail.visit_detail.app_date":1,"case_detail.doctor_id":1,"case_detail.hospital_id":1,"case_detail.visit_detail._id":1,"case_detail.visit_detail.case_type":1,"case_detail.visit_detail.is_visited":1,name:1,gender : 1}},
                                  { $match:{$and :[ { "case_detail.visit_detail.app_date" :{"$gt":yesterday,"$lt":tomorrow}},{"case_detail.doctor_id":did},{"case_detail.hospital_id":hid}]}},
                                  {$sort:{"case_detail.visit_detail.app_date":1}}
                                ],function(err, data) {
                                   if (err){
                                    res.send(err);}

                                    res.json({'status':200,'data':data});
                                });
                          } catch (e) {
                              tc.try_catch(e,res);
                            }
    });

    router.get('/patient/:id',Auth.loginDoctor,function(req,res){
      try{
            id = mongoose.Types.ObjectId(req.params.id);
            Patientdata.aggregate( [{ $match: {"case_detail.doctor_id" : req.session.user.did,"case_detail.hospital_id" : req.session.hid,"case_detail.visit_detail._id" : id}},
                                      {$project : {_id : 0,name:1,case_detail:1,bod : 1,
                                                    gender : 1, blood_group : 1,contact : 1, email : 1,
                                                    weight : 1, height : 1,occupation : 1,   income : 1,
                                                    history :1,add:1,img:1,emergency:1 }},
                                    { $unwind: "$case_detail" },
                                    //{ $unwind:  { path:"$case_detail.visit_detail", includeArrayIndex: "Index" }},
                                    { $match: { "case_detail.visit_detail._id" : id}}
                                  ],function(err, data) {
                                     if (err){
                                      res.send(err);}
                                      else {

                                        res.json({       'status': 200,
                                                        'error': 'Data',
                                                        'data': data
                                                    });
                                      }
                                    });
            } catch (e) {
                    tc.try_catch(e,res);
            }    });

    router.get('/patient/investigation/data',Auth.loginDoctor,function(req,res){
      try{

              Patientdata.aggregate( [{ $match: {"case_detail":{$elemMatch:{"doctor_id":req.session.user.did,"hospital_id": req.session.hid}}}},
                                        {$project : {name:1,case_detail:1,img:1,dir_name:1}},
                                        { $unwind: "$case_detail" },
                                        { $unwind:  "$case_detail.visit_detail"},
                                        {$project : {name:1,dir_name:1,"case_detail.doctor_id":1,"case_detail.hospital_id":1,"case_detail._id":1,"case_detail.visit_detail._id":1,"case_detail.visit_detail.app_date":1,"case_detail.visit_detail.treatment.report":1,img:1}},
                                        { $match: {$and :[{"case_detail.visit_detail.treatment.report" :{$ne:[]}},{"case_detail.visit_detail.treatment.report.img" :null},{"case_detail.visit_detail.treatment.report._id" :{ $exists: true}},
                                                          {"case_detail.doctor_id":req.session.user.did},{"case_detail.hospital_id": req.session.hid}]}},
                                    ],function(err, data) {
                                       if (err){
                                        res.send(err);}
                                        else {


                                          res.json({       'status': 200,
                                                          'error': 'Data',
                                                          'data': data
                                                      });
                                        }


                                      });
              } catch (e) {
                    tc.try_catch(e,res);
              }

    });

    router.post('/patient/investigation/upload',Auth.loginDoctor,function(req,res){
      try{
            var form = new formidable.IncomingForm();
            form.uploadDir = 'views/upload/';

            form.parse(req,function(err, fields, files) {

                files['img'].name = fields.PInv + '.' + files['img'].name.split('.')[files['img'].name.split('.').length -1];
                location = fields.dir_name + "/" + files['img'].name;
                fs.rename(files['img'].path, location);
                location = dir+'/upload/patient/' + fields['dir_name'].split('/')[fields['dir_name'].split('/').length -2] + "/" + fields.id + "/" + files['img'].name;
                fields.img = location;
                /*Patientdata.update({"_id" : fields.id,"case_detail._id" : fields.case,"case_detail.visit_detail._id" : fields.visit,"case_detail.visit_detail.treatment.report._id" : fields.PInv},{$set : {"case_detail.$0.visit_detail.$1.treatment.report.$2.img" : fields.img
                   }},function(err, data) {
                                                                                if (err){
                                                                                res.send(err);
                                                                              }
                                                                                else {

                                                                                                res.json({       'status': 200,
                                                                                                'error': 'File Uploaded...',
                                                                                                'user_data': {}
                                                                                            });
                                                                                          }
                      });*/
                     Patientdata.findById(fields.id,function(err,data){
                        if(err)
                        {
                          res.send(err);
                        }
                        else {
                          var t = data.case_detail.id(fields.case).visit_detail.id(fields.visit).treatment.report.id(fields.PInv);
                          t.laboratory_name = fields.LabName;
                          t.laboratory_id = fields.LabId;
                          t.img = fields.img;
                          data.save();
                          res.json({       'status': 200,
                                          'error':'successfully Uploaded!!!!',
                                          'user_data': {}
                                      });
                        }


                      })
                  });
          } catch (e) {
                    tc.try_catch(e,res);
          }

      });


    router.post('/case_report/bydate',Auth.loginDoctor,function(req,res){
      try{


            var startDate = new Date(req.body.DRSD);
            startDate.setHours(0,0,0,1);
            var endDate = new Date(req.body.DRED);
            endDate.setHours(0,0,0,0);


            Patientdata.aggregate( [{ $match: {"case_detail.doctor_id" : req.session.user.did,"case_detail.hospital_id" : req.session.hid}},
                                      {$project : {_id : 0,case_detail:1,name:1,gender : 1,"add.city":1}},
                                    { $unwind: "$case_detail" },
                                    { $unwind: { path: "$case_detail.visit_detail", includeArrayIndex: "Index" }},
                                    {$project : {_id : 0,"add.city":1,"case_detail.doctor_id":1,"case_detail.hospital_id":1,"case_detail.visit_detail.app_date":1,"case_detail.visit_detail._id":1,"case_detail.visit_detail.case_type":1,"case_detail.visit_detail.is_visited":1,name:1,gender : 1}},
                                    { $match: {$and :[ { "case_detail.visit_detail.app_date" :{"$gte":startDate,"$lte":endDate}},{"case_detail.doctor_id":req.session.user.did},{"case_detail.hospital_id": req.session.hid}]}},
                                    {$sort:{"case_detail.visit_detail.app_date":1}}
                                  ],function(err, data) {
                                     if (err){
                                      res.send(err);}


                                      res.json({'status':200,'data':data});
                                  });
        } catch (e) {
              tc.try_catch(e,res);
        }
    });

    router.get('/approve/:d_id',Auth.loginHospital,function(req,res){
      try{
              Hospitaldata.aggregate( [{ $match: {"hid" : req.session.user.hid}},
                                        {$project : {_id : 0,doctor:1}},
                                      { $unwind: "$doctor" },
                                      { $match: {$and : [{"doctor._id" : req.params.d_id},{"doctor.is_present" : true}]}}

                                    ],function(err, data) {
                                       if (err){
                                        res.send(err);}

                                        if(data != "")
                                        {
                                          res.json({       'status': 500,
                                                          'error': 'Doctor Already Registered',
                                                          'user_data': {}
                                                      });
                                        }
                                        else {
                                          Doctordata.find({"did" : req.params.d_id},{_id : 0,img:1,name : 1,did : 1},function(err, data) {
                                                  if (err)
                                                      {res.send(err);}

                                                  res.json({'status':200,'data':data});
                                          });
                                        }
                                      });



            } catch (e) {
                  tc.try_catch(e,res);
            }

    });

    router.get('/hospital/s/:hid',Auth.loginDoctor,function(req,res){
      try{
            req.session.hid = req.params.hid;

            res.json({       'status': 200,
                            'error': 'Dashboard',
                            'user_data': {}
                        });

        } catch (e) {
              tc.try_catch(e,res);
        }
    });

    router.post('/change_password',Auth.loginDoctor,function(req,res){
      try{
          var doctordata  = new Doctordata();
                    Doctordata.findOne({"_id" : req.session.user._id},function(err, user) {
                                  if (err)
                                        res.send(err);
                                    if (!user.validPassword(req.body.CPassword))
                                    {
                                      res.json({       'status': 500,
                                                      'error': 'Incorrect Password Entered'
                                                  });
                                    }
                                    else {

                                      Doctordata.update({"_id" : req.session.user._id},{$set : {'password' : doctordata.generateHash(req.body.NPassword)}},
                                                                                                function(err, data) {
                                                                                                          if (err)
                                                                                                          {res.send(err);}
                                                                                                          else {
                                                                                                            res.json({       'status': 200,
                                                                                                                            'error': 'Password successfully Changed...',
                                                                                                                            'user_data': {}
                                                                                                                        });
                                                                                                        }

                                              });

                                    }
                                    //res.json(data);
                                });

      } catch (e) {
            tc.try_catch(e,res);
      }
    });

    router.post('/username/verify',Auth.loginHospital,function(req,res){
      try{
            var form = new formidable.IncomingForm();
            form.parse(req,function(err, fields, files) {
                      Doctordata.find({"username" : fields.DUName},{username:1,_id:0},function(err, data) {
                                    if (err)
                                          res.send(err);
                                    if(data=="")
                                    {
                                      res.json({       'status': 200,
                                                        'error': 'Available'
                                              });
                                    }
                                    else {
                                      res.json({       'status': 200,
                                                        'error': 'Already Registered'
                                              });
                                    }
                                  });
            });

      } catch (e) {
            tc.try_catch(e,res);
      }
    });

    router.post('/id/verify',Auth.loginHospital,function(req,res){
      try{
          var form = new formidable.IncomingForm();
          form.parse(req,function(err, fields, files) {
                    Doctordata.find({"did" : fields.DReg},{did:1,_id:0},function(err, data) {

                                  if (err)
                                        res.send(err);
                                        if(data=="")
                                        {
                                          res.json({       'status': 200,
                                                            'error': 'Available'
                                                  });
                                        }
                                        else {
                                          res.json({       'status': 200,
                                                            'error': 'Already Registered'
                                                  });
                                        }
                                });
          });

    } catch (e) {
          tc.try_catch(e,res);
    }
    });

    router.post('/registration',Auth.loginHospital,function(req, res) {
      try{
                  var doctordata  = new Doctordata();
                  var form = new formidable.IncomingForm();
                  var pincode;
                  form.uploadDir = 'views/upload/';
                  form.parse(req,function(err, fields, files) {
                    doctordata.did = fields["DReg"];

                    file:
                    {
                      if(!files.file)
                      {
                      break file;
                      }
                    pincode = fields["DPin"];
                    var location = 'views/upload/doctor/' + pincode;
                    mkDir.mkDir(location,res);
                    location = location  + "/" + doctordata.did;
                    fs.mkdirSync(location);
                    doctordata.dir_name = location;

                    files['file'].name = doctordata.did + '.' + files['file'].name.split('.')[files['file'].name.split('.').length -1];
                    location = location + "/" + files['file'].name;
                    fs.rename(files['file'].path, location);
                    location = dir+'/upload/doctor/' + pincode + "/" + doctordata.did + "/" + files['file'].name;
                    doctordata.img = location;
                  }
                  doctordata.name.fname = fields["DFName"];
                  doctordata.name.mname = fields["DMName"];
                  doctordata.name.lname = fields["DLName"];
                  doctordata.gender = fields["DGen"];
                  doctordata.marital_status = fields["DMrg"];
                  doctordata.username = fields["DUName"];
                  doctordata.password = doctordata.generateHash(fields["DPass"]);
                  doctordata.bod = fields["DDob"];
                  doctordata.blood_group = fields["DBG"];
                  doctordata.add.street = fields["DStreet"];
                  doctordata.add.l_mark = fields["DLand"];
                  doctordata.add.city = fields["DCity"];
                  doctordata.add.dist = fields["DDis"];
                  doctordata.add.state = fields["DState"];
                  doctordata.add.country = fields["DCoun"];
                  doctordata.add.pincode = fields["DPin"];
                  doctordata.p_contact = fields["DMob"];
                  doctordata.o_contact = fields["DOMob"];
                  doctordata.email = fields["DMail"];
                  doctordata.qualification = fields["DQua"];
                  doctordata.category = fields["DCat"];
                  doctordata.url = fields["DWeb"];
                  doctordata.achivements = fields["Dachive"];
                  doctordata.treatment.examination.push({"name":"CVS"},{"name":"RS"},{"name":"GS"},{"name":"CNS"});

                      doctordata.save(function(err) {
                          if(err){

                              res.send(err);
                            }
                            else {
                              res.json({       'status': 200,
                                                'error': 'Record Created...',
                                                'user_data': {}
                                      });
                            }
                      });

                    })

                  form.on('error', function(err) {

                      request.resume();
                  });

                  form.on('aborted', function(err) {
                    res.json({       'status': 500,
                                      'error': 'Aborted...',
                                      'user_data': {}
                            });
                  });

          } catch (e) {
                tc.try_catch(e,res);
          }

        });

        router.post('/update',Auth.loginDoctor,function(req,res){
          try{
                    var form = new formidable.IncomingForm();
                    form.uploadDir = 'views/upload/';

                    form.parse(req,function(err, fields, files) {
                      console.log("X---"+fields.img);
                      file:
                      {
                        if(fields.img)
                        {
                        break file;
                        }
                        if(!files.img)
                        {
                        fields.img = "";
                        break file;
                        }

                        pincode = fields["pincode"];
                        var location = 'views/upload/doctor/' + pincode;
                        mkDir.mkDir(location,res);
                        location = location  + "/" + req.session.user.did;
                        mkDir.mkDir(location,res);
                        files['img'].name = req.session.user.did + '.' + files['img'].name.split('.')[files['img'].name.split('.').length -1];
                        location = location + "/" + files['img'].name;
                        fs.rename(files['img'].path, location);
                        location = dir+'/upload/doctor/' + pincode + "/" + req.session.user.did + "/" + files['img'].name;
                        fields.img = location;

                      }

                             Doctordata.update({"did" : req.session.user.did},{$set : {'add.street' : fields.street,
                                                                              'add.l_mark' : fields.l_mark,
                                                                              'add.pincode' : fields.pincode,
                                                                              'add.city' : fields.city,
                                                                              'add.country' : fields.country,
                                                                              'add.state' : fields.state,
                                                                              'add.dist' : fields.dist,
                                                                              'marital_status': fields.marital_status,
                                                                              'p_contact' : fields.p_contact,
                                                                              'o_contact' : fields.o_contact,
                                                                              'email' : fields.email,
                                                                              'gender' : fields.gender,
                                                                              'bod' : fields.bod,
                                                                              'url' : fields.url,
                                                                              'qualification' : fields.qualification,
                                                                              'category' : fields.category,
                                                                              'achivements' : fields.achivements,
                                                                              'img' : fields.img
                                                                              }},function(err, data) {
                                                                                        if (err){
                                                                                        res.send(err);
                                                                                      }
                                                                                        else {
                                                                                                        res.json({       'status': 200,
                                                                                                        'error': 'Profile Updated...',
                                                                                                        'user_data': {}
                                                                                                    });
                                                                                                  }
                              });
                          });

                } catch (e) {
                      tc.try_catch(e,res);
                }
          });

          router.post('/treatment/co',Auth.loginDoctor,function(req, res) {
            try{
                    var cos = req.body.DCo;


                      var tco = new Array();
                      if(cos != null)
                      {
                      if( Object.prototype.toString.call( cos ) === '[object Array]' ) {

                        cos.forEach(function(co) {
                          if(co != '')
                          {
                              tco.push({'name' : co});
                          }
                        });

                        Doctordata.update({"did" : req.session.user.did},{$addToSet : {"treatment.co" :
                                                                                        {$each : [tco]}}},function(err, data) {
                                                                                          if (err){
                                                                                          res.send(err);}

                                                                          }
                         );
                    }
                     else {

                       Doctordata.update({"did" : req.session.user.did},{$addToSet : {"treatment.co" :

                                                                                       {'name' : cos}}},function(err, data) {
                                                                                         if (err){
                                                                                         res.send(err);}

                                                                         }
                        );
                     }
                   }
              res.redirect('/doctor/treatment_manager');

          } catch (e) {
            res.redirect('/doctor/treatment_manager');

          }
        });

        router.post('/treatment/history/family',Auth.loginDoctor,function(req, res) {
            try{

                  var hfs = req.body.DHF;

                  var thf = new Array();
                  if(hfs != null)
                  {
                  if( Object.prototype.toString.call( hfs ) === '[object Array]' ) {
                    hfs.forEach(function(hf) {
                      if(hf != '')
                      {

                   Doctordata.update({"did" : req.session.user.did},{$addToSet : {"treatment.history.family":hf }},function(err, data) {
                                                                               if (err){

                                                                               res.send(err);}

                                                                      }
                     );
                   }
                   });
                  }
                  else {
                    Doctordata.update({"did" : req.session.user.did},{$addToSet : {"treatment.history.family":hfs }},function(err, data) {
                                                                                if (err){

                                                                                res.send(err);}

                                                                       }
                      );
                  }
                }
            res.redirect('/doctor/treatment_manager');

        } catch (e) {
          res.redirect('/doctor/treatment_manager');

        }
      });

      router.post('/treatment/history/personal',Auth.loginDoctor,function(req, res) {
          try{
                var hps = req.body.DHP;
                var thp = new Array();
                if(hps != null)
                {
                if( Object.prototype.toString.call( hps ) === '[object Array]' ) {
                  hps.forEach(function(hp) {
                    if(hp != '')
                    {

                 Doctordata.update({"did" : req.session.user.did},{$addToSet : {"treatment.history.personal":hp }},function(err, data) {
                                                                             if (err){
                                                                             res.send(err);}

                                                                    }
                   );
                 }
                 });
                }
                else {
                  Doctordata.update({"did" : req.session.user.did},{$addToSet : {"treatment.history.personal":hps}},function(err, data) {
                                                                              if (err){
                                                                              res.send(err);}

                                                                     }
                    );
                }
              }
          res.redirect('/doctor/treatment_manager');
        }catch (e) {
          res.redirect('/doctor/treatment_manager');

        }
    });

          router.post('/treatment/report',Auth.loginDoctor,function(req, res) {
            try{
                  var reports = req.body.DRep;
                  var trep = new Array();
                  if(reports != null)
                  {
                  if( Object.prototype.toString.call( reports ) === '[object Array]' ) {
                    reports.forEach(function(report) {
                      if(report != '')
                      {

                   Doctordata.update({"did" : req.session.user.did},{$addToSet : {"treatment.report" : report }},function(err, data) {
                                                                               if (err){
                                                                               res.send(err);}

                                                                      }
                     );
                   }
                   });
                  }
                  else {
                    Doctordata.update({"did" : req.session.user.did},{$addToSet : {"treatment.report" : reports }},function(err, data) {
                                                                                if (err){
                                                                                res.send(err);}

                                                                       }
                      );
                  }
                }
                res.redirect('/doctor/treatment_manager');
              }
              catch (e) {
                res.redirect('/doctor/treatment_manager');

              }
          });

          router.post('/treatment/dignosis',Auth.loginDoctor,function(req, res) {
            try{
                  var dignosis = req.body.DDig;
                  if(dignosis != null)
                  {
                    if( Object.prototype.toString.call( dignosis ) === '[object Array]' ) {
                    dignosis.forEach(function(dig) {
                      if(dig != '')
                      {
                  Doctordata.update({"did" : req.session.user.did},{$addToSet : {"treatment.dignosis" : dig}},function(err, data) {
                                                                                  if (err){
                                                                                  res.send(err);}

                                                                    }
                     );
                   }
                   });
                 }
                 else {
                   Doctordata.update({"did" : req.session.user.did},{$addToSet : {"treatment.dignosis" : dignosis}},function(err, data) {
                                                                                   if (err){
                                                                                   res.send(err);}

                                                                     }
                      );
                 }
               }
               res.redirect('/doctor/treatment_manager');
             }catch (e) {
               res.redirect('/doctor/treatment_manager');

             }
          });

          router.post('/treatment/advise',Auth.loginDoctor,function(req, res) {
              try{
                        var advises = req.body.DAdv;
                        if(advises != null)
                        {
                          if( Object.prototype.toString.call( advises ) === '[object Array]' ) {
                          advises.forEach(function(advise) {
                            if(advise != '')
                            {
                        Doctordata.update({"did" : req.session.user.did},{$addToSet : {"treatment.advise" : advise}},function(err, data) {
                                                                                          if (err){
                                                                                          res.send(err);}

                                                                          }
                           );
                         }
                         });
                       }
                       else {
                         Doctordata.update({"did" : req.session.user.did},{$addToSet : {"treatment.advise" : advises}},function(err, data) {
                                                                                           if (err){
                                                                                           res.send(err);}

                                                                           }
                            );
                       }
                     }
                     res.redirect('/doctor/treatment_manager');
                }catch (e) {
                  res.redirect('/doctor/treatment_manager');

                }
       });

       router.post('/treatment/medicine/add',Auth.loginDoctor,function(req, res) {
           try{
                 var medicine = req.body.DMed;
                 if(medicine != null)
                 {
                   if( Object.prototype.toString.call( medicine ) === '[object Array]' ) {
                   medicine.forEach(function(med) {
                     if(med != '')
                     {
                 Doctordata.update({"did" : req.session.user.did},{$addToSet : {"treatment.medicine" : med}},function(err, data) {
                                                                                 if (err){
                                                                                 res.send(err);}

                                                                   }
                    );
                  }
                  });
                }
                else {
                  Doctordata.update({"did" : req.session.user.did},{$addToSet : {"treatment.medicine" : medicine}},function(err, data) {
                                                                                  if (err){
                                                                                  res.send(err);}

                                                                    }
                     );
                }
               }
               res.redirect('/doctor/treatment_manager');
             }catch (e) {
               res.redirect('/doctor/treatment_manager');

             }
       });
       router.post('/treatment/examination/cvs',Auth.loginDoctor,function(req, res) {
           try{

                 var CVS = req.body.DCVS;
                 var tcvs = new Array();
                 if(CVS != null)
                 {
                 if( Object.prototype.toString.call( CVS ) === '[object Array]' ) {
                   CVS.forEach(function(cvs) {
                     if(cvs != '')
                     {

                  Doctordata.update({"did" : req.session.user.did,"treatment.examination.name":"CVS"},{$addToSet : {"treatment.examination.$.status" : cvs }},function(err, data) {
                                                                              if (err){
                                                                              res.send(err);}

                                                                     }
                    );
                  }
                  });
                 }
                 else {
                   Doctordata.update({"did" : req.session.user.did,"treatment.examination.name":"CVS"},{$addToSet : {"treatment.examination.$.status" : CVS }},function(err, data) {
                                                                               if (err){
                                                                               res.send(err);}

                                                                      }
                     );
                 }
               }
               res.redirect('/doctor/treatment_manager');
          }catch (e) {
            res.redirect('/doctor/treatment_manager');

          }
       });
       router.post('/treatment/examination/rs',Auth.loginDoctor,function(req, res) {
           try{
                   var RS = req.body.DRS;
                   if(RS != null)
                   {
                   if( Object.prototype.toString.call( RS ) === '[object Array]' ) {
                     RS.forEach(function(rs) {
                       if(rs != '')
                       {

                    Doctordata.update({"did" : req.session.user.did,"treatment.examination.name":"RS"},{$addToSet : {"treatment.examination.$.status" : rs }},function(err, data) {
                                                                                if (err){
                                                                                res.send(err);}

                                                                       }
                      );
                    }
                    });
                   }
                   else {
                     Doctordata.update({"did" : req.session.user.did,"treatment.examination.name":"RS"},{$addToSet : {"treatment.examination.$.status" : RS}},function(err, data) {
                                                                                 if (err){
                                                                                 res.send(err);}

                                                                        }
                       );
                   }
                 }
                 res.redirect('/doctor/treatment_manager');
            }catch (e) {
              res.redirect('/doctor/treatment_manager');

            }

       });
       router.post('/treatment/examination/gs',Auth.loginDoctor,function(req, res) {
           try{
                   var GS = req.body.DGS;

                   if(GS != null)
                   {
                   if( Object.prototype.toString.call( GS ) === '[object Array]' ) {
                     GS.forEach(function(gs) {
                       if(gs != '')
                       {

                    Doctordata.update({"did" : req.session.user.did,"treatment.examination.name":"GS"},{$addToSet : {"treatment.examination.$.status" : gs }},function(err, data) {
                                                                                if (err){
                                                                                res.send(err);}

                                                                       }
                      );
                    }
                    });
                   }
                   else {
                     Doctordata.update({"did" : req.session.user.did,"treatment.examination.name":"GS"},{$addToSet : {"treatment.examination.$.status" : GS }},function(err, data) {
                                                                                 if (err){
                                                                                 res.send(err);}

                                                                        }
                       );
                   }
                 }
                 res.redirect('/doctor/treatment_manager');
            }catch (e) {
              res.redirect('/doctor/treatment_manager');

            }
       });
       router.post('/treatment/examination/cns',Auth.loginDoctor,function(req, res) {
           try{
                   var CNS = req.body.DCNS;
                   if(CNS != null)
                   {
                   if( Object.prototype.toString.call( CNS ) === '[object Array]' ) {
                     CNS.forEach(function(cns) {
                       if(cns != '')
                       {

                    Doctordata.update({"did" : req.session.user.did,"treatment.examination.name":"CNS"},{$addToSet : {"treatment.examination.$.status" : cns }},function(err, data) {
                                                                                if (err){
                                                                                res.send(err);}

                                                                       }
                      );
                    }
                    });
                   }
                   else {
                     Doctordata.update({"did" : req.session.user.did,"treatment.examination.name":"CNS"},{$addToSet : {"treatment.examination.$.status" : CNS }},function(err, data) {
                                                                                 if (err){
                                                                                 res.send(err);}

                                                                        }
                       );
                   }
                 }
                 res.redirect('/doctor/treatment_manager');
          }catch (e) {
            res.redirect('/doctor/treatment_manager');

          }
       });



          router.post('/treatment/co/delete',Auth.loginDoctor,function(req, res) {
              try{

                    var cos = req.body.DLCo;
                      if( Object.prototype.toString.call( cos ) === '[object Array]' ) {
                      cos.forEach(function(co) {
                      Doctordata.update({"did" : req.session.user.did},{$pull : {"treatment.co" :

                                                                                      {'name' : co}}},function(err, data) {
                                                                                        if (err){
                                                                                        res.send(err);}

                                                                        }
                       );
                     });
                   }
                   else {
                     Doctordata.update({"did" : req.session.user.did},{$pull : {"treatment.co" :

                                                                                     {'name' : cos}}},function(err, data) {
                                                                                       if (err){
                                                                                       res.send(err);}

                                                                       }
                      );
                   }


                     res.redirect('/doctor/treatment_manager');

            }
            catch (e) {
              res.redirect('/doctor/treatment_manager');

            }
          });

          router.post('/treatment/history/family/delete',Auth.loginDoctor,function(req, res) {
              try{

                    var hfs = req.body.DLHF;
                      if( Object.prototype.toString.call( hfs ) === '[object Array]' ) {
                    hfs.forEach(function(hf) {
                     Doctordata.update({"did" : req.session.user.did},{$pull : {"treatment.history.family":hf}},function(err, data) {
                                                                                 if (err){
                                                                                 res.send(err);}

                                                                        }
                       );
                     });
                   }
                   else {
                     Doctordata.update({"did" : req.session.user.did},{$pull : {"treatment.history.family":hfs}},function(err, data) {
                                                                                 if (err){
                                                                                 res.send(err);}

                                                                        }
                       );
                   }
                     res.redirect('/doctor/treatment_manager');
              }catch (e) {
                res.redirect('/doctor/treatment_manager');

              }
          });

          router.post('/treatment/history/personal/delete',Auth.loginDoctor,function(req, res) {
              try{
                    var hps = req.body.DLHP;
                      if( Object.prototype.toString.call( hps ) === '[object Array]' ) {
                    hps.forEach(function(hp) {
                     Doctordata.update({"did" : req.session.user.did},{$pull : {"treatment.history.personal":hp}},function(err, data) {
                                                                                 if (err){
                                                                                 res.send(err);}

                                                                        }
                       );
                     });
                   }
                   else {
                     Doctordata.update({"did" : req.session.user.did},{$pull : {"treatment.history.personal":hps}},function(err, data) {
                                                                                 if (err){
                                                                                 res.send(err);}

                                                                        }
                       );
                   }
                     res.redirect('/doctor/treatment_manager');
              }catch (e) {
                res.redirect('/doctor/treatment_manager');

              }
          });


          router.post('/treatment/report/delete',Auth.loginDoctor,function(req, res) {
              try{
                      var reports = req.body.DLRep;
                        if( Object.prototype.toString.call( reports ) === '[object Array]' ) {
                      reports.forEach(function(report) {
                       Doctordata.update({"did" : req.session.user.did},{$pull : {"treatment.report" : report}},function(err, data) {
                                                                                   if (err){
                                                                                   res.send(err);}

                                                                          }
                         );
                       });
                     }
                     else {
                       Doctordata.update({"did" : req.session.user.did},{$pull : {"treatment.report" : reports}},function(err, data) {
                                                                                   if (err){
                                                                                   res.send(err);}

                                                                          }
                         );
                     }
                       res.redirect('/doctor/treatment_manager');
                  }catch (e) {
                    res.redirect('/doctor/treatment_manager');

                  }
          });

          router.post('/treatment/dignosis/delete',Auth.loginDoctor,function(req, res) {
              try{
                      var dignosis = req.body.DLDig;
                        if( Object.prototype.toString.call( dignosis ) === '[object Array]' ) {
                        dignosis.forEach(function(dig) {
                      Doctordata.update({"did" : req.session.user.did},{$pull : {"treatment.dignosis" :dig}},function(err, data) {
                                                                                      if (err){
                                                                                      res.send(err);}

                                                                        }
                         );
                       });
                     }
                     else {
                       Doctordata.update({"_id" : req.session.user._id},{$pull : {"treatment.dignosis" :dignosis}},function(err, data) {
                                                                                       if (err){
                                                                                       res.send(err);}

                                                                         }
                          );
                     }
                       res.redirect('/doctor/treatment_manager');

                  }catch (e) {
                    res.redirect('/doctor/treatment_manager');

                  }
          });

          router.post('/treatment/advise/delete',Auth.loginDoctor,function(req, res) {
              try{
                    var advises = req.body.DLAdv;
                      if( Object.prototype.toString.call( advises ) === '[object Array]' ) {
                      advises.forEach(function(advise) {
                    Doctordata.update({"did" : req.session.user.did},{$pull : {"treatment.advise" : advise}},function(err, data) {
                                                                                      if (err){
                                                                                      res.send(err);}

                                                                      }
                       );
                     });
                   }
                   else {
                     Doctordata.update({"did" : req.session.user.did},{$pull : {"treatment.advise" : advises}},function(err, data) {
                                                                                       if (err){
                                                                                       res.send(err);}

                                                                       }
                        );
                   }
                     res.redirect('/doctor/treatment_manager');
                }catch (e) {
                  res.redirect('/doctor/treatment_manager');

                }
          });

          router.post('/treatment/medicine/delete',Auth.loginDoctor,function(req, res) {
              try{
                    var medicine = req.body.DLMed;
                      if( Object.prototype.toString.call( medicine ) === '[object Array]' ) {
                      medicine.forEach(function(med) {
                    Doctordata.update({"did" : req.session.user.did},{$pull : {"treatment.medicine" :med}},function(err, data) {
                                                                                    if (err){
                                                                                    res.send(err);}

                                                                      }
                       );
                     });
                   }
                   else {
                     Doctordata.update({"did" : req.session.user.did},{$pull : {"treatment.medicine" :medicine}},function(err, data) {
                                                                                     if (err){
                                                                                     res.send(err);}

                                                                       }
                        );
                   }
                     res.redirect('/doctor/treatment_manager');
                }catch (e) {
                  res.redirect('/doctor/treatment_manager');

                }
          });
          router.post('/treatment/examination/cvs/delete',Auth.loginDoctor,function(req, res) {
              try{
                    var CVS = req.body.DCVS;
                      if( Object.prototype.toString.call( CVS ) === '[object Array]' ) {
                    CVS.forEach(function(cvs) {
                     Doctordata.update({"did" : req.session.user.did,"treatment.examination.name":"CVS"},{$pull : {"treatment.examination.$.status" :cvs}},function(err, data) {
                                                                                 if (err){
                                                                                 res.send(err);}

                                                                        }
                       );
                     });
                   }
                   else {
                     Doctordata.update({"did" : req.session.user.did,"treatment.examination.name":"CVS"},{$pull : {"treatment.examination.$.status":CVS}},function(err, data) {
                                                                                 if (err){
                                                                                 res.send(err);}
                                                                        }
                       );
                   }
                     res.redirect('/doctor/treatment_manager');
                  }catch (e) {
                    res.redirect('/doctor/treatment_manager');

                  }
          });
          router.post('/treatment/examination/rs/delete',Auth.loginDoctor,function(req, res) {
              try{
                      var RS = req.body.DRS;
                        if( Object.prototype.toString.call( RS ) === '[object Array]' ) {
                      RS.forEach(function(rs) {
                       Doctordata.update({"did" : req.session.user.did,"treatment.examination.name":"RS"},{$pull : {"treatment.examination.$.status" :rs}},function(err, data) {
                                                                                   if (err){
                                                                                   res.send(err);}

                                                                          }
                         );
                       });
                     }
                     else {
                       Doctordata.update({"did" : req.session.user.did,"treatment.examination.name":"RS"},{$pull : {"treatment.examination.$.status":RS}},function(err, data) {
                                                                                   if (err){
                                                                                   res.send(err);}
                                                                          }
                         );
                     }
                       res.redirect('/doctor/treatment_manager');
                }catch (e) {
                  res.redirect('/doctor/treatment_manager');

                }
          });
          router.post('/treatment/examination/gs/delete',Auth.loginDoctor,function(req, res) {
              try{
                    var GS = req.body.DGS;
                      if( Object.prototype.toString.call( GS ) === '[object Array]' ) {
                    GS.forEach(function(gs) {
                     Doctordata.update({"did" : req.session.user.did,"treatment.examination.name":"GS"},{$pull : {"treatment.examination.$.status" :gs}},function(err, data) {
                                                                                 if (err){
                                                                                 res.send(err);}

                                                                        }
                       );
                     });
                   }
                   else {
                     Doctordata.update({"did" : req.session.user.did,"treatment.examination.name":"GS"},{$pull : {"treatment.examination.$.status":GS}},function(err, data) {
                                                                                 if (err){
                                                                                 res.send(err);}
                                                                        }
                       );
                   }
                     res.redirect('/doctor/treatment_manager');

                  }catch (e) {
                    res.redirect('/doctor/treatment_manager');

                  }
          });
          router.post('/treatment/examination/cns/delete',Auth.loginDoctor,function(req, res) {
              try{
                      var CNS = req.body.DCNS;
                        if( Object.prototype.toString.call( CNS ) === '[object Array]' ) {
                      CNS.forEach(function(cns) {
                       Doctordata.update({"did" : req.session.user.did,"treatment.examination.name":"CNS"},{$pull : {"treatment.examination.$.status" :cns}},function(err, data) {
                                                                                   if (err){
                                                                                   res.send(err);}

                                                                          }
                         );
                       });
                     }
                     else {
                       Doctordata.update({"did" : req.session.user.did,"treatment.examination.name":"CNS"},{$pull : {"treatment.examination.$.status":CNS}},function(err, data) {
                                                                                   if (err){
                                                                                   res.send(err);}
                                                                          }
                         );
                     }
                       res.redirect('/doctor/treatment_manager');
                  }catch (e) {
                    res.redirect('/doctor/treatment_manager');

                  }
          });
}
