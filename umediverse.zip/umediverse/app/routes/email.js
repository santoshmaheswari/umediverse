var smtpTransport = nodemailer.createTransport("SMTP",{
   service: "Gmail",
   auth: {
       user: "chauhanashvini05@gmail.com",
       pass: "456@ashvini"
   }
});

smtpTransport.sendMail({
 //email options
   from: "Ashvini Chauhan <chauhanashvini05@gmail.com>", // sender address.  Must be the same as authenticated user if using Gmail.
   to: "<santoshmaheswari.ce@gmail.com>", // receiver
   subject: "Emailing with nodemailer", // subject
   text: "Email Example with nodemailer" // body
}, function(error, response){  //callback
   if(error){

   }else{
      
   }

   smtpTransport.close(); // shut down the connection pool, no more messages.  Comment this line out to continue sending emails.
});
