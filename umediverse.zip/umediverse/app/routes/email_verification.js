//var nodemailer = require("nodemailer");
var bcrypt   = require('bcrypt-nodejs');
var async   = require('async');
var crypto   = require('crypto');
var Hospitaldata            = require('../models/hospitalDB');
var Doctordata            = require('../models/doctorDB');
var pharmacydata            = require('../models/pharmacyDB');
var Laboratorydata            = require('../models/laboratoryDB');
var Patientdata            = require('../models/patientDB');
var Admindata            = require('../models/admin');
var email_verification = require('./email_verification');
var User;
var user_type;
var tc = require('./hub');


module.exports.find_user = function (user) {
  if(user === "doctor")
    User = Doctordata;
  else if(user === "hospital")
    User = Hospitaldata;
  else if(user === "patient")
    User = Patientdata;
  else if(user === "pharmacy")
    User = pharmacydata;
  else if(user === "laboratory")
    User = Laboratorydata;
    else if(user === "admin")
      User = Laboratorydata;
}

module.exports.forgot = function (req,res,next) {
try{

  user_type = req.params.user;
email_verification.find_user(user_type);

    async.waterfall([
      function(done) {
        crypto.randomBytes(20, function(err, buf) {
          var token = buf.toString('hex');
          done(err, token);
        });
      },
      function(token, done) {

        User.findOne({ email: req.body.email }, function(err, user) {
          if (!user) {
            res.json({error : "Invalid Email Id."});
          }
          user.resetPasswordToken = token;
          user.resetPasswordExpires = Date.now() + 900000; // 1 hour

          user.save(function(err) {
            done(err, token, user);
          });
        });
      },
      function(token, user, done)
      {
        email_verification.forgot_email(req,token,user,done) ;
      }
    ], function(err) {
      if (err)
      {
        res.json({status : 500,error:"Error Occured!!!"});
      }
      else {
      res.json({status : 200,error:"Email Sent....Visit your Registered Email!!!"});
    }
    });

  } catch (e) {
      tc.try_catch(e,res);
    }

}

module.exports.reset_verify = function (req,res) {
try{

  user_type = req.route.path.split('/')[req.route.path.split('/').length -2];
  email_verification.find_user(user_type);


        User.findOne({ resetPasswordToken: req.params.token, resetPasswordExpires: { $gt: Date.now() } }, function(err, user) {
          if (!user) {
            res.json({status:404,error:"Password reset token is invalid or has expired."});
          }
          else {
            res.json({status:200,id :user._id});
          }
        });
      } catch (e) {
          tc.try_catch(e,res);
        }
}

module.exports.reset = function (req,res) {
try{

  email_verification.find_user(req.body.type);
  var type = new User();
  User.findById(req.body.id, function(err, user) {
    if (!user) {
      res.json({status:500,error:"Error Occured."});
    }
      user.password = type.generateHash(req.body.password);
      user.resetPasswordToken = undefined;
      user.resetPasswordExpires = undefined;

      user.save(function(err) {
        email_verification.reset_email(user) ;
      });
      res.json({status:200,error:"Password Updated Successfully!!!!"})
  });
} catch (e) {
    tc.try_catch(e,res);
  }
}

module.exports.forgot_email = function (req,token, user, done) {
  try{

  /*var smtpTransport = nodemailer.createTransport('SMTP', {
    service: 'Gmail',
    auth: {
      user: 'santoshmaheswari.ce@gmail.com',
      pass: 'snmecomputersn'
    }
  });
  var mailOptions = {
    to: user.email,
    from: 'passwordreset@usantinfo.com',
    subject: 'Node.js Password Reset',
    text: 'You are receiving this because you (or someone else) have requested the reset of the password for your account.\n\n' +
      'Please click on the following link, or paste this into your browser to complete the process:\n\n' +
      'http://' + req.headers.host + '/reset/'+ user_type +'/' + token + '\n\n' +
      'If you did not request this, please ignore this email and your password will remain unchanged.\n'
  };
  smtpTransport.sendMail(mailOptions, function(err) {
    done(err, 'done');
  });*/
} catch (e) {
    tc.try_catch(e,res);
  }

}

module.exports.reset_email = function (user, done) {
try{
/*
  var smtpTransport = nodemailer.createTransport('SMTP', {
    service: 'Gmail',
    auth: {
      user: 'santoshmaheswari.ce@gmail.com',
      pass: 'snmecomputersn'
    }
  });
  var mailOptions = {
    to: user.email,
    from: 'passwordreset@usantinfo.com',
    subject: 'Your password has been changed',
    text: 'Hello,\n\n' +
      'This is a confirmation that the password for your account ' + user.email + ' has just been changed.\n'
  };
  smtpTransport.sendMail(mailOptions, function(err) {
    if(err)
      res.json({error:"Error Occured.."});
  });*/
} catch (e) {
    tc.try_catch(e,res);
  }
}
