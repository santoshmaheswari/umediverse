var Auth = require('./auth');
var mongoose = require('mongoose');
var email_verification = require('./email_verification');

module.exports = function(router){
//localhost:8000/fogot

    router.post('/:user',function(req,res,next){
            email_verification.forgot(req,res,next);
    });

}
