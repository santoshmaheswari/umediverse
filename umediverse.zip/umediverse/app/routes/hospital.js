var Auth = require('./auth');
var formidable = require('formidable');
var mongoose = require('mongoose');
var fs = require('fs');
var mkDir = require('./mkdir');
var tc = require('./hub');


module.exports = function(router){
//localhost:8000/hospital
    var Hospitaldata            = require('../models/hospitalDB');
      var Doctordata            = require('../models/doctorDB');
      var Staffdata            = require('../models/staffDB');

    router.get('/all',function(req,res){
      try{
            Hospitaldata.find(function(err, data) {
                    if (err)
                        res.send(err);
                    res.json({'status':200,'data':data});
                });
          } catch (e) {
              tc.try_catch(e,res);
            }
    });

    router.get('/fees',Auth.loginHospital,function(req,res){
      try {

            Hospitaldata.find({"hid" : req.session.user.hid},{_id : 0,case_fees : 1},function(err, data) {
                    if (err)
                        res.send(err);
                    res.json({'status':200,'data':data});
                });
          }
          catch (e) {
            tc.try_catch(e,res);
          }

    });

    router.post('/case_history/data/',Auth.PatientPharmacyLaboratory,function(req,res){

      try {

            Hospitaldata.find({"hid" : {$in:req.body.hid}},{_id : 0,name : 1,add : 1,contact : 1,hid:1},function(err, data) {
                    if (err){
                        res.send(err);}
                        res.json({'status':200,'data':data});
                    });
              }
              catch (e) {
                tc.try_catch(e,res);
              }

    });

    router.get('/data',Auth.loginHospital,function(req,res){

        try {
        Hospitaldata.find({"_id" : req.session.user._id},{_id:0,password:0,doctor:0,rooms:0,auth:0},function(err, data) {
                    if (err)
                        res.send(err);

                        res.json({'status':200,'data':data});
                    });
              }
              catch (e) {
                tc.try_catch(e,res);
              }
    });

    router.get('/doctor/data',Auth.HospitalStaff,function(req,res){
      try {
            var hid;
            if(req.session.user.hid)
            {
              hid = req.session.user.hid;
            }
            else if(req.session.user[0].hid)
            {
              hid = req.session.user[0].hid;
            }
            Hospitaldata.aggregate( [{ $match: {"hid" : hid}},
                                      {$project : {_id : 0,"doctor":1}},
                                    { $unwind: "$doctor" },
                                    { $match: { "doctor.is_present" :true}},
                                    {$sort : {"doctor.doj":1}}
                                  ],function(err, data) {
                                     if (err){
                                      res.send(err);}

                                      res.json({'status':200,'data':data});
                                  });
          }
          catch (e) {
            tc.try_catch(e,res);
          }

    });

    router.get('/doctor/stdata',Auth.loginStaff,function(req,res){
      try {
            Hospitaldata.aggregate( [{ $match: {"hid" : req.session.user[0].hid}},
                                      {$project : {_id : 0,"doctor":1}},
                                    { $unwind: "$doctor" },
                                    { $match: { "doctor.is_present" :true}},
                                    {$sort : {"doctor.doj":1}}
                                  ],function(err, data) {
                                     if (err){
                                      res.send(err);}

                                      res.json({'status':200,'data':data});

                                    });
        }
        catch (e) {
                  tc.try_catch(e,res);
        }

    });

    router.get('/doctor/no_shift/data',Auth.loginHospital,function(req,res){
      try {

            var hid;
            if(req.session.user.hid)
            {
              hid = req.session.user.hid;
            }
            else if(req.session.user[0].hid)
            {
              hid = req.session.user[0].hid;
            }
            Hospitaldata.aggregate( [{ $match: {"hid" : hid}},
                                      {$project : {_id : 0,"doctor":1}},
                                    { $unwind: "$doctor" },
                                    { $match: { "doctor.is_present" :true,"doctor.shift":[]}},
                                    {$sort : {"doctor.doj":1}}
                                  ],function(err, data) {
                                     if (err){
                                      res.send(err);}

                                      res.json({'status':200,'data':data});

                                    });
        }
        catch (e) {
                  tc.try_catch(e,res);
        }
    });

    router.get('/doctor/shift/data',Auth.loginHospital,function(req,res){
      try {

            var hid;
            if(req.session.user.hid)
            {
              hid = req.session.user.hid;
            }
            else if(req.session.user[0].hid)
            {
              hid = req.session.user[0].hid;
            }
            Hospitaldata.aggregate( [{ $match: {"hid" : hid}},
                                      {$project : {_id : 0,"doctor":1}},
                                    { $unwind: "$doctor" },
                                    { $match: { "doctor.is_present" :true,"doctor.shift":{$exists:true,$ne:[]}}},
                                    {$sort : {"doctor.doj":1}},
                                    {$project : {"doctor._id":1}},
                                  ],function(err, data) {
                                     if (err){
                                      res.send(err);}

                                      res.json({'status':200,'data':data});

                                    });
        }
        catch (e) {
                  tc.try_catch(e,res);
        }

    });

    router.get('/doctor/shift/data/:did',Auth.loginHospital,function(req,res){
      try {
            var hid;
            if(req.session.user.hid)
            {
              hid = req.session.user.hid;
            }
            else if(req.session.user[0].hid)
            {
              hid = req.session.user[0].hid;
            }

            Hospitaldata.aggregate( [{ $match: {"hid" : hid}},
                                      {$project : {_id : 0,"doctor":1}},
                                    { $unwind: "$doctor" },
                                    { $match: {"doctor._id" : req.params.did}},
                                  ],function(err, data) {
                                     if (err){
                                      res.send(err);
                                    }
                                    else {
                                      res.json({'status':200,'data':data});
                                    }
                                    });
        }
        catch (e) {
                  tc.try_catch(e,res);
        }

    });


    router.get('/doctor/data/:did',Auth.loginHospital,function(req,res){
      try {

            Doctordata.find({"did" : req.params.did},{_id:0,username:0,password:0,hospital:0,treatment:0},function(err, data) {
                        if (err)
                            res.send(err);


                            res.json({'status':200,'data':data});

                          });
        }
        catch (e) {
            tc.try_catch(e,res);
        }
    });

    router.get('/staff/data',Auth.loginHospital,function(req,res){
      try {

            Hospitaldata.aggregate( [{ $match: {"hid" : req.session.user.hid}},
                                      {$project : {_id : 0,"staff":1}},
                                    { $unwind: "$staff" },
                                    { $match: { "staff.is_present" :true}},
                                    {$sort : {"doctor.doj":1}}
                                  ],function(err, data) {
                                     if (err){
                                      res.send(err);}
                                      res.json({'status':200,'data':data});

                                    });
          }
          catch (e) {
                tc.try_catch(e,res);
          }
    });

    router.get('/s/staff/data/:sid',Auth.loginHospital,function(req,res){
      try {
        id = mongoose.Types.ObjectId(req.params.sid);
        Staffdata.find({"_id" : id},function(err, data) {
                    if (err)
                        res.send(err);
                    res.json({'status':200,'data':data,'error':'successful'});
        });
      } catch (e) {
        tc.try_catch(e,res);
      }

    });

    router.get('/staff/account/all',Auth.loginHospital,function(req,res){
      try {

        Hospitaldata.find({"_id" : req.session.user._id},{"auth" : 1,_id : 0},function(err, data) {
                    if (err)
                        res.send(err);
                        res.json({'status':200,'data':data,'error':'successful'});
              });
          } catch (e) {
            tc.try_catch(e,res);
          }
    });

    /*router.get('/staff/account/view',Auth.loginHospital,function(req,res){
      try {

        Hospitaldata.find({"_id" : req.session.user._id,"auth._id" : req.body.id},{"auth" : 1,_id : 0,"auth.password" : 0},function(err, data) {
                    if (err)
                        res.send(err);


                        res.json({'status':200,'data':data,'error':'successful'});
              });
          } catch (e) {
            tc.try_catch(e,res);
          }
    });*/

    router.get('/staff/account/delete/:id',Auth.loginHospital,function(req, res) {
      try {

        Hospitaldata.update({"_id" : req.session.user._id},{$pull : {"auth" : {"_id" : req.params.id}}},function(err, data) {
                                                                          if (err){
                                                                          res.send(err);}
                                                                          else{

                                                                            res.json({       'status': 200,
                                                                                            'error': 'Account Deleted...',
                                                                                            'user_data': {}
                                                                                        });
                                                                                }
                                                          }
         );
       } catch (e) {
         tc.try_catch(e,res);
       }

    });

    router.post('/change_password',Auth.loginHospital,function(req,res){
      try {

      var hospitaldata  = new Hospitaldata();
                      Hospitaldata.findOne({"_id" : req.session.user._id},function(err, user) {
                              if (err)
                                    res.send(err);
                                if (!user.validPassword(req.body.CPassword))
                                {
                                  res.json({       'status': 500,
                                                  'error': 'Incorrect Password Entered'
                                              });
                                }
                                else {

                                  Hospitaldata.update({"_id" : req.session.user._id},{$set : {'password' : hospitaldata.generateHash(req.body.NPassword)}},
                                                                                            function(err, data) {
                                                                                                      if (err)
                                                                                                      {res.send(err);}
                                                                                                      else {
                                                                                                        res.json({       'status': 200,
                                                                                                                        'error': 'Password successfully Changed...',
                                                                                                                        'user_data': {}
                                                                                                                    });
                                                                                                    }

                                          });

                                }
                                //res.json(data);
                            });
                          } catch (e) {
                            tc.try_catch(e,res);
                          }

    });

    router.post('/username/verify',function(req,res){
      try {

      var form = new formidable.IncomingForm();
      form.parse(req,function(err, fields, files) {
                Hospitaldata.find({"username" : fields.HUName},{username:1,_id:0},function(err, data) {
                              if (err)
                                    res.send(err);
                              if(data=="")
                              {
                                res.json({       'status': 200,
                                                  'error': 'Available'
                                        });
                              }
                              else {
                                res.json({       'status': 200,
                                                  'error': 'Already Registered'
                                        });
                              }
                            });
      });
    } catch (e) {
      tc.try_catch(e,res);
    }

    });

    router.post('/id/verify',function(req,res){
      try {

              var form = new formidable.IncomingForm();
              form.parse(req,function(err, fields, files) {
                        Hospitaldata.find({"hid" : fields.HLic},{hid:1,_id:0},function(err, data) {

                                      if (err)
                                            res.send(err);
                                      if(data=="")
                                      {
                                        res.json({'status': 200,
                                                          'error': 'Available'});
                                      }
                                      else {
                                        res.json({'status': 500,
                                                          'error': 'Already Registered'});
                                      }
                                    });
              });
            } catch (e) {
              tc.try_catch(e,res);
            }

    });


    router.post('/registration',function(req, res) {
      try {
        console.log("hospital");
              var hospitaldata  = new Hospitaldata();
              var form = new formidable.IncomingForm();
              var pincode;
              form.uploadDir = 'views/upload/';

              form.parse(req,function(err, fields, files) {
                hospitaldata.hid  = fields["HLic"];
                file:
                {
                  if(!files.file)
                  {
                  break file;
                  }
                pincode = fields["HPin"];
                var location = 'views/upload/hospital/' + pincode;
                mkDir.mkDir(location,res);
                location = location  + "/" + hospitaldata.hid;
                fs.mkdirSync(location);
                files['file'].name = hospitaldata.hid + '.' + files['file'].name.split('.')[files['file'].name.split('.').length -1];
                location = location + "/" + files['file'].name;
                fs.rename(files['file'].path, location);
                location = dir+'/upload/hospital/' + pincode + "/" + hospitaldata.hid + "/" + files['file'].name;

                hospitaldata.logo = location;
              }

              hospitaldata.name = fields["HName"];
              hospitaldata.paramlink = fields["HPLink"];
              hospitaldata.username =fields["HUName"];
              hospitaldata.password = hospitaldata.generateHash(fields["HPass"]);
              hospitaldata.est_date = fields["HEDate"];
              hospitaldata.type = fields["HType"];
              hospitaldata.description = fields["HDes"];
              hospitaldata.url = fields["HLink"];
              hospitaldata.contact      =  fields["Hcont"];

                        /*
              for(key in Hcont )
              {

                hospitaldata.contact.push(Hcont[key]);
              }*/
              hospitaldata.e_contact = fields["HEcon"];
              hospitaldata.email = fields["HMail"];
              hospitaldata.category = fields["HCat"];
              hospitaldata.fax = fields["HFax"];
              hospitaldata.add.street = fields["HStreet"];
              hospitaldata.add.l_mark = fields["HLand"];
              hospitaldata.add.city = fields["HCity"];
              hospitaldata.add.dist = fields["HDis"];
              hospitaldata.add.state = fields["HState"];
              hospitaldata.add.country = fields["HCoun"];
              hospitaldata.add.pincode = fields["HPin"];
              hospitaldata.location.x = fields["HLX"];
              hospitaldata.location.y =fields["HLY"];
              hospitaldata.title = fields["HTitle"];
              hospitaldata.achivements = fields["Hachive"];
              hospitaldata.formula = fields["HForm"];

                  hospitaldata.save(function(err) {
                      if(err){
                        }
                        else {
                          res.json({       'status': 200,
                                        'error': 'Record Created...',
                                        'user_data': {}
                              });
                        }

                  });

                })

              form.on('error', function(err) {

              request.resume();
              });

              form.on('aborted', function(err) {

              });



          } catch (e) {
            tc.try_catch(e,res);
          }
        });

        router.post('/update',Auth.loginHospital,function(req,res){
          try {

          var form = new formidable.IncomingForm();
          form.uploadDir = 'views/upload/';

          form.parse(req,function(err, fields, files) {

            file:
            {
              if(fields.logo)
              {
              break file;
              }
              if(!files.logo)
              {
              fields.logo = "";
              break file;
              }

              pincode = fields["pincode"];
              var location = 'views/upload/hospital/' + pincode;

              mkDir.mkDir(location,res);

              location = location  + "/" + req.session.user.hid;
              mkDir.mkDir(location,res);

              files['logo'].name = req.session.user.hid + '.' + files['logo'].name.split('.')[files['logo'].name.split('.').length -1];
              location = location + "/" + files['logo'].name;

              fs.rename(files['logo'].path, location);
              location = dir+'/upload/hospital/' + pincode + "/" + req.session.user.hid + "/" + files['logo'].name;
              fields.logo = location;

            }

                            Hospitaldata.update({"_id" : req.session.user._id},{$set : { 'paramlink' : fields.paramlink,
                                                                                'category' : fields.category,
                                                                                'type' : fields.type,
                                                                                'description' : fields.description,
                                                                                'url' : fields.url,
                                                                                'fax' : fields.fax,
                                                                                'category' : fields.category,
                                                                                'paramlink' : fields.paramlink,
                                                                                'est_date': fields.est_date,
                                                                                'add.street' : fields.street,
                                                                                'add.l_mark' : fields.l_mark,
                                                                                'add.pincode' : fields.pincode,
                                                                                'add.city' : fields.city,
                                                                                'add.country' : fields.country,
                                                                                'add.state' : fields.state,
                                                                                'add.dist' : fields.dist,
                                                                                'contact' : fields.contact,
                                                                                'email' : fields.email,
                                                                                'e_contact' : fields.e_contact,
                                                                                'title' : fields.title,
                                                                                'location.x' : fields.x,
                                                                                'location.y' : fields.y,
                                                                                'logo' : fields.logo

                                                                                }},function(err, data) {
                                                                                          if (err)
                                                                                          res.send(err);
                                                                                          res.json({       'status': 200,
                                                                                                          'error': 'Profile Updated...',
                                                                                                          'user_data': {}
                                                                                                      });

                        });
              });
            } catch (e) {
              tc.try_catch(e,res);
            }

        });

        router.post('/staff/approve',Auth.loginHospital,function(req, res) {
          try {


          if(req.body.SDET && req.body.SDate && req.body.SSal && req.body.SDes)
          {

            Hospitaldata.update({"_id" : req.session.user._id},{$addToSet : {"staff" :

                                                                            {'_id' : req.body.SDET,
                                                                             'doj' : req.body.SDate,
                                                                             'salary' : req.body.SSal,
                                                                             'designation' : req.body.SDes,
                                                                             'is_present' : "true"}}},function(err, data) {

                                                                              if (err){
                                                                              res.send(err);}
                                                                              else {
                                                                                res.json({       'status': 200,
                                                                                                'error': 'Staff Approved...',
                                                                                                'user_data': {}
                                                                                            });
                                                                                }});
          }
          else {
                    res.json({      'status': 500,
                                    'error': 'Fill Proper Data...',
                                    'user_data': {}
                            });
                }
              } catch (e) {
                tc.try_catch(e,res);
              }
          });

             router.post('/doctor/update',Auth.loginHospital,function(req, res) {
               try {


               if(!req.body.special_fees)
               {

                 req.body.special_fees = "";
               }
                  Hospitaldata.update({"_id" : req.session.user._id,"doctor" :{$elemMatch:{"_id":req.body.did,"is_present":true}} },{$set : {"doctor.$.designation" : req.body.designation,
                                                                                  "doctor.$.salary" : req.body.salary,"doctor.$.special_fees" : req.body.special_fees}},function(err, data) {
                                                                                   if (err){
                                                                                   res.send(err);}

                                                                                   res.json({       'status': 200,
                                                                                                   'error': 'Doctor Updated...',
                                                                                                   'user_data': {}
                                                                                               });

                                                                   }
                  );

                } catch (e) {
                  tc.try_catch(e,res);
                }

             });


        router.post('/doctor/approve',Auth.loginHospital,function(req, res) {
        try {

          if(req.body.DDET && req.body.DDate && req.body.DSAL && req.body.DDes)
          {

            Hospitaldata.update({"_id" : req.session.user._id},{$addToSet : {"doctor" :
                                                                                {'_id' : req.body.DDET,
                                                                                'name' : req.body.name,
                                                                                 'doj' : req.body.DDate,
                                                                                 'salary' : req.body.DSAL,
                                                                                 'designation' : req.body.DDes,
                                                                                 'is_present' : "true"}
                                                                              }},function(err, data) {
                                                                              if (err){
                                                                              res.send(err);}
                                                              }
             );
             Doctordata.update({"did" : req.body.DDET},{$addToSet : {"hospital" : req.session.user._id}},function(err, data) {
                                                                               if (err){
                                                                               res.send(err);}
                                                               }
              );
              res.json({       'status': 200,
                              'error': 'Doctor Approved...',
                              'user_data': {}
                          });
                        }
                        else {
                            res.json({       'status': 500,
                                              'error': 'Fill Proper Data...',
                                              'user_data': {}
                                    });
                          }
              } catch (e) {
                  tc.try_catch(e,res);
              }

        });

        router.post('/staff/relieve',Auth.loginHospital,function(req, res) {
            try {
                  if(req.body.SDET && req.body.SDate)
                  {

                    Hospitaldata.update({"_id" : req.session.user._id,"staff" :{$elemMatch:{"_id":req.body.SDET,"is_present":true}}},{$set : {"staff.$.dol" : req.body.SDate,
                                                                                     "staff.$.is_present" : "false"}},function(err, data) {
                                                                                      if (err){
                                                                                      res.send(err);}


                                                                      }
                     );
                     Staffdata.update({"_id" : req.body.SDET},{$unset : {"hospital" :req.session.user._id}},function(err, data) {
                                                                                       if (err){
                                                                                       res.send(err);}


                                                                       }
                      );

                      res.json({       'status': 200,
                                      'error': 'Staff Relieved...',
                                      'user_data': {}
                                  });
                  }
                  else {
                      res.json({       'status': 500,
                                        'error': 'Fill Proper Data...',
                                        'user_data': {}
                              });
                    }
              } catch (e) {
                    tc.try_catch(e,res);
              }
        });

        router.post('/doctor/relieve',Auth.loginHospital,function(req, res){
            try {
                  if(req.body.DDET && req.body.DDate)
                  {
                      Hospitaldata.update({"_id" : req.session.user._id,"doctor":{$elemMatch:{"_id":req.body.DDET,"is_present":true}}},{$set : {"doctor.$.dol" : req.body.DDate,
                                                                                       'doctor.$.is_present' : "false"}},function(err, data) {
                                                                                        if (err){
                                                                                        res.send(err);}

                                                                        }
                       );
                       Doctordata.update({"did" : req.body.DDET},{$pull : {"hospital" :req.session.user._id}},function(err, data) {
                                                                                         if (err){
                                                                                         res.send(err);}

                                                                         }
                        );
                        res.json({       'status': 200,
                                        'error': 'Doctor Relieved...',
                                        'user_data': {}
                                    });
                    }
                    else {
                      res.json({       'status': 500,
                                      'error': 'Fill Proper Data...',
                                      'user_data': {}
                                  });
                    }
                  } catch (e) {
                        tc.try_catch(e,res);
                  }

        });

        router.post('/doctor/shift/s',Auth.loginHospital,function(req, res) {
            try {
                    var days = req.body.Day;
                    var ST = req.body.ST;
                    var length = ST.length;
                    var ET = req.body.ET;
                    var TP = req.body.TP;
                    var DR = req.body.DR;
                    var shift = new Array();
                    var session = req.body.session;
                    var Day = new Array();
                    if(days != null)
                    {
                      for(i=0;i<length;i++)
                      {
                        Day[i]=new Array();
                        if(days.Mon != null && days.Mon[i] === true)
                        {
                          Day[i].push("Monday");
                        }
                        if(days.Tue != null && days.Tue[i] === true)
                        {
                          Day[i].push("Tuesday");
                        }
                        if(days.Wed != null && days.Wed[i] === true)
                        {
                          Day[i].push("Wednesday");
                        }
                        if(days.Thu != null && days.Thu[i] === true)
                        {
                          Day[i].push("Thursday");
                        }
                        if(days.Fri != null && days.Fri[i] === true)
                        {
                          Day[i].push("Friday");
                        }
                        if(days.Sat != null && days.Sat[i] === true)
                        {
                          Day[i].push("Saturday");
                        }
                        if(days.Sun != null && days.Sun[i] === true)
                        {
                          Day[i].push("Sunday");
                        }
                      }
                    }
                    for(i=0;i<length;i++)
                    {
                      shift.push({"start":ST[i],"end":ET[i],"session":session[i],"day":Day[i],"patient_count":TP[i]});
                    }

                    if(shift)
                    {

                      Hospitaldata.update({"_id" : req.session.user._id,"doctor" :{$elemMatch:{"_id":DR,"is_present":true}}},
                                                                                              {$set : {"doctor.$.shift" : shift}},
                                                                                              function(err, data) {


                                                                                                if (err){
                                                                                                  res.send(err);
                                                                                                }


                                                                        }
                       );
                       res.json({       'status': 200,
                                        'error': 'Data Updated...',
                                        'user_data': {}
                                });
                    }
                    else {
                        res.json({       'status': 500,
                                          'error': 'Fill Proper Data...',
                                          'user_data': {}
                                });
                    }
                  } catch (e) {
                        tc.try_catch(e,res);
                  }
        });

        router.post('/doctor/shift/update/s',Auth.loginHospital,function(req, res) {
            try {

                  Hospitaldata.update({"_id" : req.session.user._id,"doctor" :{$elemMatch:{"_id":req.body._id,"is_present":true}}},
                                                                                          {$set : {"doctor.$.shift" : req.body.shift}},
                                                                                          function(err, data) {

                                                                                            if (err){
                                                                                              res.send(err);
                                                                                            }
                                                                                            res.json({       'status': 200,
                                                                                                             'error': 'Data Updated successfully...',
                                                                                                             'user_data': {}
                                                                                                     });

                                                                    }
                   );
                 } catch (e) {
                       tc.try_catch(e,res);
                 }

        });

        router.post('/fees',Auth.loginHospital,function(req, res) {
            try {
                  var special = req.body.special;
                  if(!special)
                  {
                    special = 0;
                  }
                  Hospitaldata.update({"hid" : req.session.user.hid},{$set : {"case_fees" :

                                                                                  {'new' : req.body.new,
                                                                                   'old' : req.body.old,
                                                                                   'emergency' : req.body.emergency,
                                                                                   'special' : req.body.special}}},function(err, data) {
                                                                                    if (err){
                                                                                    res.send(err);}
                                                                                    else{

                                                                                      res.json({       'status': 200,
                                                                                                      'error': 'Fees Updated...',
                                                                                                      'user_data': {}
                                                                                                  });}
                                                                    }
                   );
                 } catch (e) {
                       tc.try_catch(e,res);
                 }
        });

        router.post('/staff/account',Auth.loginHospital,function(req, res) {
            try {

                  var hospitaldata  = new Hospitaldata();

                  if(req.body.SID && req.body.SUName && req.body.SPass && req.body.SRole)
                  {

                  Hospitaldata.update({"_id" : req.session.user._id},{$addToSet : {"auth" :

                                                                                  {'staff_id' : req.body.SID,
                                                                                   'username' : req.body.SUName,
                                                                                   'password' : hospitaldata.generateHash(req.body.SPass),
                                                                                   'role' : req.body.SRole
                                                                                   }}},function(err, data) {
                                                                                    if (err){
                                                                                    res.send(err);}
                                                                                    else {
                                                                                      res.json({       'status': 200,
                                                                                                      'error': 'Account Created...',
                                                                                                      'user_data': {}
                                                                                                  });
                                                                                    }

                                                                    }
                   );
                 }
                 else {
                   res.json({       'status': 500,
                                   'error': 'Fill Proper Data...',
                                   'user_data': {}
                               });
                 }
               } catch (e) {
                     tc.try_catch(e,res);
               }

        });

        router.post('/staff/account/update',Auth.loginHospital,function(req, res) {
            try {

                    if(req.body.staff_id && req.body.role && req.body.username)
                    {


                      Hospitaldata.update({"hid" : req.session.user.hid,"auth.username" : req.body.username},{$set : {"auth.$.staff_id" : req.body.staff_id,
                                                                                       'auth.$.role' : req.body.role}},function(err, data) {
                                                                                        if (err){
                                                                                        res.send(err);}
                                                                                        else{


                                                                                          res.json({       'status': 200,
                                                                                                          'error': 'Account Updated...',
                                                                                                          'user_data': {}
                                                                                                      });}
                                                                        }
                       );
                     }
                     else {
                       res.json({       'status': 500,
                                       'error': 'Fill Proper Data...',
                                       'user_data': {}
                                   });
                     }
                   } catch (e) {
                         tc.try_catch(e,res);
                   }
        });
}
