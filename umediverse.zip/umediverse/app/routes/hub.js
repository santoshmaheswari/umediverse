var recaptcha = require('../../config/database');

module.exports.try_catch = function (e,res) {

  if(mode != "Product")
  {
    console.log();;
    console.log("Exception Error :");
    console.log(e);
    console.log("\n\n");
  }
  res.json({'status':500,'error':'Error Occured'});
}


// Helper function to make API call to recatpcha and check response
module.exports.verifyRecaptcha = function (key, callback) {
        /*https.post("https://www.google.com/recaptcha/api/siteverify?secret=" + recaptcha.recaptcha-secret + "&response=" + key, function(res) {
                var data = "";
                res.on('data', function (chunk) {
                        data += chunk.toString();
                });
                res.on('end', function() {
                        try {
                                var parsedData = JSON.parse(data);
                                console.log(parsedData);
                                callback(parsedData.success);
                        } catch (e) {
                                callback(false);
                        }
                });
        });*/
}
