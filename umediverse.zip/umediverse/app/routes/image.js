var multer = require('multer');
var fs = require('fs');


  var patientstorage = multer.diskStorage({ //multers disk storage settings
          destination: function (req, file, cb) {

            var newDestination = 'views/upload/';
            var stat = null;
      try {
          stat = fs.statSync(newDestination);
      } catch (err) {
          fs.mkdirSync(newDestination);
      }
      if (stat && !stat.isDirectory()) {
          throw new Error('Directory cannot be created because an inode of a different type exists at "' + dest + '"');
      }
              cb(null, newDestination);

          },
          filename: function (req, file, cb) {
              var datetimestamp = Date.now();
              cb(null, file.fieldname + '-' + datetimestamp + '.' + file.originalname.split('.')[file.originalname.split('.').length -1]);
          }
      });

    module.exports.patientupload = multer({ //multer settings
                      storage: patientstorage
                  }).single('file');

    var doctorstorage = multer.diskStorage({ //multers disk storage settings
                         destination: function (req, file, cb) {

                            var newDestination = 'views/upload/' + req.body.DPin + '/' + req.body.DReg ;
                            var stat = null;
                          

                      try {
                          stat = fs.statSync(newDestination);
                      } catch (err) {
                          fs.mkdirSync(newDestination);
                      }
                      if (stat && !stat.isDirectory()) {
                          throw new Error('Directory cannot be created because an inode of a different type exists at "' + dest + '"');
                      }
                              cb(null, newDestination);

                          },
                          filename: function (req, file, cb) {
                              var datetimestamp = Date.now();
                              cb(null, req.body.DReg + '.' + file.originalname.split('.')[file.originalname.split('.').length -1]);
                          }
                      });

    module.exports.doctorupload = multer({ //multer settings
                                      storage: doctorstorage
    }).single('file');
