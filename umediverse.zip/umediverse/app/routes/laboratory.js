var Auth = require('./auth');
var formidable = require('formidable');
var mongoose = require('mongoose');
var fs = require('fs');
var mkDir = require('./mkdir');

module.exports = function(router){
//localhost:8000/laboratory
    var Laboratorydata            = require('../models/laboratoryDB');
    var Patientdata            = require('../models/patientDB');

    router.get('/all',function(req,res){
      try{
            Laboratorydata.find(function(err, data) {
                    if (err)
                        res.send(err);

                        res.json({'status':200,'data':data});

                });
          } catch (e) {
              tc.try_catch(e,res);
            }
    });

    router.get('/data',Auth.loginLaboratory,function(req,res){
        try{

              Laboratorydata.find({"_id" : req.session.user._id},function(err, data) {
                          if (err)
                              res.send(err);


                              res.json({'status':200,'data':data});

              });
            } catch (e) {
                tc.try_catch(e,res);
              }
    });

    router.get('/s/fees',Auth.loginLaboratory,function(req,res){
        try{
            Laboratorydata.find({"lid" : req.session.user.lid},{_id : 0,investigation_list : 1,emergency_fees:1},function(err, data) {
                    if (err)
                        res.send(err);
                        res.json({'status':200,'data':data});

                });
          } catch (e) {
              tc.try_catch(e,res);
            }
    });

    router.get('/patient/data',Auth.loginLaboratory,function(req,res){
        try{
              var yesterday = new Date();
              yesterday.setDate(yesterday.getDate()-1);
              yesterday.setHours(0,0,0,0);
              var tomorrow = new Date();
              tomorrow.setDate(tomorrow.getDate()+1);
              tomorrow.setHours(0,0,0,1);

              var investigation = req.session.user.investigation_list.map(function(a){return a.name});

              Patientdata.aggregate( [{ $match: {"case_detail.hospital_id" : req.session.user.hospital}},
                                        {$project : {_id : 0,case_detail:1,name:1,gender : 1,"add.city" : 1}},
                                      { $unwind: "$case_detail" },
                                      { $unwind: { path: "$case_detail.visit_detail", includeArrayIndex: "Index"}},
                                      {$project : {_id : 0, "case_detail.visit_detail.app_date":1,"case_detail.visit_detail._id":1,
                                      "case_detail.doctor_id":1,name:1,gender : 1,"add.city":1,"case_detail.hospital_id":1,"case_detail.visit_detail.treatment.report":1}},
                                      { $match: {$and :[{"case_detail.visit_detail.treatment.report" : {$elemMatch: {"name" :{$in :investigation}}}}, {"case_detail.visit_detail.app_date" :{"$gt":yesterday,"$lt":tomorrow}},{"case_detail.hospital_id" : req.session.user.hospital}]}},
                                      {$sort:{"case_detail.visit_detail.app_date":1}}
                                    ],function(err, data) {

                                       if (err){
                                        res.send(err);

                                      }
                                        else {
                                          if(data.length !=0 && data !== 'undefined' )
                                          {
                                            res.json({       'status': 200,
                                                            'error': 'Data',
                                                            'data': data
                                                        });
                                          }
                                          else {

                                              res.json({       'status': 500,
                                                              'error': 'No data available',
                                                              'data': ''
                                                          });
                                          }
                                        }

                                      });
              } catch (e) {
                  tc.try_catch(e,res);
                }
    });

    router.get('/patient/data/s/:id',Auth.loginLaboratory,function(req,res){
        try{
              id = mongoose.Types.ObjectId(req.params.id);
              Patientdata.aggregate( [{ $match: {"case_detail.visit_detail._id" : id}},
                                      { $project : {name:1,case_detail:1,bod : 1,
                                                      gender : 1,contact : 1,"add.city":1,dir_name:1}},
                                      { $unwind: "$case_detail" },
                                      { $unwind:  { path:"$case_detail.visit_detail", includeArrayIndex: "Index" }},
                                      { $match: { "case_detail.visit_detail._id" : id}},
                                      { $project : {name:1,"case_detail._id":1,"case_detail.doctor_id":1,"case_detail.hospital_id":1,
                                                "case_detail.visit_detail.app_date":1,"case_detail.visit_detail._id":1,
                                                "case_detail.visit_detail.treatment.report": 1 , dir_name:1,bod : 1,gender : 1,contact : 1,"add.city":1
                                              }}]
                                                ,function(err, data) {if (err){
                                        res.send(err);}
                                        else {
                                          res.json({       'status': 200,
                                                          'error': 'Data',
                                                          'data': data
                                                      });
                                        }
                                      });
            } catch (e) {
                tc.try_catch(e,res);
              }
    });

    router.get('/patient/investigation/upload/:id',Auth.loginLaboratory,function(req,res){
        try{
              id = mongoose.Types.ObjectId(req.params.id);
              Patientdata.aggregate( [{ $match: {"case_detail.visit_detail._id" : id}},
                                        {$project : {name:1,case_detail:1,img:1,dir_name:1,bod : 1}},
                                        { $unwind: "$case_detail" },
                                        { $unwind:  { path:"$case_detail.visit_detail", includeArrayIndex: "Index" }},
                                        { $match: { "case_detail.visit_detail._id" : id}},
                                        {$project : {name:1,bod : 1,dir_name:1,"case_detail.doctor_id":1,"case_detail.hospital_id":1,"case_detail._id":1,"case_detail.visit_detail._id":1,"case_detail.visit_detail.app_date":1,"case_detail.visit_detail.treatment.report":1,img:1}},
                                      ],function(err, data) {
                                       if (err){
                                        res.send(err);}
                                        else {

                                          res.json({       'status': 200,
                                                          'error': 'Data',
                                                          'data': data
                                                      });
                                        }


                                      });
            } catch (e) {
                tc.try_catch(e,res);
              }
    });

    router.post('/getName',Auth.loginDoctor,function(req,res){
        try{


              Laboratorydata.findById(req.body.LabId,{_id:0,name:1},function(err, data) {
                          if (err)
                          {
                              res.send(err);
                            }
                            else {
                              res.json({'status':200,'data':data});
                              
                            }


              });
         } catch (e) {
             tc.try_catch(e,res);
           }
    });

    router.post('/patient/investigation/upload',Auth.loginLaboratory,function(req,res){
        try{

                var form = new formidable.IncomingForm();
                form.uploadDir = 'views/upload/';

                form.parse(req,function(err, fields, files) {


                    files['img'].name = fields.PInv + '.' + files['img'].name.split('.')[files['img'].name.split('.').length -1];
                    location = fields.dir_name + "/" + fields.id + "/" +files['img'].name;

                    mkDir.mkDir('views/upload/patient/'+fields['dir_name'].split('/')[fields['dir_name'].split('/').length -1],res);
                    mkDir.mkDir('views/upload/patient/'+fields['dir_name'].split('/')[fields['dir_name'].split('/').length -1]+'/'+fields.id,res);

                    fs.rename(files['img'].path, location);
                    location = dir+'/upload/patient/' + fields['dir_name'].split('/')[fields['dir_name'].split('/').length -1] + "/" + fields.id + "/" + files['img'].name;
                    fields.img = location;

                   Patientdata.findById(fields.id,function(err,data){
                            if(err)
                            {
                              res.send(err);
                            }
                            else {
                              var t = data.case_detail.id(fields.case).visit_detail.id(fields.visit).treatment.report.id(fields.PInv);
                              t.img = fields.img;
                              t.laboratory_id = req.session.user.lid;
                              t.laboratory_name = req.session.user.name;
                              t.date = new Date();
                              for(i in req.session.user.investigation_list)
                              {
                                if(req.session.user.investigation_list[i].name ==fields.name)
                                {
                                  t.fees = req.session.user.investigation_list[i].fees;
                                }
                              }
                            //  t.detail.fees = req.session.user.investigation_list.fees
                              data.save();
                              res.json({       'status': 200,
                                              'error':'successfully Uploaded!!!!',
                                              'user_data': {}
                                          });
                            }


                          })
                      });
              } catch (e) {
                  tc.try_catch(e,res);
                }
      });



    router.post('/change_password',Auth.loginLaboratory,function(req,res){
        try{
                var laboratorydata  = new Laboratorydata();

                Laboratorydata.findOne({"_id" : req.session.user._id},function(err, user) {
                              if (err)
                                    res.send(err);
                                if (!user.validPassword(req.body.CPassword))
                                {
                                  res.json({       'status': 500,
                                                  'error': 'Incorrect Password Entered'
                                              });
                                }
                                else {

                                  Laboratorydata.update({"_id" : req.session.user._id},{$set : {'password' : laboratorydata.generateHash(req.body.NPassword)}},
                                                                                            function(err, data) {
                                                                                                      if (err)
                                                                                                      {res.send(err);}
                                                                                                      else {
                                                                                                        res.json({       'status': 200,
                                                                                                                        'error': 'Password successfully Changed...',
                                                                                                                        'user_data': {}
                                                                                                                    });
                                                                                                    }

                                          });

                                }
                                //res.json(data);
                            });
          } catch (e) {
              tc.try_catch(e,res);
            }
    });




    router.post('/username/verify',Auth.HospitalAdmin,function(req,res){
        try{
              var form = new formidable.IncomingForm();
              form.parse(req,function(err, fields, files) {
                        Laboratorydata.find({"username" : fields.LUName},{username:1,_id:0},function(err, data) {
                                      if (err)
                                            res.send(err);
                                      if(data=="")
                                      {
                                        res.json({       'status': 200,
                                                          'error': 'Available'
                                                });
                                      }
                                      else {
                                        res.json({       'status': 200,
                                                          'error': 'Already Registered'
                                                });
                                      }
                                    });
              });
         } catch (e) {
             tc.try_catch(e,res);
           }
    });

    router.post('/id/verify',Auth.HospitalAdmin,function(req,res){
        try{
                var form = new formidable.IncomingForm();
                form.parse(req,function(err, fields, files) {
                          Laboratorydata.find({"lid" : fields.LLic},{mid:1,_id:0},function(err, data) {

                                        if (err)
                                              res.send(err);
                                        if(data=="")
                                        {
                                          res.json({       'status': 200,
                                                            'error': 'Available'
                                                  });
                                        }
                                        else {
                                          res.json({       'status': 200,
                                                            'error': 'Already Registered'
                                                  });
                                        }
                                      });
                });
          } catch (e) {
              tc.try_catch(e,res);
            }
     });

    router.post('/registration',Auth.HospitalAdmin,function(req, res) {
        try{

                  var laboratorydata  = new Laboratorydata();
                  var data = "admin";
                  var form = new formidable.IncomingForm();
                  var pincode;
                  form.uploadDir = 'views/upload/';


                  form.parse(req,function(err, fields, files) {
                    laboratorydata.lid  = fields["LLic"];
                    file:
                    {
                      if(!files.file)
                      {
                      break file;
                      }
                    pincode = fields["LPin"];
                    var location = 'views/upload/laboratory/' + pincode;

                    mkDir.mkDir(location,res);

                    location = location  + "/" + laboratorydata.lid;
                    fs.mkdirSync(location);
                    files['file'].name = laboratorydata.lid + '.' + files['file'].name.split('.')[files['file'].name.split('.').length -1];
                    location = location + "/" + files['file'].name;
                    fs.rename(files['file'].path, location);
                    location = dir+'/upload/laboratory/' + pincode + "/" + laboratorydata.lid + "/" + files['file'].name;

                    laboratorydata.logo = location;
                  }
                  laboratorydata.mid  = fields["LLic"];
                  laboratorydata.name = fields["LName"];
                  laboratorydata.username =fields["LUName"];
                  laboratorydata.password = laboratorydata.generateHash(fields["LPass"]);
                  laboratorydata.est_date = fields["LEDate"];
                  laboratorydata.type = fields["LType"];
                  laboratorydata.description = fields["LDes"];
                  laboratorydata.contact      =  fields["Lcont"];

                            /*
                  for(key in Hcont )
                  {

                    hospitaldata.contact.push(Hcont[key]);
                  }*/
                  laboratorydata.email = fields["LMail"];
                  laboratorydata.category = fields["LCat"];
                  laboratorydata.fax = fields["LFax"];
                  laboratorydata.add.street = fields["LStreet"];
                  laboratorydata.add.l_mark = fields["LLand"];
                  laboratorydata.add.city = fields["LCity"];
                  laboratorydata.add.dist = fields["LDis"];
                  laboratorydata.add.state = fields["LState"];
                  laboratorydata.add.country = fields["LCoun"];
                  laboratorydata.add.pincode = fields["LPin"];
                  laboratorydata.location.x = fields["LLX"];
                  laboratorydata.location.y =fields["LLY"];
                  laboratorydata.title = fields["LTitle"];
                  if(req.session.user.hid)
                  {
                    laboratorydata.hospital = req.session.user.hid;
                    data = "hospital";
                  }

                      laboratorydata.save(function(err) {
                          if(err){

                            }
                            else {
                              res.json({       'status': 200,
                                            'error': 'Record Created...',
                                            'data': data
                                  });
                            }
                      });

                    })

                  form.on('error', function(err) {

                  request.resume();
                  });

                  form.on('aborted', function(err) {

                  });
          } catch (e) {
              tc.try_catch(e,res);
            }

      });

      router.post('/update',Auth.loginLaboratory,function(req,res){
          try{
                    var form = new formidable.IncomingForm();
                    form.uploadDir = 'views/upload/';

                    form.parse(req,function(err, fields, files) {
                      file:
                      {
                        if(fields.logo)
                        {
                        break file;
                        }
                        if(!files.logo)
                        {
                        fields.logo = "";
                        break file;
                        }

                        pincode = fields["pincode"];
                        var location = 'views/upload/laboratory/' + pincode;

                        mkDir.mkDir(location,res);


                        location = location  + "/" + req.session.user.lid;
                        mkDir.mkDir(location,res);

                        files['logo'].name = req.session.user.lid + '.' + files['logo'].name.split('.')[files['logo'].name.split('.').length -1];
                        location = location + "/" + files['logo'].name;

                        fs.rename(files['logo'].path, location);
                        location = dir+'/upload/laboratory/' + pincode + "/" + req.session.user.lid + "/" + files['logo'].name;
                        fields.logo = location;

                      }


                                      Laboratorydata.update({"_id" : req.session.user._id},{$set : {
                                                                                          'category' : fields.category,
                                                                                          'type' : fields.type,
                                                                                          'name' : fields.name,
                                                                                          'est_date' : fields.est_date,
                                                                                          'description' : fields.description,
                                                                                          'fax' : fields.fax,
                                                                                          'add.street' : fields.street,
                                                                                          'add.l_mark' : fields.l_mark,
                                                                                          'add.pincode' : fields.pincode,
                                                                                          'add.city' : fields.city,
                                                                                          'add.country' : fields.country,
                                                                                          'add.state' : fields.state,
                                                                                          'add.dist' : fields.dist,
                                                                                          'contact' : fields.contact,
                                                                                          'email' : fields.email,
                                                                                          'title' : fields.title,
                                                                                          'location.x' : fields.x,
                                                                                          'location.y' : fields.y,
                                                                                          'logo' : fields.logo

                                                                                          }},function(err, data) {
                                                                                                    if (err)
                                                                                                    res.send(err);
                                                                                                    res.json({       'status': 200,
                                                                                                                    'error': 'Profile Updated...',
                                                                                                                    'user_data': {}
                                                                                                                });

                                  });
                        });

            } catch (e) {
                tc.try_catch(e,res);
              }
      });

      router.post('/fees',Auth.loginLaboratory,function(req, res) {
          try{
                 Laboratorydata.update({"lid" : req.session.user.lid},{$set :    {'investigation_list' : req.body.investigation,
                                                                                    'emergency_fees' : req.body.emergency,
                                                                                     }},function(err, data) {
                                                                                      if (err){
                                                                                      res.send(err);}
                                                                                      else{

                                                                                        res.json({       'status': 200,
                                                                                                        'error': 'Fees Updated...',
                                                                                                        'user_data': {}
                                                                                                    });}
                                                                      }
                     );
          } catch (e) {
              tc.try_catch(e,res);
            }
      });





}
