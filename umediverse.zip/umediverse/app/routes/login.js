module.exports = function(router, passport) {

    // =====================================
    // HOME PAGE (with login links) ========
    // =====================================


     // process the login form
         router.post('/login', passport.authenticate('Admin-login', {
             successRedirect : '/admin', // redirect to the secure profile section
             failureRedirect : '/login' // redirect back to the signup page if there is an error
             //failureFlash : true // allow flash messages
         }));

        router.post('/plogin', passport.authenticate('Patient-login', {
            successRedirect : '/patient', // redirect to the secure profile section
            failureRedirect : '/plogin' // redirect back to the signup page if there is an error
            //failureFlash : true // allow flash messages
        }));

        router.post('/dlogin', passport.authenticate('Doctor-login', {
            successRedirect : '/doctor', // redirect to the secure profile section
            failureRedirect : '/dlogin' // redirect back to the signup page if there is an error
            //failureFlash : true // allow flash messages
        }));

        router.post('/hlogin', passport.authenticate('Hospital-login', {
            successRedirect : '/hospital', // redirect to the secure profile section
            failureRedirect : '/hlogin' // redirect back to the signup page if there is an error
            //failureFlash : true // allow flash messages
        }));

        router.post('/phlogin', passport.authenticate('Pharmacy-login', {
            successRedirect : '/pharmacy', // redirect to the secure profile section
            failureRedirect : '/phlogin' // redirect back to the signup page if there is an error
            //failureFlash : true // allow flash messages
        }));

        router.post('/slogin', passport.authenticate('Staff-login', {
            successRedirect : '/staff', // redirect to the secure profile section
            failureRedirect : '/slogin' // redirect back to the signup page if there is an error
            //failureFlash : true // allow flash messages
        }));

        router.post('/llogin', passport.authenticate('Laboratory-login', {
            successRedirect : '/laboratory', // redirect to the secure profile section
            failureRedirect : '/llogin' // redirect back to the signup page if there is an error
            //failureFlash : true // allow flash messages
        }));


    // =====================================
    // LOGOUT ==============================
    // =====================================
    router.get('/logout', function(req, res) {
      req.logout();
      req.session.destroy(function() {
            res.clearCookie('connect.sid');
            res.json({ 'status': 200,
                            'error': 'Logout successfully',})
          });
    });
};
