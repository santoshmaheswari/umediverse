var fs = require('fs');
var tc = require('./hub');


module.exports.mkDir = function (location,res) {
try{
  var stat = null;

  try {
        stat = fs.statSync(location);
  }
  catch (err) {
    fs.mkdirSync(location);
  }

  if (stat && !stat.isDirectory()) {
      throw new Error('Directory cannot be created because an inode of a different type exists at "' + dest + '"');
  }
} catch (e) {
    tc.try_catch(e,res);
  }

}
