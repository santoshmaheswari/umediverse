var Auth = require('./auth');
var server = require('../../server');
var mongoose = require('mongoose');
var formidable = require('formidable');
var mkDir = require('./mkdir');
var fs = require('fs');
var tc = require('./hub');

//var fse = require('fs-extra');

module.exports = function(router){
//localhost:8000/patient
    var Patientdata            = require('../models/patientDB');


    router.get('/all',function(req,res){
        try{

            Patientdata.find(function(err, data) {
                    if (err)
                        res.send(err);

                        res.json({'status':200,'data':data});

                });
            }catch (e) {
                tc.try_catch(e,res);
              }
    });

    router.get('/appointment/list',Auth.loginDoctor,function(req,res){
        try{
                var did,hid;
                var yesterday = new Date();
                yesterday.setDate(yesterday.getDate()-1);
                yesterday.setHours(0,0,0,0);
                var tomorrow = new Date();
                tomorrow.setDate(tomorrow.getDate()+1);
                tomorrow.setHours(0,0,0,1);
                if(req.session.user.did)
                {
                   did = req.session.user.did;
                }
                if(req.session.hid)
                {
                  hid = req.session.hid;
                }
                else if (req.session.user.hid) {
                  hid = req.session.user.hid;
                }

                Patientdata.aggregate( [{ $match: {"case_detail.doctor_id":did,"case_detail.hospital_id": hid}},
                                          {$project : {_id : 0,case_detail:1}},
                                        { $unwind: "$case_detail" },
                                        { $unwind: "$case_detail.visit_detail"},
                                          {$project : {_id : 0,"case_detail.doctor_id":1,"case_detail.hospital_id":1,"case_detail.visit_detail.app_date":1,"case_detail.visit_detail._id":1,"case_detail.visit_detail.is_visited":1}},
                                        { $match: {$and :[{ "case_detail.visit_detail.app_date" :{"$gt":yesterday,"$lt":tomorrow}},{"case_detail.doctor_id":did},{"case_detail.hospital_id":hid}]}},
                                        {$sort:{"case_detail.visit_detail.app_date":1}}
                                      ],function(err, data) {

                                         if (err){
                                          res.send(err);
                                        }
                                        else if(data)
                                        {
                                          res.json({       'status': 200,
                                                            'data': data
                                                      });
                                        }
                                        else {
                                          res.json({       'status': 500,
                                                            'data': ''
                                                      });
                                        }
                                        })
                }catch (e) {
                    tc.try_catch(e,res);
                  }
    });

    router.post('/staff/appointment/list',Auth.loginStaff,function(req,res){
        try{
              var yesterday = new Date();
              yesterday.setDate(yesterday.getDate()-1);
              yesterday.setHours(0,0,0,0);
              var tomorrow = new Date();
              tomorrow.setDate(tomorrow.getDate()+1);
              tomorrow.setHours(0,0,0,1);

              Patientdata.aggregate( [{ $match: {"case_detail.doctor_id" : req.body.did,"case_detail.hospital_id" : req.session.user[0].hid}},
                                        {$project : {_id : 0,case_detail:1,name:1,add:1,img:1,contact:1}},
                                      { $unwind: "$case_detail" },
                                      { $unwind: { path: "$case_detail.visit_detail", includeArrayIndex: "Index" }},
                                      { $match: { "case_detail.visit_detail.app_date" :{"$gt":yesterday,"$lt":tomorrow}}},
                                      {$sort:{"case_detail.visit_detail.app_date":1}}
                                    ],function(err, data) {
                                       if (err){
                                        res.send(err);}


                                        res.json({'status':200,'data':data});

                                      })
          }catch (e) {
              tc.try_catch(e,res);
            }
    });

    router.get('/case_history/data',Auth.loginPatient,function(req,res){
        try{
              id = mongoose.Types.ObjectId(req.session.user._id);
              Patientdata.aggregate( [{ $match: {_id : id}},
                                        {$project : {_id : 0,case_detail:1}},
                                      { $unwind: "$case_detail"},
                                      { $unwind: { path: "$case_detail.visit_detail", includeArrayIndex: "Index" }},
                                      {$sort:{"case_detail.visit_detail.app_date":-1}}
                                    ],function(err, data) {
                                       if (err){
                                        res.send(err);}

                                        res.json({'status':200,'data':data});

                                      })
            }catch (e) {
                tc.try_catch(e,res);
              }
    });

    router.get('/case_history/:appid',Auth.loginPatient,function(req,res){
        try{
              id = mongoose.Types.ObjectId(req.session.user._id);
              appid = mongoose.Types.ObjectId(req.params.appid);

              Patientdata.aggregate( [{ $match: {_id : id}},
                                        {$project : {_id : 0,case_detail:1}},
                                      { $unwind:{ path:"$case_detail", includeArrayIndex: "Index" }},
                                      { $match: { "case_detail.visit_detail._id" : appid}},
                                      {$sort:{"case_detail.visit_detail.app_date":-1}}
                                    ],function(err, data) {
                                       if (err){
                                        res.send(err);}

                                        res.json({       'status': 200,
                                                        'error': 'Data',
                                                        'data': data
                                                    });
                                      })
            }catch (e) {
                tc.try_catch(e,res);
              }
    });

    router.get('/data',Auth.loginPatient,function(req,res){

        try{
                Patientdata.find({"_id" : req.session.user._id},function(err, data) {
                              if (err)
                                    res.send(err);
                                    res.json({'status':200,'data':data});

                            });
            }catch (e) {
                tc.try_catch(e,res);
              }
    });

    router.post('/change_password',Auth.loginPatient,function(req,res){
        try{
            var patientdata  = new Patientdata();

                Patientdata.findOne({"_id" : req.session.user._id},function(err, user) {
                              if (err)
                                    res.send(err);
                                if (!user.validPassword(req.body.CPassword))
                                {
                                  res.json({       'status': 500,
                                                  'error': 'Incorrect Password Entered'
                                              });
                                }
                                else {

                                  Patientdata.update({"_id" : req.session.user._id},{$set : {'password' : patientdata.generateHash(req.body.NPassword)}},
                                                                                            function(err, data) {
                                                                                                      if (err)
                                                                                                      {res.send(err);}
                                                                                                      else {
                                                                                                        res.json({       'status': 200,
                                                                                                                        'error': 'Password successfully Changed...',
                                                                                                                        'user_data': {}
                                                                                                                    });
                                                                                                    }

                                          });

                                }
                                //res.json(data);
                            });
            }catch (e) {
                tc.try_catch(e,res);
              }
    });

    router.post('/username/verify',function(req,res){
        try{
              var form = new formidable.IncomingForm();
              form.parse(req,function(err, fields, files) {
                        Patientdata.find({"username" : fields.PUName},{username:1,_id:0},function(err, data) {
                                      if (err)
                                            res.send(err);
                                      if(data=="")
                                      {
                                        res.json({       'status': 200,
                                                          'error': 'Available'
                                                });
                                      }
                                      else {
                                        res.json({       'status': 200,
                                                          'error': 'Already Registered'
                                                });
                                      }
                                    });
              });
    }catch (e) {
        tc.try_catch(e,res);
      }
    });

    router.post('/contact/verify',function(req,res){
        try{

              var form = new formidable.IncomingForm();
              form.parse(req,function(err, fields, files) {

                        Patientdata.find({"contact" : fields.PMob},{contact:1,_id:0},function(err, data) {
                                      if (err)
                                            res.send(err);


                                      if(data=="")
                                      {
                                        res.json({       'status': 200,
                                                          'error': 'Available'
                                                });
                                      }
                                      else {
                                        res.json({       'status': 200,
                                                          'error': 'Already Registered'
                                                });
                                      }
                                    });
              });
    }catch (e) {
          tc.try_catch(e,res);
        }
    });

    router.post('/registration',function(req, res) {
        try{
        
                var patientdata  = new Patientdata();
                var form = new formidable.IncomingForm();
                var pincode;
                form.uploadDir = 'views/upload/';
                form.parse(req,function(err, fields, files) {

                file:
                {
                  if(!files.file)
                  {
                  break file;
                  }
                  pincode = fields["PPin"];
                  var location = 'views/upload/patient/' + pincode;
                  mkDir.mkDir(location,res);
                  location = location  + "/" + patientdata._id;
                  fs.mkdirSync(location);
                    patientdata.dir_name = location;
                  files['file'].name = patientdata._id + '.' + files['file'].name.split('.')[files['file'].name.split('.').length -1];
                  location = location + "/" + files['file'].name;
                  fs.rename(files['file'].path, location);
                  patientdata.img = dir+"/upload/patient/" + pincode + "/" + patientdata._id + "/" + files['file'].name;;
                }
                  patientdata.name.fname = fields["PFName"]
                  patientdata.name.mname = fields["PMName"];
                  patientdata.name.lname = fields["PLName"];
                  patientdata.username = fields["PUName"];
                  patientdata.password = patientdata.generateHash(fields["PPass"]);
                  patientdata.gender = fields["PGen"];
                  patientdata.bod = fields["PDob"];
                  patientdata.marital_status = fields["PMrg"];
                  patientdata.blood_group = fields["PBG"];
                  patientdata.contact = fields["PMob"];
                  patientdata.add.street = fields["PStreet"];
                  patientdata.add.l_mark = fields["PLand"];
                  patientdata.add.city = fields["PCity"];
                  patientdata.add.dist = fields["PDis"];
                  patientdata.add.state = fields["PState"];
                  patientdata.add.country = fields["PCoun"];
                  patientdata.add.pincode = fields["PPin"];
                  patientdata.email = fields["PMail"];
                  patientdata.emergency.ename = fields["PEName"];
                  patientdata.emergency.contact = fields["PECN"];
                  patientdata.emergency.relation = fields["PERel"];
                  patientdata.height = fields["PHeight"];
                  patientdata.weight = fields["PWeight"];
                  patientdata.occupation = fields["POcc"];
                  patientdata.income = fields["PInc"];

                patientdata.save(function(err) {
                    if (err)
                        {}
                        else {
                          res.json({       'status': 200,
                                            'error': 'Record Created...',
                                            'name':patientdata.name,
                                            'id':patientdata._id
                                  });
                        }
                });


              })

              form.on('error', function(err) {

                  request.resume();
              });

              form.on('aborted', function(err) {

              });


      }catch (e) {
          tc.try_catch(e,res);
        }

    });

        router.post('/update',Auth.loginPatient,function(req,res){
            try{
                  var form = new formidable.IncomingForm();
                  form.uploadDir = 'views/upload/';
                  form.parse(req,function(err, fields, files) {
                    file:
                    {
                      if(fields.img)
                      {
                      break file;
                      }
                      if(!files.img)
                      {
                      fields.img = "";
                      break file;
                      }
                      pincode = fields["pincode"];
                      var dir_name = 'views/upload/patient/' + pincode;
                      mkDir.mkDir(dir_name,res);
                       var location = dir_name  + "/" + req.session.user._id;
                      mkDir.mkDir(location,res);
                      files['img'].name = req.session.user._id + '.' + files['img'].name.split('.')[files['img'].name.split('.').length -1];
                      location = location + "/" + files['img'].name;
                      fs.rename(files['img'].path, location);
                      location = dir+'/upload/patient/' + pincode + "/" + req.session.user._id + "/" + files['img'].name;
                      fields.img = location;
                    }
                              Patientdata.update({"_id" : req.session.user._id},{$set : {'add.street' : fields.street,
                                                                                        'add.l_mark' : fields.l_mark,
                                                                                        'add.pincode' : fields.pincode,
                                                                                        'add.city' : fields.city,
                                                                                        'add.country' : fields.country,
                                                                                        'add.state' : fields.state,
                                                                                        'add.dist' : fields.dist,
                                                                                        'contact' : fields.contact,
                                                                                        'marital_status': fields.marital_status,
                                                                                        'email' : fields.email,
                                                                                        'occupation' : fields.occupation,
                                                                                        'income' : fields.income,
                                                                                        'weight' : fields.weight,
                                                                                        'height' : fields.height,
                                                                                        'gender' : fields.gender,
                                                                                        'name.fname' : fields.fname,
                                                                                        'name.mname' : fields.mname,
                                                                                        'name.lname' : fields.lname,
                                                                                        'bod' : fields.bod,
                                                                                        'blood_group' : fields.blood_group,
                                                                                        'dir_name' :dir_name,
                                                                                        'emergency.ename' : fields.ename,
                                                                                        'emergency.contact' : fields.econtact,
                                                                                        'emergency.relation' : fields.erelation,
                                                                                        'img' : fields.img
                                                                                        }},function(err, data) {
                                                                                                  if (err)
                                                                                                  {res.send(err);}
                                                                                                  else {
                                                                                                    res.json({       'status': 200,
                                                                                                                    'error': 'Profile Updated...',
                                                                                                                    'user_data': {}
                                                                                                                });
                                                                                                }

                                      });
                          });
              }catch (e) {
                  tc.try_catch(e,res);
                }
        });

        router.post('/treatment/data/insert',Auth.loginDoctor,function(req,res){
            try{

                    var co = req.body.DTCO;
                    var report = req.body.DTRep;
                    var advise = req.body.DTAdv;
                    var dignosis = req.body.DTDig;
                    var additional = req.body.DTCOADD;
                    var duration = req.body.DTCODU;
                    var med_names = req.body.DTMedName;
                    var med_food = req.body.DTMedFood;
                    var med_timeM = req.body.DTMedTimeM;
                    var med_timeA = req.body.DTMedTimeA;
                    var med_timeE = req.body.DTMedTimeE;
                    var med_timeN = req.body.DTMedTimeN;
                    var med_day = req.body.DTMedDay;
                    var exam = req.body.Exam;
                    var examination = [];
                    var past = [];
                    var family = [];
                    var drug = [];
                    var personal = [];

                    if(co != null)
                    {
                      var co = Object.keys(co).filter(function(k){return co[k]});
                      var tco = new Array();
                      if(additional == null)
                      {
                        co.forEach(function(cos) {
                          tco.push({'name' : cos,'duration' : duration[cos]})
                      });
                      }
                      else {
                        co.forEach(function(cos) {
                          if(additional[cos] != null ) {
                            tco.push({'name' : cos,'duration' : duration[cos],'additional' : additional[cos]});
                          }
                        });
                      }
                    }
                    if(report != null)
                    {
                      var report = Object.keys(report).filter(function(k){return report[k]});
                      var treport = new Array();
                      report.forEach(function(reports) {
                          treport.push({'name' : reports});
                      });
                    }
                    if(advise != null)
                    {
                      var advise = Object.keys(advise).filter(function(k){return advise[k]});
                    }
                    if(dignosis != null)
                    {
                      var dignosis = Object.keys(dignosis).filter(function(k){return dignosis[k]});
                    }
                    if(med_names != null)
                    {
                        var length=0;
                        for(key in med_names)
                        {
                          length++;
                        }

                        var time=new Array(length);
                        var tmed = new Array();
                        for(i=0;i<length;i++)
                        {
                          time[i]=new Array();
                        }
                        for(i=0;i<length;i++)
                        {
                          if(med_timeM != null && med_timeM[i] != null)
                          {
                            time[i].push(med_timeM[i]);
                          }
                          if(med_timeA != null && med_timeA[i] != null)
                          {
                            time[i].push(med_timeA[i]);
                          }
                          if(med_timeE != null && med_timeE[i] != null)
                          {
                            time[i].push(med_timeE[i]);
                          }
                          if(med_timeN != null && med_timeN[i] != null)
                          {
                            time[i].push(med_timeN[i]);
                          }

                        }
                        for(i in med_names) {
                          tmed.push({'name' : med_names[i],'food' : med_food[i],'days':med_day[i],'time':time[i]});
                        }
                      }

                    for(key in exam)
                    {

                      if(exam[key] != null)
                      {
                                      examination.push({'name' : key,'status':exam[key]})
                      }
                    }


                    Patientdata.update({"case_detail.visit_detail._id" : req.body.AID},{$set : {"case_detail.$.visit_detail.0.treatment.co" : tco,
                                                                                                "case_detail.$.visit_detail.0.treatment.examination" : examination,
                                                                                                "case_detail.$.visit_detail.0.treatment.report" : treport,
                                                                                                "case_detail.$.visit_detail.0.treatment.dignosis" : dignosis,
                                                                                                "case_detail.$.visit_detail.0.treatment.advise" : advise,
                                                                                                "case_detail.$.visit_detail.0.treatment.medicine" : tmed,
                                                                                                "case_detail.$.visit_detail.0.treatment.comment" : req.body.DTCom,
                                                                                                "case_detail.$.visit_detail.0.is_visited" : "Yes",
                                                                                                "case_detail.$.visit_detail.0.next_visit" :req.body.DTNApp,
                                                                                                "history.past" : req.body.past,
                                                                                                "history.family" : req.body.family,
                                                                                                "history.drug" : req.body.drug,
                                                                                                "history.personal" : req.body.personal}},function(err, data) {
                                                                                                    if (err){
                                                                                                    res.send(err);}
                                                                                                    else {

                                                                                                      res.json({       'status': 200,
                                                                                                                      'error': 'Record Updated...',
                                                                                                                      'user_data': {}
                                                                                                                  });
                                                                                                    }
                    });
                  } catch (e) {
                      tc.try_catch(e,res);
                    }
                  });



}
