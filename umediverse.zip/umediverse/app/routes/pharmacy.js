var Auth = require('./auth');
var formidable = require('formidable');
var mongoose = require('mongoose');
var fs = require('fs');
var mkDir = require('./mkdir');
var tc = require('./hub');


module.exports = function(router){
//localhost:8000/pharmacy
    var Pharmacydata            = require('../models/pharmacyDB');
    var Patientdata            = require('../models/patientDB');

    router.get('/all',function(req,res){
      try{
              Pharmacydata.find(function(err, data) {
                      if (err)
                          res.send(err);

                          res.json({'status':200,'data':data});

                  });
              }catch (e) {
                    tc.try_catch(e,res);
                  }
    });

    router.get('/data',Auth.loginPharmacy,function(req,res){
      try{

          Pharmacydata.find({"_id" : req.session.user._id},{"password":0},function(err, data) {
                      if (err)
                          res.send(err);
                          res.json({'status':200,'data':data});

          });
      }catch (e) {
          tc.try_catch(e,res);
        }
    });

    router.get('/patient/data',Auth.loginPharmacy,function(req,res){
      try{
            var yesterday = new Date();
            yesterday.setDate(yesterday.getDate()-1);
            yesterday.setHours(0,0,0,0);
            var tomorrow = new Date();
            tomorrow.setDate(tomorrow.getDate()+1);
            tomorrow.setHours(0,0,0,1);
            Patientdata.aggregate( [{ $match: {"case_detail.hospital_id" : req.session.user.hospital}},
                                      {$project : {_id : 0,case_detail:1,name:1,gender : 1,"add.city" : 1}},
                                    { $unwind: "$case_detail" },
                                    { $unwind: { path: "$case_detail.visit_detail", includeArrayIndex: "Index"}},
                                    {$project : {_id : 0, "case_detail.visit_detail.app_date":1,"case_detail.visit_detail._id":1,
                                    "case_detail.doctor_id":1,name:1,gender : 1,"add.city":1}},
                                    { $match: { "case_detail.visit_detail.app_date" :{"$gt":yesterday,"$lt":tomorrow}}},
                                    {$sort:{"case_detail.visit_detail.app_date":1}}
                                  ],function(err, data) {
                                     if (err){
                                      res.send(err);}

                                      res.json({'status':200,'data':data});

                                    });
          }catch (e) {
              tc.try_catch(e,res);
            }
    });

    router.get('/patient/data/s/:id',Auth.loginPharmacy,function(req,res){
      try{
            id = mongoose.Types.ObjectId(req.params.id);
            Patientdata.aggregate( [{ $match: {"case_detail.visit_detail._id" : id}},
                                    { $project : {_id : 0,name:1,case_detail:1,bod : 1,
                                                    gender : 1,contact : 1,"add.city":1}},
                                    { $unwind: "$case_detail" },
                                    { $unwind:  { path:"$case_detail.visit_detail", includeArrayIndex: "Index" }},
                                    { $match: { "case_detail.visit_detail._id" : id}},
                                    { $project : {_id : 0,name:1,"case_detail.doctor_id":1,"case_detail.hospital_id":1,
                                              "case_detail.visit_detail.app_date":1,"case_detail.visit_detail._id":1,
                                              "case_detail.visit_detail.treatment.medicine": 1 , bod : 1,gender : 1,contact : 1,"add.city":1
                                            }}]
                                              ,function(err, data) {if (err){
                                      res.send(err);}
                                      else {
                                        res.json({       'status': 200,
                                                        'error': 'Data',
                                                        'data': data
                                                    });
                                      }
                                    });
        }catch (e) {
            tc.try_catch(e,res);
          }
    });

    router.post('/change_password',Auth.loginPharmacy,function(req,res){
      try{
            var Pharmacydata  = new Pharmacydata();

                Pharmacydata.findOne({"_id" : req.session.user._id},function(err, user) {
                              if (err)
                                    res.send(err);
                                if (!user.validPassword(req.body.CPassword))
                                {
                                  res.json({       'status': 500,
                                                  'error': 'Incorrect Password Entered'
                                              });
                                }
                                else {

                                  Pharmacydata.update({"_id" : req.session.user._id},{$set : {'password' : Pharmacydata.generateHash(req.body.NPassword)}},
                                                                                            function(err, data) {
                                                                                                      if (err)
                                                                                                      {res.send(err);}
                                                                                                      else {
                                                                                                        res.json({       'status': 200,
                                                                                                                        'error': 'Password successfully Changed...',
                                                                                                                        'user_data': {}
                                                                                                                    });
                                                                                                    }

                                          });

                                }
                                //res.json(data);
                            });
        }catch (e) {
            tc.try_catch(e,res);
          }
    });



    router.post('/username/verify',Auth.HospitalAdmin,function(req,res){
      try{
            var form = new formidable.IncomingForm();
            form.parse(req,function(err, fields, files) {
                      Pharmacydata.find({"username" : fields.PUName},{username:1,_id:0},function(err, data) {
                                    if (err)
                                          res.send(err);
                                    if(data=="")
                                    {
                                      res.json({       'status': 200,
                                                        'error': 'Available'
                                              });
                                    }
                                    else {
                                      res.json({       'status': 500,
                                                        'error': 'Already Registered'
                                              });
                                    }
                                  });
                                });
        }catch (e) {
            tc.try_catch(e,res);
          }
    });

    router.post('/id/verify',Auth.HospitalAdmin,function(req,res){
      try{
            var form = new formidable.IncomingForm();
            form.parse(req,function(err, fields, files) {
                      Pharmacydata.find({"pid" : fields.PLic},{pid:1,_id:0},function(err, data) {

                                    if (err)
                                          res.send(err);
                                    if(data=="")
                                    {
                                      res.json({       'status': 200,
                                                        'error': 'Available'
                                              });
                                    }
                                    else {
                                      res.json({       'status': 500,
                                                        'error': 'Already Registered'
                                              });
                                    }
                                  });
                                });
          }catch (e) {
              tc.try_catch(e,res);
            }
    });

    router.post('/registration',Auth.HospitalAdmin,function(req, res) {
      try{
            var pharmacydata  = new Pharmacydata();
            var data = "admin";
            var form = new formidable.IncomingForm();
            var pincode;
            form.uploadDir = 'views/upload/';


            form.parse(req,function(err, fields, files) {

              pharmacydata.pid  = fields["PLic"];
              file:
              {
                if(!files.file)
                {
                break file;
                }
              pincode = fields["PPin"];
              var location = 'views/upload/pharmacy/' + pincode;

              mkDir.mkDir(location,res);

              location = location  + "/" + pharmacydata.pid;
              fs.mkdirSync(location);
              files['file'].name = pharmacydata.pid + '.' + files['file'].name.split('.')[files['file'].name.split('.').length -1];
              location = location + "/" + files['file'].name;
              fs.rename(files['file'].path, location);
              location = dir+'/upload/pharmacy/' + pincode + "/" + pharmacydata.pid + "/" + files['file'].name;

              pharmacydata.logo = location;
            }
            pharmacydata.pid  = fields["PLic"];
            pharmacydata.name = fields["PName"];
            pharmacydata.username =fields["PUName"];
            pharmacydata.password = pharmacydata.generateHash(fields["PPass"]);
            pharmacydata.est_date = fields["PEDate"];
            pharmacydata.type = fields["PType"];
            pharmacydata.description = fields["PDes"];
            pharmacydata.contact      =  fields["Pcont"];

                      /*
            for(key in Hcont )
            {

              hospitaldata.contact.push(Hcont[key]);
            }*/
            pharmacydata.email = fields["PMail"];
            pharmacydata.category = fields["PCat"];
            pharmacydata.fax = fields["PFax"];
            pharmacydata.add.street = fields["PStreet"];
            pharmacydata.add.l_mark = fields["PLand"];
            pharmacydata.add.city = fields["PCity"];
            pharmacydata.add.dist = fields["PDis"];
            pharmacydata.add.state = fields["PState"];
            pharmacydata.add.country = fields["PCoun"];
            pharmacydata.add.pincode = fields["PPin"];
            pharmacydata.location.x = fields["PLX"];
            pharmacydata.location.y =fields["PLY"];
            pharmacydata.title = fields["PTitle"];
            if(req.session.user.hid)
            {
              pharmacydata.hospital = req.session.user.hid;
              data = "hospital";
            }

                pharmacydata.save(function(err) {
                    if(err){

                      }
                      else {
                        res.json({       'status': 200,
                                      'error': 'Record Created...',
                                      'data': data
                            });
                      }
                });

              })

            form.on('error', function(err) {

            request.resume();
            });

            form.on('aborted', function(err) {

            });

          }catch (e) {
              tc.try_catch(e,res);
            }
      });

      router.post('/update',Auth.loginPharmacy,function(req,res){
        try{
                var form = new formidable.IncomingForm();
                form.uploadDir = 'views/upload/';

                form.parse(req,function(err, fields, files) {
                  file:
                  {
                    if(fields.logo)
                    {
                    break file;
                    }
                    if(!files.logo)
                    {
                    fields.logo = "";
                    break file;
                    }

                    pincode = fields["pincode"];
                    var location = 'views/upload/pharmacy/' + pincode;

                    mkDir.mkDir(location,res);


                    location = location  + "/" + req.session.user.pid;
                    mkDir.mkDir(location,res);

                    files['logo'].name = req.session.user.pid + '.' + files['logo'].name.split('.')[files['logo'].name.split('.').length -1];
                    location = location + "/" + files['logo'].name;

                    fs.rename(files['logo'].path, location);
                    location = dir+'/upload/pharmacy/' + pincode + "/" + req.session.user.pid + "/" + files['logo'].name;
                    fields.logo = location;

                  }


                                  Pharmacydata.update({"_id" : req.session.user._id},{$set : {
                                                                                      'category' : fields.category,
                                                                                      'name' : fields.name,
                                                                                      'est_date' : fields.est_date,
                                                                                      'type' : fields.type,
                                                                                      'description' : fields.description,
                                                                                      'fax' : fields.fax,
                                                                                      'add.street' : fields.street,
                                                                                      'add.l_mark' : fields.l_mark,
                                                                                      'add.pincode' : fields.pincode,
                                                                                      'add.city' : fields.city,
                                                                                      'add.country' : fields.country,
                                                                                      'add.state' : fields.state,
                                                                                      'add.dist' : fields.dist,
                                                                                      'contact' : fields.contact,
                                                                                      'email' : fields.email,
                                                                                      'title' : fields.title,
                                                                                      'location.x' : fields.x,
                                                                                      'location.y' : fields.y,
                                                                                      'logo' : fields.logo

                                                                                      }},function(err, data) {
                                                                                                if (err)
                                                                                                res.send(err);
                                                                                                res.json({       'status': 200,
                                                                                                                'error': 'Profile Updated...',
                                                                                                                'user_data': {}
                                                                                                            });

                              });
                    });
          }catch (e) {
              tc.try_catch(e,res);
            }
      });






}
