var Auth = require('./auth');
var mongoose = require('mongoose');
var email_verification = require('./email_verification');

module.exports = function(router){
//localhost:8000/reset

    router.get('/s/patient/:token',function(req,res,next){
            email_verification.reset_verify(req,res,next);
    });

    router.post('/s/hospital/:token',function(req,res,next){
            email_verification.reset(req,res,next);
    });

    router.post('/s/pharmacy/:token',function(req,res,next){
            email_verification.reset(req,res,next);
    });

    router.post('/s/doctor/:token',function(req,res,next){
            email_verification.reset(req,res,next);
    });

    router.post('/s/laboratory/:token',function(req,res,next){
            email_verification.reset(req,res,next);
    });
    router.post('/s/admin/:token',function(req,res,next){
            email_verification.reset(req,res,next);
    });

    router.post('/s/password',function(req,res,next){
            email_verification.reset(req,res,next);
    });

}
