const Nexmo = require('nexmo');
const nexmo = new Nexmo({
  apiKey: "868f8ce2",
  apiSecret: "4e2ad9194c7dab9c"
});

nexmo.message.sendSms(
    '917016272752', '917016272752', 'yo',
      (err, responseData) => {
        if (err) {
          console.log(err);
        } else {
          console.dir(responseData);
        }
      }
   );
