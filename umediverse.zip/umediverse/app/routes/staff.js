
var Auth = require('./auth');
var formidable = require('formidable');
var fs = require('fs');
var mkDir = require('./mkdir');
var tc = require('./hub');


module.exports = function(router){
//localhost:8000/staff
    var Staffdata            = require('../models/staffDB');
    var Hospitaldata            = require('../models/hospitalDB');
    var Patientdata            = require('../models/patientDB');


    router.get('/all',function(req,res){
        try{
            Staffdata.find(function(err, data) {
                    if (err)
                        res.send(err);
                        res.json({'status':200,'data':data});

            });
          }catch (e) {
              tc.try_catch(e,res);
            }
    });

   router.get('/data',Auth.loginHospital,function(req,res){
       try{
            Staffdata.find({hospital_id : req.session.user._id},{name : 1},function(err, data) {
                    if (err)
                        res.send(err);

                        res.json({'status':200,'data':data});

                });
        }catch (e) {
            tc.try_catch(e,res);
          }
    });

    router.post('/hospital/data/',Auth.loginHospital,function(req,res){
        try{
            Staffdata.find({"_id" : {$in:req.body.sid}},{name : 1,img:1,email:1,contact:1},function(err, data) {
                    if (err){
                        res.send(err);}
                        res.json({'status':200,'data':data});

            });
        }catch (e) {
            tc.try_catch(e,res);
          }
    });

    router.post('/change_password',Auth.loginStaff,function(req,res){
        try{
              var hospitaldata  = new Hospitaldata();
              Hospitaldata.aggregate( [{ $match: {'hid' : req.session.user[0].hid}},
                                   { $unwind: "$auth" },
                                   {$project: {_id:0,hid:1,auth:1}},
                                   { $match: {'auth.username' : req.session.user[0].auth.username}}
                                 ],function(err, user) {



                  if (!hospitaldata.validStaffPassword(user[0],req.body.CPassword))
                      {
                                          res.json({       'status': 500,
                                                          'error': 'Incorrect Password Entered'
                                                      });
                                        }
                                        else {

                                          Hospitaldata.update({"hid" : req.session.user[0].hid,'auth.username' : req.session.user[0].auth.username},{$set : {'auth.$.password' : hospitaldata.generateHash(req.body.NPassword)}},
                                                                                                    function(err, data) {
                                                                                                              if (err)
                                                                                                              {res.send(err);}
                                                                                                              else {
                                                                                                                res.json({       'status': 200,
                                                                                                                                'error': 'Password successfully Changed...',
                                                                                                                                'user_data': {}
                                                                                                                            });
                                                                                                            }

                                                  });

                                        }
                                        //res.json(data);
                                    });
        }catch (e) {
            tc.try_catch(e,res);
          }
    });

    router.get('/patient/investigation/data',Auth.loginStaff,function(req,res){
        try{
            Patientdata.aggregate( [{ $match: {"case_detail":{$elemMatch:{"hospital_id":  req.session.user[0].hid}}}},
                                      {$project : {name:1,case_detail:1,img:1,dir_name:1}},
                                      { $unwind: "$case_detail" },
                                      { $unwind:  "$case_detail.visit_detail"},
                                      {$project : {name:1,dir_name:1,"case_detail.doctor_id":1,"case_detail.hospital_id":1,"case_detail._id":1,"case_detail.visit_detail._id":1,"case_detail.visit_detail.app_date":1,"case_detail.visit_detail.treatment.report":1,img:1}},
                                      { $match: {$and :[{"case_detail.visit_detail.treatment.report" :{$ne:[]}},{"case_detail.visit_detail.treatment.report.img" :null},{"case_detail.visit_detail.treatment.report._id" :{ $exists: true}},
                                                      {"case_detail.hospital_id":  req.session.user[0].hid}]}},
                                  ],function(err, data) {
                                     if (err){
                                      res.send(err);}
                                      else {

                                        res.json({       'status': 200,
                                                        'error': 'Data',
                                                        'data': data
                                                    });
                                      }


                                    });
            }catch (e) {
                tc.try_catch(e,res);
              }
    });

    router.post('/patient/investigation/upload',Auth.loginStaff,function(req,res){
        try{
              var form = new formidable.IncomingForm();
              form.uploadDir = 'views/upload/';

              form.parse(req,function(err, fields, files) {
                files['img'].name = fields.PInv + '.' + files['img'].name.split('.')[files['img'].name.split('.').length -1];
                location = fields.dir_name + "/" + files['img'].name;
                fs.rename(files['img'].path, location);
                location = dir+'/upload/patient/' + fields['dir_name'].split('/')[fields['dir_name'].split('/').length -2] + "/" + fields.id + "/" + files['img'].name;
                fields.img = location;
                           Patientdata.findById(fields.id,function(err,data){
                        if(err)
                        {
                          res.send(err);
                        }
                        else {
                          var t = data.case_detail.id(fields.case).visit_detail.id(fields.visit).treatment.report.id(fields.PInv);
                          t.laboratory_name = fields.LabName;
                          t.laboratory_id = fields.LabId;
                          t.img = fields.img;
                          data.save();
                          res.json({       'status': 200,
                                          'error':'successfully Uploaded!!!!',
                                          'user_data': {}
                                      });
                        }


                      })
                  });
        }catch (e) {
            tc.try_catch(e,res);
          }
        });


    router.post('/registration',Auth.loginHospital,function(req, res) {
        try{
              var staffdata  = new Staffdata();
                  //patientdata._id
                  var form = new formidable.IncomingForm();
                  var pincode;
                  form.uploadDir = 'views/upload/';
                  form.parse(req,function(err, fields, files) {
                    file:
                    {
                      if(!files.file)
                      {
                      break file;
                      }
                    pincode = fields["SPin"];
                    var location = 'views/upload/staff/' + pincode;

                    mkDir.mkDir(location,res);


                    location = location  + "/" + staffdata._id;
                    fs.mkdirSync(location);
                    files['file'].name = staffdata._id + '.' + files['file'].name.split('.')[files['file'].name.split('.').length -1];
                    location = location + "/" + files['file'].name;
                    fs.rename(files['file'].path, location);
                    location = dir+'/upload/staff/' + pincode + "/" + staffdata._id + "/" + files['file'].name;

                    staffdata.img = location;
                  }
                  staffdata.name.fname = fields.SFName;
                  staffdata.name.mname = fields.SMName;
                  staffdata.name.lname = fields.SLName;
                  staffdata.dob = fields.SDob;
                  staffdata.qualification = fields.SQual;
                  staffdata.gender = fields.SGen;
                  staffdata.marital_status = fields.SMrg;
                  staffdata.blood_group = fields.SBG;
                  staffdata.contact = fields.SMob;
                  staffdata.email = fields.SMail;
                  staffdata.add.street = fields.SStreet;
                  staffdata.add.l_mark = fields.SLand;
                  staffdata.add.city = fields.SCity;
                  staffdata.add.pincode = fields.SPin;
                  staffdata.reference.name = fields.SEName;
                  staffdata.reference.contact = fields.SECN;
                  staffdata.reference.relation = fields.SERel;

                    staffdata.hospital_id = req.session.user._id;

                  staffdata.save(function(err) {
                      if (err)
                          {res.send(err);}
                      else {
                        res.json({       'status': 200,
                                        'error': 'Staff Record Created...',
                                        'user_data': {}
                                    });
                      }

                  }
                );
                });
        }catch (e) {
            tc.try_catch(e,res);
          }
        });
        router.post('/update',Auth.loginHospital,function(req,res){
            try{
                var form = new formidable.IncomingForm();
                form.uploadDir = 'views/upload/';

                form.parse(req,function(err, fields, files) {

                  file:
                  {
                    if(fields.img)
                    {
                    break file;
                    }
                    if(!files.img)
                    {
                    fields.img = "";
                    break file;
                    }

                    pincode = fields["pincode"];
                    var location = 'views/upload/staff/' + pincode;

                    mkDir.mkDir(location,res);


                    location = location  + "/" + fields._id;
                    mkDir.mkDir(location,res);

                    files['img'].name = fields._id + '.' + files['img'].name.split('.')[files['img'].name.split('.').length -1];
                    location = location + "/" + files['img'].name;

                    fs.rename(files['img'].path, location);
                    location = dir+'/upload/staff/' + pincode + "/" + fields._id + "/" + files['img'].name;
                    fields.img = location;

                  }


                            Staffdata.update({"_id" : fields._id},{$set : {'add.street' : fields.street,
                                                                                      'add.l_mark' : fields.l_mark,
                                                                                      'add.pincode' : fields.pincode,
                                                                                      'add.city' : fields.city,
                                                                                      'add.country' : fields.country,
                                                                                      'add.state' : fields.state,
                                                                                      'add.dist' : fields.dist,
                                                                                      'contact' : fields.contact,
                                                                                      'marital_status': fields.marital_status,
                                                                                      'email' : fields.email,
                                                                                      'dob' : fields.dob,
                                                                                      'name.fname' : fields.fname,
                                                                                      'name.mname' : fields.mname,
                                                                                      'name.lname' : fields.lname,
                                                                                      'blood_group' : fields.blood_group,

                                                                                      'qualification' : fields.qualification,
                                                                                      'reference.name' : fields.rname,
                                                                                      'reference.contact' : fields.rcontact,
                                                                                      'reference.relation' : fields.rrelation,
                                                                                      'img' : fields.img
                                                                                      }},function(err, data) {

                                                                                                if (err)
                                                                                                {res.send(err);}

                            });
                            Hospitaldata.update({"_id" : req.session.user._id,"staff" :{$elemMatch:{"_id":fields._id,"is_present":true}}},{$set : {"staff.$.salary" : fields.salary,
                                                                                             "staff.$.designation" : fields.designation}},function(err, data) {
                                                                                              if (err){
                                                                                              res.send(err);}


                                                                              }
                             );
                             res.json({       'status': 200,
                                             'error': 'Staff Profile Updated...',
                                             'user_data': {}
                                         });


                        });
              }catch (e) {
                  tc.try_catch(e,res);
                }
        });

}
