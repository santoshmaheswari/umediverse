var Auth = require('./auth');
var tc = require('./hub');

module.exports = function(router){
//localhost:8000/treatment
    var Treatmentdata            = require('../models/treatmentDB');

    router.get('/category',function(req,res){
        try{
            Treatmentdata.find({},{category : 1,_id:0},function(err, data) {
                    if (err)
                        res.send(err);

                        res.json({'status':200,'data':data});

                });
            }catch (e) {
                  tc.try_catch(e,res);
            }

    });

    router.get('/data',function(req,res){
        try{
            Treatmentdata.find(function(err, data) {
                    if (err)
                        res.send(err);

                        res.json({'status':200,'data':data});

                });
            }catch (e) {
                  tc.try_catch(e,res);
            }
    });

    router.get('/data/:D_category',function(req,res){
        try{
            Treatmentdata.find({category : req.params.D_category},{_id : 0},function(err, data) {
                    if (err)
                        res.send(err);

                        res.json({'status':200,'data':data});

                });
          }catch (e) {
                tc.try_catch(e,res);
          }
    });

    router.post('/category',Auth.loginAdmin,function(req, res) {
        try{
              var treatmentdata  = new Treatmentdata();

                  treatmentdata.category = req.body.DCategory;


                  treatmentdata.save(function(err) {
                      if (err)
                          res.send(err);
                      res.redirect('/admin/treatment_data');

                  });
          }catch (e) {
            res.redirect('/admin/treatment_data');


          }


        });

        router.post('/co',Auth.loginAdmin,function(req, res) {
            try{
                  if(req.body.TCO != null)
                  {


                    Treatmentdata.update({"category" : req.body.DC},{$push : {"treatment.co" :

                                                                                    {'name' : req.body.TCO}}},function(err, data) {
                                                                                      if (err){
                                                                                      res.send(err);}
                                                                                      else{
                                                                                        res.json({       'status': 200,
                                                                                                        'error': 'Record Updated...',
                                                                                                        'user_data': {}
                                                                                                    });

                                                                      }
                     });
                   }
                 }catch (e) {
                       tc.try_catch(e,res);
                 }
        });

        router.post('/history/family',Auth.loginAdmin,function(req, res) {
            try{
                  if(req.body.THF != null)
                  {


                    Treatmentdata.update({"category" : req.body.DC},{$addToSet : {"treatment.history.family" : req.body.THF}},function(err, data) {
                                                                                      if (err){
                                                                                      res.send(err);}
                                                                                      else{
                                                                                        res.json({       'status': 200,
                                                                                                        'error': 'Record Updated...',
                                                                                                        'user_data': {}
                                                                                                    });

                                                                      }
                     });
                   }
                }catch (e) {
                      tc.try_catch(e,res);
                }
        });

        router.post('/history/personal',Auth.loginAdmin,function(req, res) {
            try{
                if(req.body.THP != null)
                {


                  Treatmentdata.update({"category" : req.body.DC},{$addToSet : {"treatment.history.personal" : req.body.THP}},function(err, data) {
                                                                                    if (err){
                                                                                    res.send(err);}
                                                                                    else{
                                                                                      res.json({       'status': 200,
                                                                                                      'error': 'Record Updated...',
                                                                                                      'user_data': {}
                                                                                                  });

                                                                    }
                   });
                 }
              }catch (e) {
                    tc.try_catch(e,res);
              }
        });

        router.post('/report',Auth.loginAdmin,function(req, res) {
            try{
                if(req.body.TRep != null)
                {
                 Treatmentdata.update({"category" : req.body.DC},{$addToSet : {"treatment.report" : req.body.TRep}},function(err, data) {
                                                                             if (err){
                                                                             res.send(err);}
                                                                             else{
                                                                               res.json({       'status': 200,
                                                                                               'error': 'Record Updated...',
                                                                                               'user_data': {}
                                                                                           });

                                                                    }
                   });
                 }
               }catch (e) {
                     tc.try_catch(e,res);
               }
        });

        router.post('/dignosis',Auth.loginAdmin,function(req, res) {
            try{
                  if(req.body.TDig != null)
                  {
                  Treatmentdata.update({"category" : req.body.DC},{$addToSet : {"treatment.dignosis" : req.body.TDig}},function(err, data) {
                                                                                  if (err){
                                                                                  res.send(err);}
                                                                                  else{
                                                                                    res.json({       'status': 200,
                                                                                                    'error': 'Record Updated...',
                                                                                                    'user_data': {}
                                                                                                });
                                                                    }
                     });
                  }
              }catch (e) {
                    tc.try_catch(e,res);
              }
        });

        router.post('/advise',Auth.loginAdmin,function(req, res) {
            try{
                if(req.body.TAdv != null)
                {
                Treatmentdata.update({"category" : req.body.DC},{$addToSet : {"treatment.advise" : req.body.TAdv}},function(err, data) {
                                                                                  if (err){
                                                                                  res.send(err);}
                                                                                  else{
                                                                                    res.json({       'status': 200,
                                                                                                    'error': 'Record Updated...',
                                                                                                    'user_data': {}
                                                                                                });
                                                                  }
                   });
                 }
              }catch (e) {
                    tc.try_catch(e,res);
              }
        });

        router.delete('/category/:D_category',Auth.loginAdmin,function(req, res) {
            try{
                  Treatmentdata.remove({category : req.params.D_category},function(err, data) {
                                                                            if (err){
                                                                            res.send(err);}
                                                                            else{
                                                                              res.json({       'status': 200,
                                                                                              'error': 'Record Deleted...',
                                                                                              'user_data': {}
                                                                                          });
                                                                    }
                     });
              }catch (e) {
                    tc.try_catch(e,res);
              }
        });

        router.post('/co/delete',Auth.loginAdmin,function(req, res) {
            try{

                  var cos = req.body.TLCo;
                    if( Object.prototype.toString.call( cos ) === '[object Array]' ) {
                    cos.forEach(function(co) {
                    Treatmentdata.update({"category" : req.body.DC},{$pull : {"treatment.co" :
                                                                                    {'name' : co}}},function(err, data) {
                                                                                      if (err){
                                                                                      res.send(err);}

                                                                      }
                     );
                   });
                 }
                 else {
                   Treatmentdata.update({"category" : req.body.DC},{$pull : {"treatment.co" :
                                                                                   {'name' : cos}}},function(err, data) {
                                                                                     if (err){
                                                                                     res.send(err);}

                                                                     }
                    );
                 }
                   res.redirect('/admin/treatment_data');
              }catch (e) {
                res.redirect('/admin/treatment_data');


              }
        });

        router.post('/history/family/delete',Auth.loginAdmin,function(req, res) {
            try{

                var familys = req.body.TLHF;

                  if( Object.prototype.toString.call( familys ) === '[object Array]' ) {
                familys.forEach(function(family) {
                 Treatmentdata.update({"category" : req.body.DC},{$pull : {"treatment.history.family" : family}},function(err, data) {
                                                                             if (err){
                                                                             res.send(err);}
                                                              }
                   );
                 });
               }
               else {
                 Treatmentdata.update({"category" : req.body.DC},{$pull : {"treatment.history.family" : familys}},function(err, data) {
                                                                             if (err){
                                                                             res.send(err);}
                                                                    }
                   );
               }
                 res.redirect('/admin/treatment_data');
            }catch (e) {
              res.redirect('/admin/treatment_data');


            }

        });

        router.post('/history/personal/delete',Auth.loginAdmin,function(req, res) {
            try{

                var personals = req.body.TLHP;

                  if( Object.prototype.toString.call( personals ) === '[object Array]' ) {
                personals.forEach(function(personal) {
                 Treatmentdata.update({"category" : req.body.DC},{$pull : {"treatment.history.personal" : personal}},function(err, data) {
                                                                             if (err){
                                                                             res.send(err);}

                                                                    }
                   );
                 });
               }
               else {
                 Treatmentdata.update({"category" : req.body.DC},{$pull : {"treatment.history.personal" : personals}},function(err, data) {
                                                                             if (err){
                                                                             res.send(err);}

                                                                    }
                   );
               }
                 res.redirect('/admin/treatment_data');
            }catch (e) {
              res.redirect('/admin/treatment_data');


            }

        });

        router.post('/report/delete',Auth.loginAdmin,function(req, res) {
            try{

                  var reports = req.body.TLRep;

                    if( Object.prototype.toString.call( reports ) === '[object Array]' ) {
                  reports.forEach(function(report) {
                   Treatmentdata.update({"category" : req.body.DC},{$pull : {"treatment.report" : report}},function(err, data) {
                                                                               if (err){
                                                                               res.send(err);}

                                                                      }
                     );
                   });
                 }
                 else {
                   Treatmentdata.update({"category" : req.body.DC},{$pull : {"treatment.report" : reports}},function(err, data) {
                                                                               if (err){
                                                                               res.send(err);}

                                                                      }
                     );
                 }
                   res.redirect('/admin/treatment_data');
                }catch (e) {
                  res.redirect('/admin/treatment_data');


                }

        });

        router.post('/dignosis/delete',Auth.loginAdmin,function(req, res) {
            try{
                  var dignosis = req.body.TLDig;
                    if( Object.prototype.toString.call( dignosis ) === '[object Array]' ) {
                    dignosis.forEach(function(dig) {
                  Treatmentdata.update({"category" : req.body.DC},{$pull : {"treatment.dignosis" :dig}},function(err, data) {
                                                                                  if (err){
                                                                                  res.send(err);}

                                                                    }
                     );
                   });
                 }
                 else {
                   Treatmentdata.update({"category" : req.body.DC},{$pull : {"treatment.dignosis" :dignosis}},function(err, data) {
                                                                                   if (err){
                                                                                   res.send(err);}

                                                                     }
                      );
                 }
                   res.redirect('/admin/treatment_data');
                 }catch (e) {
                   res.redirect('/admin/treatment_data');


                 }

        });

        router.post('/advise/delete',Auth.loginAdmin,function(req, res) {
            try{
                  var advises = req.body.TLAdv;
                    if( Object.prototype.toString.call( advises ) === '[object Array]' ) {
                    advises.forEach(function(advise) {
                  Treatmentdata.update({"category" : req.body.DC},{$pull : {"treatment.advise" : advise}},function(err, data) {
                                                                                    if (err){
                                                                                    res.send(err);}

                                                                    }
                     );
                   });
                 }
                 else {
                   Treatmentdata.update({"category" : req.body.DC},{$pull : {"treatment.advise" : advises}},function(err, data) {
                                                                                     if (err){
                                                                                     res.send(err);}

                                                                     }
                      );
                 }
                   res.redirect('/admin/treatment_data');
              }catch (e) {
                res.redirect('/admin/treatment_data');


              }

        });
};
