var type,doctor,staff,medical,cost,discount;
module.exports.Clinic = function (req, res, next) {
  type = "Clinic";
  doctor = 1;
  staff = 0;
  medical = 0;
  cost = 2000;
  discount = 0;
}
module.exports.Speciality = function (req, res, next) {
  type = "Speciality";
  doctor = 1;
  staff = 1;
  medical = 0;
  cost = 3000;
  discount = 0;
}
module.exports.SuperSpeciality = function (req, res, next) {
  type = "SuperSpeciality";
  doctor = 1;
  staff = 3;
  medical = 1;
  cost = 4000;
  medical_cost = 1000;
  discount = 0;
}
module.exports.Silver = function (req, res, next) {
  type = "MultiSpeciality";
  doctor = 3;
  staff = 5;
  medical = 1;
  cost = 10000;
  discount = 0;
}
module.exports.Golden = function (req, res, next) {
  type = "MultiSpeciality";
  doctor = 5;
  staff = 8;
  medical = 1;
  cost = 25000;
  discount = 0;
}
module.exports.Platinum = function (req, res, next) {
  type = "MultiSpeciality";
  doctor = 10;
  staff = 15;
  medical = 2;
  cost = 50000;
  discount = 0;
}
module.exports.Dimond = function (req, res, next) {
  type = "MultiSpeciality";
  doctor = 50;
  staff = 80;
  medical = 10;
  cost = 250000;
  discount = 0;
}
