module.exports = {

    'url' : process.env.OPENSHIFT_MONGODB_DB_URL, // looks like mongodb://<user>:<pass>@mongo.onmodulus.net:27017/Mikha4ot
    'local' : 'mongodb://127.0.0.1:27017/dr',
    'mlab' : 'mongodb://usant_admin:Umediverse_89@ds141274.mlab.com:41274/umediverse',
    'secret' : 'wemadeindianmedicaluniverse',
    'recaptcha-secret' : '6LfJISsUAAAAALuI6zfcvLsOoTa9BtLEyzLo2K8B'
};
