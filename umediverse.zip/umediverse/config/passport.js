// load all the things we need
var LocalStrategy   = require('passport-local').Strategy;

// load up the user model
var Admin            = require('../app/models/admin');
var Patient           = require('../app/models/patientDB');
var Doctor            = require('../app/models/doctorDB');
var Hospital            = require('../app/models/hospitalDB');
var Pharmacy            = require('../app/models/pharmacyDB');
var Laboratory            = require('../app/models/laboratoryDB');



// expose this function to our app using module.exports
module.exports = function(passport) {

    // =========================================================================
    // passport session setup ==================================================
    // =========================================================================
    // required for persistent login sessions
    // passport needs ability to serialize and unserialize users out of session

    // used to serialize the user for the session
    passport.serializeUser(function(user, done) {

      if(user.id)
      {
        done(null, user.id);
      }
      else if(user[0].auth.staff_id)
      {
          done(null, user[0].auth.staff_id);
      }
    });

    // used to deserialize the user
    passport.deserializeUser(function(id, done) {
      Patient.find({"_id" : id},function(err,user){
        if(err) done(err);
        if(user){
            done(null,user);
        }else{
          Doctor.find({"_id" : id},function(err,user){
            if(err) done(err);
            if(user){
                done(null,user);
            }else{
                Hospital.find({"_id" : id}, function(err,user){
                    if(err) done(err);
                    if(user){
                        done(null,user);
                    }else{
                        Admin.find({"_id" : id}, function(err,user){
                            if(err) done(err);
                            if(user){
                                done(null,user);
                            }else{
                                Pharmacy.find({"_id" : id}, function(err,user){
                                    if(err) done(err);
                                    if(user){
                                        done(null,user);
                                    }else{
                                        Laboratory.find({"_id" : id}, function(err,user){
                                            if(err) done(err);
                                            done(null,user);
                                        });
                                    }
                                });
                            }
                        });
                    }
                });
            }
            });
        }
    });
  });


        // =========================================================================
            // Admin LOGIN =============================================================
            // =========================================================================

        passport.use('Admin-login', new LocalStrategy(
          {usernameField : 'username',
            passwordField : 'password',
            passReqToCallback : true},
        function(req,username, password, done) { // callback with email and password from our form

            // find a user whose email is the same as the forms email
            // we are checking to see if the user trying to login already exists
            Admin.findOne({ 'username' :  username }, function(err, user) {
                // if there are any errors, return the error before anything else
                if (err)
                    return done(err);

                // if no user is found, return the message
                if (!user)
                    return done(null, false);

                // if the user is found but the password is wrong
                if (!user.validPassword(password))
                    return done(null, false);

                // all is well, return successful user
                Admin.update({"_id" : user._id},{$set : {"last_login" :new Date()}},function(err, data) {
                                                                                  if (err){
                                                                                  res.send(err);}

                                                                  }
                 );
              req.session.user = user;
              req.session.role = 'Admin';


                return done(null, user);
            });

        }));


    // =========================================================================
        // Patient LOGIN =============================================================
        // =========================================================================


        passport.use('Patient-login', new LocalStrategy(
          {usernameField : 'username',
            passwordField : 'password',
            passReqToCallback : true},
        function(req,username, password, done) { // callback with email and password from our form
            // find a user whose email is the same as the forms email
            // we are checking to see if the user trying to login already exists
            Patient.findOne({'username' :  username }, function(err, user) {
                // if there are any errors, return the error before anything else

                if (err)
                    return done(err);

                // if no user is found, return the message
                if (!user)
                    return done(null, false);

                // if the user is found but the password is wrong
                if (!user.validPassword(password))
                    return done(null, false);

                    Patient.update({"_id" : user._id},{$set : {"last_login" :new Date()}},function(err, data) {
                                                                                      if (err){
                                                                                      res.send(err);}

                                                                      }
                     );
                // all is well, return successful user
              req.session.user = user;
              req.session.role = 'Patient';


                return done(null, user);
            });

        }));

        // =========================================================================
            // Doctor LOGIN =============================================================
            // =========================================================================


        passport.use('Doctor-login', new LocalStrategy(
          {usernameField : 'username',
            passwordField : 'password',
            passReqToCallback : true},
        function(req,username, password, done) { // callback with email and password from our form

            // find a user whose email is the same as the forms email
            // we are checking to see if the user trying to login already exists
            Doctor.findOne({ 'username' :  username }, function(err, user) {
                // if there are any errors, return the error before anything else

                if (err)
                    return done(err);

                // if no user is found, return the message
                if (!user)
                    return done(null, false);

                // if the user is found but the password is wrong
                if (!user.validPassword(password))

                    return done(null, false);

                    Doctor.update({"did" : user.did},{$set : {"last_login" :new Date()}},function(err, data) {
                                                                                      if (err){
                                                                                      res.send(err);}

                                                                      }
                     );
                // all is well, return successful user
                req.session.user = user;
                req.session.role = 'Doctor';


                return done(null, user);
            });

        }));

        // =========================================================================
            // Hospital LOGIN =============================================================
            // =========================================================================

        passport.use('Hospital-login', new LocalStrategy(
          {usernameField : 'username',
            passwordField : 'password',
            passReqToCallback : true},
        function(req,username, password, done) { // callback with email and password from our form

            // find a user whose email is the same as the forms email
            // we are checking to see if the user trying to login already exists
            Hospital.findOne({ 'username' :  username }, function(err, user) {
                // if there are any errors, return the error before anything else

                if (err)
                    return done(err);

                // if no user is found, return the message
                if (!user)
                    {

                    return done(null, false);
                  }
                // if the user is found but the password is wrong
                if (!user.validPassword(password))

                          return done(null, false);


                // all is well, return successful user
                Hospital.update({"hid" : user.hid},{$set : {"last_login" :new Date()}},function(err, data) {
                                                                                  if (err){
                                                                                  res.send(err);}

                                                                  }
                 );
                req.session.user = user;
                req.session.role = 'Hospital';


                return done(null, user);
            });

        }));


        // =========================================================================
            // Pharmacy LOGIN =============================================================
            // =========================================================================


        passport.use('Pharmacy-login', new LocalStrategy(
          {usernameField : 'username',
            passwordField : 'password',
            passReqToCallback : true},
        function(req,username, password, done) { // callback with email and password from our form

            // find a user whose email is the same as the forms email
            // we are checking to see if the user trying to login already exists
            Pharmacy.findOne({ 'username' :  username }, function(err, user) {
                // if there are any errors, return the error before anything else
                if (err)
                    return done(err);

                // if no user is found, return the message
                if (!user)
                    return done(null, false);
                // if the user is found but the password is wrong
                if (!user.validPassword(password))
                    return done(null, false);

                // all is well, return successful user
                Pharmacy.update({"_id" : user._id},{$set : {"last_login" :new Date()}},function(err, data) {
                                                                                  if (err){
                                                                                  res.send(err);}

                                                                  }
                 );
              req.session.user = user;
              req.session.role = 'Pharmacy';



                return done(null, user);
            });

        }));

        // =========================================================================
            // Laboratory LOGIN =============================================================
            // =========================================================================


        passport.use('Laboratory-login', new LocalStrategy(
          {usernameField : 'username',
            passwordField : 'password',
            passReqToCallback : true},
        function(req,username, password, done) { // callback with email and password from our form

            // find a user whose email is the same as the forms email
            // we are checking to see if the user trying to login already exists
            Laboratory.findOne({ 'username' :  username }, function(err, user) {
                // if there are any errors, return the error before anything else
                if (err)
                    return done(err);

                // if no user is found, return the message
                if (!user)
                    return done(null, false);
                // if the user is found but the password is wrong
                if (!user.validPassword(password))
                    return done(null, false);

                // all is well, return successful user
                Laboratory.update({"_id" : user._id},{$set : {"last_login" :new Date()}},function(err, data) {
                                                                                  if (err){
                                                                                  res.send(err);}

                                                                  }
                 );
              req.session.user = user;
              req.session.role = 'Laboratory';



                return done(null, user);
            });

        }));


        // =========================================================================
            // Staff LOGIN =============================================================
            // =========================================================================


        passport.use('Staff-login', new LocalStrategy(
          {usernameField : 'username',
            passwordField : 'password',
            passReqToCallback : true},
        function(req,username, password, done) { // callback with email and password from our form

            // find a user whose email is the same as the forms email
            // we are checking to see if the user trying to login already exists

            Hospital.aggregate( [{ $match: {'auth.username' : username}},
                                 { $unwind: "$auth" },
                                 {$project: {_id:0,hid:1,auth:1}},
                                 { $match: {'auth.username' : username}}
                               ],/*Hospital.findOne({ 'username' :  username },*/ function(err, user) {

                                  var hospital = new Hospital();
                // if there are any errors, return the error before anything else
                if (err)
                    return done(err);

                // if no user is found, return the message
                if (user=="")
                    return done(null, false);

                // if the user is found but the password is wrong
                if (!hospital.validStaffPassword(user[0],password))
                    return done(null, false);

                // all is well, return successful user
              /*  Hospital.update({'auth.username' : user[0].auth.username},{$set : {"auth.$.last_login" :new Date()}},function(err, data) {
                                                                                  if (err){
                                                                                  res.send(err);}

                                                                  }
                 );*/
              req.session.user = user;
              req.session.role = 'Staff';


                return done(null, user);
            });

        }));
};
