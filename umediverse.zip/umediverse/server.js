// set up ======================================================================
// get all the tools we need
global.mode = "Dev";
global.dir = "http://umediverse-usant.rhcloud.com"
var express  = require('express');
var app      = express();
var ip = process.env.OPENSHIFT_NODEJS_IP || "127.0.0.1" ;
var port      = process.env.OPENSHIFT_NODEJS_PORT || 8000;
var mongoose = require('mongoose');
var passport = require('passport');
var morgan       = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser   = require('body-parser');
var session      = require('express-session');
//var MongoStore = require('connect-mongo')(session);
//var nodemailer = require("nodemailer");


var configDB = require('./config/database.js');
var connect_url = configDB.mlab || configDB.local;


// configuration ===============================================================
mongoose.connect(connect_url,{config:{autoIndex:false}}); // connect to our database


require('./config/passport')(passport); // pass passport for configuration

// set up our express application
app.use(morgan('dev')); // log every request to the console
app.use(cookieParser()); // read cookies (needed for auth)
app.use(bodyParser()); // get information from html forms
app.use("/",express.static(__dirname + '/views'));
app.use("/upload",express.static(__dirname + '/views/upload'));

app.set('view engine', 'html'); // set up ejs for templating

// required for passport
app.use(session({
                cookieName: 'session',
                secret: configDB.secret,
                duration: 30 * 60 * 1000,
                activeDuration:  60 * 60,
                httpOnly: true,
                secure: true,
                ephemeral: true
                //store: new MongoStore({ mongooseConnection: mongoose.connection,
                  //                      ttl: 15 * 60  })
              })); // session secret
app.use(passport.initialize());
app.use(passport.session()); // persistent login sessions


var login = express.Router();
require('./app/routes/login.js')(login,passport);
app.use('/',login);

var patient = express.Router();
require('./app/routes/patient.js')(patient);
app.use('/patient',patient);

var doctor = express.Router();
require('./app/routes/doctor.js')(doctor);
app.use('/doctor',doctor);

var hospital = express.Router();
require('./app/routes/hospital.js')(hospital);
app.use('/hospital',hospital);

var appointment = express.Router();
require('./app/routes/appointment.js')(appointment);
app.use('/appointment',appointment);

var admin = express.Router();
require('./app/routes/admin.js')(admin);
app.use('/admin',admin);

var pharmacy = express.Router();
require('./app/routes/pharmacy.js')(pharmacy);
app.use('/pharmacy',pharmacy);

var laboratory = express.Router();
require('./app/routes/laboratory.js')(laboratory);
app.use('/laboratory',laboratory);

var staff = express.Router();
require('./app/routes/staff.js')(staff);
app.use('/staff',staff);

var treatment = express.Router();
require('./app/routes/treatment.js')(treatment);
app.use('/treatment',treatment);

var forgot = express.Router();
require('./app/routes/forgot.js')(forgot);
app.use('/forgot',forgot);

var reset = express.Router();
require('./app/routes/reset.js')(reset);
app.use('/reset',reset);


app.get('*', function(request, response, next) {
  response.sendfile(__dirname +'/views/index.html');
});


// launch ======================================================================
app.listen(port,ip);
console.log('The server run on ' + port + ' Port.....');
