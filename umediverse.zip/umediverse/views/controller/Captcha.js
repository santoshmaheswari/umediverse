var CaptchaModule = angular.module('CaptchaModule',[]);

CaptchaModule.controller('captcha', function($scope){
$scope.Captcha =  function (){
  var alpha = new Array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W',
                        'X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v',
                        'w','x','y','z','1','2','3','4','5','6','7','8','9','0');
  var i;
  for (i=0;i<6;i++){
    var a = alpha[Math.floor(Math.random() * alpha.length)];
    var b = alpha[Math.floor(Math.random() * alpha.length)];
    var c = alpha[Math.floor(Math.random() * alpha.length)];
    var d = alpha[Math.floor(Math.random() * alpha.length)];
    var e = alpha[Math.floor(Math.random() * alpha.length)];
    var f = alpha[Math.floor(Math.random() * alpha.length)];
    var g = alpha[Math.floor(Math.random() * alpha.length)];
   }
 var code = a + ' ' + b + ' ' + ' ' + c + ' ' + d + ' ' + e + ' '+ f + ' ' + g;
 $scope.code = code;

 }
   $scope.ValidCaptcha = function(){
   var string1 = removeSpaces($scope.code);
   var string2 = removeSpaces($scope.inputcode);
   if (string1 != string2){
     $scope.err = "Enter valid security code."
     //return true;
   }
   else{
    $scope.err = "";
   }
 }
 function removeSpaces(string){
 return string.split(' ').join('');
}
});
