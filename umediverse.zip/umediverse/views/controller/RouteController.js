var IndexRoute = angular.module('IndexRoute', ['ngRoute','ngFileUpload','ResetData','AdminData','DoctorData','HospitalData',
                                'StaffData','TreatmentDrData','AppointmentData','PatientData','Treatmentdata','DatePicker',
                                  'Laboratorydata','CaptchaModule','TabModule','PharmacyData','Mapdata'])

.config(['$routeProvider','$locationProvider',
  function($routeProvider,$locationProvider) {
    $routeProvider
      .when('/', {
        templateUrl: 'home.html',
        resolve : {title: ["Title", function(Title) {
             return Title;
                  }]}
        })
      .when('/login', {
        templateUrl: 'Admin_Login.html',
        resolve : {title: ["Title", function(Title) {
             return Title;
                  }]}
      })
      .when('/dlogin', {
        templateUrl: 'Doctor_Login.html',
        resolve : {title: ["Title", function(Title) {
             return Title;
           }]}
      })
      .when('/hlogin', {
        templateUrl: 'Hospital_Login.html',
        resolve : {title: ["Title", function(Title) {
             return Title;
                  }]}
      })
      .when('/plogin', {
        templateUrl: 'Patient_Login.html',
        resolve : {title: ["Title", function(Title) {
             return Title;
                  }]}
      })
      .when('/slogin', {
        templateUrl: 'Staff_Login.html',
        resolve : {title: ["Title", function(Title) {
             return Title;
                  }]}
      })
      .when('/phlogin', {
        templateUrl: 'Pharmacy_Login.html',
        resolve : {title: ["Title", function(Title) {
             return Title;
                  }]}
      })
      .when('/llogin', {
        templateUrl: 'Laboratory_Login.html',
        resolve : {title: ["Title", function(Title) {
             return Title;
                  }]}
      })
      .when('/logout', {
        controller: 'LogoutController'

      })
      .when('/test', {
        templateUrl: 'test.html',
        controller: 'testCtrl',
      })
      .when('/map', {
        templateUrl: 'map.html',
        controller: 'mapController',
        resolve : {title: ["Title", function(Title) {
             return Title;
                  }]}
      })

      //forgot & reset

      .when('/forgot/admin', {
        templateUrl: 'Admin_Forgot.html',
        controller: 'ForgotController',
        resolve : {title: ["Title", function(Title) {
             return Title;
                  }]}
      })
      .when('/forgot/hospital', {
        templateUrl: 'Hospital_Forgot.html',
        controller: 'ForgotController',
        resolve : {title: ["Title", function(Title) {
             return Title;
                  }]}
      })

      .when('/forgot/patient', {
        templateUrl: 'Patient_Forgot.html',
        controller: 'ForgotController',
        resolve : {title: ["Title", function(Title) {
             return Title;
                  }]}
      })
      .when('/forgot/doctor', {
        templateUrl: 'Doctor_Forgot.html',
        controller: 'ForgotController',
        resolve : {title: ["Title", function(Title) {
             return Title;
                  }]}
      })
      .when('/forgot/pharmacy', {
        templateUrl: 'Pharmacy_Forgot.html',
        controller: 'ForgotController',
        resolve : {title: ["Title", function(Title) {
             return Title;
                  }]}
      })
      .when('/forgot/laboratory', {
        templateUrl: 'Laboratory_Forgot.html',
        controller: 'ForgotController',
        resolve : {title: ["Title", function(Title) {
             return Title;
                  }]}
      })
      .when('/reset/admin/:token', {
        templateUrl: 'Reset_Verify.html',
        controller: 'ADResetController',
        resolve : {title: ["Title", function(Title) {
             return Title;
                  }]}
      })
      .when('/reset/patient/:token', {
        templateUrl: 'Reset_Verify.html',
        controller: 'PTResetController',
        resolve : {title: ["Title", function(Title) {
             return Title;
                  }]}
      })
      .when('/reset/hospital/:token', {
        templateUrl: 'Reset_Verify.html',
        controller: 'HPResetController',
        resolve : {title: ["Title", function(Title) {
             return Title;
                  }]}
      })
      .when('/reset/doctor/:token', {
        templateUrl: 'Reset_Verify.html',
        controller: 'DRResetController',
        resolve : {title: ["Title", function(Title) {
             return Title;
                  }]}
      })
      .when('/reset/pharmacy/:token', {
        templateUrl: 'Reset_Verify.html',
        controller: 'MedResetController',
        resolve : {title: ["Title", function(Title) {
             return Title;
                  }]}
      })
      .when('/reset/laboratory/:token', {
        templateUrl: 'Reset_Verify.html',
        controller: 'LabResetController',
        resolve : {title: ["Title", function(Title) {
             return Title;
                  }]}
      })
      .when('/reset/password', {
        templateUrl: 'Reset_Password.html',
        controller: 'ResetPasswordController',
        resolve : {title: ["Title", function(Title) {
             return Title;
                  }]}
      })

      //Admin URL

      .when('/admin', {
          templateUrl: 'Admin_Dashboard.html',
          resolve : {auth: ["$q", "AdminSession", function($q, AdminSession) {
                          return AdminSession.isValid();
                    }]}
      })
      .when('/admin/registration', {
          templateUrl: 'Admin_Registration.html'
        /*  resolve : {auth: ["$q", "AdminSession", function($q, AdminSession) {
                          return AdminSession.isValid();
                    }]}*/
      })
      .when('/admin/treatment_data', {
          templateUrl: 'Treatment_Data.html',
          controller: 'TRcontroller',
          resolve : {auth: ["$q", "AdminSession", function($q, AdminSession) {
                          return AdminSession.isValid();
                    }]}
      })
      .when('/admin/change_password', {
          templateUrl: 'Change_Password.html',
          controller: 'ADPwdChngcontroller',
          resolve : {auth: ["$q", "AdminSession", function($q, AdminSession) {
                          return AdminSession.isValid();
                    }]}
      })

      //Doctor URL

        .when('/doctor', {
          templateUrl: 'Doctor_Hospital.html',
          controller: 'DHcontroller',
          resolve : {auth: ["$q", "AuthTSession", function($q, AuthTSession) {
                          return AuthTSession.isValid();
                    }]}
      })
      .when('/doctor/registration', {
          templateUrl: 'Doctor_Registration.html',
          controller: 'DRcontroller',
          resolve : {auth: ["$q", "HospitalSession", function($q, HospitalSession) {
                          return HospitalSession.isValid();
                    }]}
      })
      .when('/doctor/hospital/:hid', {
          templateUrl: 'Doctor_Dashboard.html',
          controller: 'DDashcontroller',
          resolve : {auth: ["$q", "DoctorSession", function($q, DoctorSession) {
                          return DoctorSession.isValid();
                    }]}
      })
      .when('/doctor/profile', {
          templateUrl: 'Doctor_Profile.html',
          controller: 'DRviewcontroller',
          resolve : {auth: ["$q", "DoctorSession", function($q, DoctorSession) {
                          return DoctorSession.isValid();
                    }]}
      })
      .when('/doctor/update', {
          templateUrl: 'Doctor_Update.html',
          controller: 'DRviewcontroller',
          resolve : {auth: ["$q", "DoctorSession", function($q, DoctorSession) {
                          return DoctorSession.isValid();
                    }]}
      })
      .when('/doctor/treatment_window', {
          templateUrl: 'Treatment.html',
          controller: 'doctorTreatmentController',
          resolve : {auth: ["$q", "DoctorSession", function($q, DoctorSession) {
                          return DoctorSession.isValid();
                    }]}
      })
      .when('/doctor/treatment_manager', {
          templateUrl: 'Treatment_Manager.html',
          controller: 'TMcontroller',
          resolve : {auth: ["$q", "DoctorSession", function($q, DoctorSession) {
                          return DoctorSession.isValid();
                    }]}
      })
      .when('/doctor/doctor_case_report', {
          templateUrl: 'Doctor_Case_Report.html',
          controller: 'DRCasecontroller',
          resolve : {auth: ["$q", "DoctorSession", function($q, DoctorSession) {
                          return DoctorSession.isValid();
                    }]}
      })
      .when('/doctor/doctor_case_report/:appid', {
          templateUrl: 'Doctor_Case_Report_View.html',
          controller: 'DRCaseViewcontroller',
          resolve : {auth: ["$q", "DoctorSession", function($q, DoctorSession) {
                          return DoctorSession.isValid();
                    }]}
      })
      .when('/doctor/appointment', {
          templateUrl: 'Doctor_Appointment.html',
          controller: 'DrappointmentCtrl',
          resolve : {auth: ["$q", "DoctorSession", function($q, DoctorSession) {
                          return DoctorSession.isValid();
                    }]}
      })
      .when('/doctor/investigation/upload', {
          templateUrl: 'Doctor_Investigation.html',
          controller: 'DRInvcontroller',
          resolve : {auth: ["$q", "DoctorSession", function($q, DoctorSession) {
                          return DoctorSession.isValid();
                    }]}
      })
      .when('/doctor/change_password', {
          templateUrl: 'Change_Password.html',
          controller: 'DRPwdChngcontroller',
          resolve : {auth: ["$q", "DoctorSession", function($q, DoctorSession) {
                          return DoctorSession.isValid();
                    }]}
      })


      //Hospital URL
      .when('/hospital', {
          templateUrl: 'Hospital_Dashboard.html',
          resolve : {auth: ["$q", "HospitalSession", function($q, HospitalSession) {
                          return HospitalSession.isValid();
                    }]}
      })
      .when('/hospital/registration', {
          templateUrl: 'Hospital_Registration.html',
          controller: 'HOcontroller',
          resolve : {title: ["Title", function(Title) {
               return Title;
                    }]}
          /*resolve : {auth: ["$q", "AdminSession", function($q, AdminSession) {
                          return AdminSession.isValid();
                    }]}*/
      })
      .when('/hospital/profile', {
          templateUrl: 'Hospital_Profile.html',
          controller: 'HOviewcontroller',
          resolve : {auth: ["$q", "HospitalSession", function($q, HospitalSession) {
                          return HospitalSession.isValid();
                    }]}
      })
      .when('/hospital/update', {
          templateUrl: 'Hospital_Update.html',
          controller: 'HOviewcontroller',
          resolve : {auth: ["$q", "HospitalSession", function($q, HospitalSession) {
                          return HospitalSession.isValid();
                    }]}
      })
      .when('/hospital/doctor/approve', {
          templateUrl: 'Doctor_Approve.html',
          controller: 'DoctorApproveController',
          resolve : {auth: ["$q", "HospitalSession", function($q, HospitalSession) {
                          return HospitalSession.isValid();
                    }]}
      })
      .when('/hospital/doctor/relieve', {
          templateUrl: 'Doctor_Relieve.html',
          controller: 'doctorRelieveController',
          resolve : {auth: ["$q", "HospitalSession", function($q, HospitalSession) {
                          return HospitalSession.isValid();
                    }]}
      })
      .when('/hospital/doctor/detail', {
          templateUrl: 'Hospital_Doctor_Detail.html',
          controller: 'HospitalDoctorDetailController',
          resolve : {auth: ["$q", "HospitalSession", function($q, HospitalSession) {
                          return HospitalSession.isValid();
                    }]}
      })
      .when('/hospital/doctor/data/:did', {
          templateUrl: 'Hospital_Doctor_View.html',
          controller: 'HDrViewcontroller',
          resolve : {auth: ["$q", "HospitalSession", function($q, HospitalSession) {
                          return HospitalSession.isValid();
                    }]}
      })
      .when('/hospital/doctor/update', {
          templateUrl: 'hospital_Doctor_Update.html',
          controller: 'HdoctorUpdateController',
          resolve : {auth: ["$q", "HospitalSession", function($q, HospitalSession) {
                          return HospitalSession.isValid();
                    }]}
      })
      .when('/hospital/doctor/shift', {
          templateUrl: 'Doctor_Shift.html',
          resolve : {auth: ["$q", "HospitalSession", function($q, HospitalSession) {
                          return HospitalSession.isValid();
                    }]}
      })
      .when('/hospital/doctor/shift/add', {
          templateUrl: 'Doctor_Shift_Add.html',
          controller: 'doctorShiftAddController',
          resolve : {auth: ["$q", "HospitalSession", function($q, HospitalSession) {
                          return HospitalSession.isValid();
                    }]}
      })
      .when('/hospital/doctor/shift/update', {
          templateUrl: 'Doctor_Shift_Update.html',
          controller: 'doctorShiftViewController',
          resolve : {auth: ["$q", "HospitalSession", function($q, HospitalSession) {
                          return HospitalSession.isValid();
                    }]}
      })
      .when('/hospital/doctor/shift/view', {
          templateUrl: 'Doctor_Shift_View.html',
          controller: 'doctorShiftViewController',
          resolve : {auth: ["$q", "HospitalSession", function($q, HospitalSession) {
                          return HospitalSession.isValid();
                    }]}
      })
      .when('/hospital/staff/approve', {
          templateUrl: 'Staff_Approve.html',
          controller: 'staffApproveController',
          resolve : {auth: ["$q", "HospitalSession", function($q, HospitalSession) {
                          return HospitalSession.isValid();
                    }]}
      })
      .when('/hospital/staff/relieve', {
          templateUrl: 'Staff_Relieve.html',
          controller: 'staffRelieveController',
          resolve : {auth: ["$q", "HospitalSession", function($q, HospitalSession) {
                          return HospitalSession.isValid();
                    }]}
      })
      .when('/hospital/staff/account', {
          templateUrl: 'staff_Account.html',
          controller: 'staffAccountController',
          resolve : {auth: ["$q", "HospitalSession", function($q, HospitalSession) {
                          return HospitalSession.isValid();
                    }]}
      })
      .when('/hospital/staff/account/detail', {
          templateUrl: 'staff_Account_Detail.html',
          controller: 'staffAccountController',
          resolve : {auth: ["$q", "HospitalSession", function($q, HospitalSession) {
                          return HospitalSession.isValid();
                    }]}
      })
      .when('/hospital/staff/account/add', {
          templateUrl: 'staff_Account_Add.html',
          controller: 'staffCAccountController',
          resolve : {auth: ["$q", "HospitalSession", function($q, HospitalSession) {
                          return HospitalSession.isValid();
                    }]}
      })
      .when('/hospital/staff/account/update', {
          templateUrl: 'Staff_Account_Update.html',
          controller: 'staffUAccountController',
          resolve : {auth: ["$q", "HospitalSession", function($q, HospitalSession) {
                          return HospitalSession.isValid();
                    }]}
      })
      .when('/hospital/staff/detail', {
          templateUrl: 'Hospital_Staff_Detail.html',
          controller: 'HospitalStaffDetailController',
          resolve : {auth: ["$q", "HospitalSession", function($q, HospitalSession) {
                          return HospitalSession.isValid();
                    }]}
      })
      .when('/hospital/staff/update', {
          templateUrl: 'Hospital_Staff_Update.html',
          controller: 'HospitalStaffUpdateController',
          resolve : {auth: ["$q", "HospitalSession", function($q, HospitalSession) {
                          return HospitalSession.isValid();
                    }]}
      })
      .when('/hospital/staff/data/:sid', {
          templateUrl: 'Hospital_Staff_View.html',
          controller: 'HStaffViewcontroller',
          resolve : {auth: ["$q", "HospitalSession", function($q, HospitalSession) {
                          return HospitalSession.isValid();
                    }]}
      })
      .when('/hospital/casefees', {
          templateUrl: 'Hospital_Fees.html',
          controller: 'HOFeesController',
          resolve : {auth: ["$q", "HospitalSession", function($q, HospitalSession) {
                          return HospitalSession.isValid();
                    }]}
      })

      .when('/hospital/change_password', {
          templateUrl: 'Change_Password.html',
          controller: 'HOPwdChngcontroller',
          resolve : {auth: ["$q", "HospitalSession", function($q, HospitalSession) {
                          return HospitalSession.isValid();
                    }]}
      })
      .when('/hospital/doctor', {
          templateUrl: 'Hospital_Doctor.html',
          resolve : {auth: ["$q", "HospitalSession", function($q, HospitalSession) {
                          return HospitalSession.isValid();
                    }]}
      })
      .when('/hospital/staff', {
          templateUrl: 'Hospital_Staff.html',
          resolve : {auth: ["$q", "HospitalSession", function($q, HospitalSession) {
                          return HospitalSession.isValid();
                    }]}
      })
      .when('/hospital/pharmacy', {
          templateUrl: 'Hospital_Pharmacy.html',
          resolve : {auth: ["$q", "HospitalSession", function($q, HospitalSession) {
                          return HospitalSession.isValid();
                    }]}
      })
      .when('/hospital/laboratory', {
          templateUrl: 'Hospital_Laboratory.html',
          resolve : {auth: ["$q", "HospitalSession", function($q, HospitalSession) {
                          return HospitalSession.isValid();
                    }]}
      })
      .when('/hospital/clinic', {
          templateUrl: 'Doctor_Clinic_Dashboard.html',
          resolve : {auth: ["$q", "HospitalSession", function($q, HospitalSession) {
                          return HospitalSession.isValid();
                    }]}
      })


      //Staff URL

      .when('/staff', {
          templateUrl: 'Staff_Dashboard.html',
          resolve : {auth: ["$q", "StaffSession", function($q, StaffSession) {
                          return StaffSession.isValid();
                    }]}

      })
      .when('/staff/report', {
          templateUrl: 'Staff_Appointment_Report.html',
          controller: 'StaffAppReportController',
          resolve : {auth: ["$q", "StaffSession", function($q, StaffSession) {
                          return StaffSession.isValid();
                    }]}

      })
      .when('/staff/registration', {
          templateUrl: 'Staff_Registration.html',
          controller: 'staffController',
          resolve : {auth: ["$q", "HospitalSession", function($q, HospitalSession) {
                          return HospitalSession.isValid();
                    }]}
      })
      .when('/staff/appointment', {
          templateUrl: 'Staff_Appointment.html',
          controller: 'StfappointmentCtrl',
          resolve : {auth: ["$q", "StaffSession", function($q, StaffSession) {
                          return StaffSession.isValid();
                    }]}
      })
      .when('/staff/investigation/upload', {
          templateUrl: 'Staff_Investigation.html',
          controller: 'STFInvcontroller',
          resolve : {auth: ["$q", "StaffSession", function($q, StaffSession) {
                          return StaffSession.isValid();
                    }]}
      })
      .when('/staff/change_password', {
          templateUrl: 'Change_Password.html',
          controller: 'STFPwdChngcontroller',
          resolve : {auth: ["$q", "StaffSession", function($q, StaffSession) {
                          return StaffSession.isValid();
                    }]}
      })


      //Pharmacy URL
      .when('/pharmacy', {
          templateUrl: 'Pharmacy_Dashboard.html',
          resolve : {auth: ["$q", "PharmacySession", function($q, PharmacySession) {
                          return PharmacySession.isValid();
                    }]}
      })
      .when('/admin/pharmacy/registration', {
          templateUrl: 'Pharmacy_Registration.html',
          controller: 'PHcontroller',
          resolve : {auth: ["$q", "AdminSession", function($q, AdminSession) {
                          return AdminSession.isValid();
                    }]}
      })
      .when('/hospital/pharmacy/registration', {
          templateUrl: 'Pharmacy_Registration.html',
          controller: 'PHcontroller',
          resolve : {auth: ["$q", "HospitalSession", function($q, HospitalSession) {
                          return HospitalSession.isValid();
                    }]}
      })
      .when('/pharmacy/profile', {
          templateUrl: 'Pharmacy_Profile.html',
          controller: 'PHviewcontroller',
          resolve : {auth: ["$q", "PharmacySession", function($q, PharmacySession) {
                          return PharmacySession.isValid();
                    }]}
      })
      .when('/pharmacy/update', {
          templateUrl: 'Pharmacy_Update.html',
          controller: 'PHviewcontroller',
          resolve : {auth: ["$q", "PharmacySession", function($q, PharmacySession) {
                          return PharmacySession.isValid();
                    }]}
      })
      .when('/pharmacy/patient/case_detail', {
          templateUrl: 'Pharmacy_Patient_Report.html',
          controller: 'PHpatientcontroller',
          resolve : {auth: ["$q", "PharmacySession", function($q, PharmacySession) {
                          return PharmacySession.isValid();
                    }]}
      })
      .when('/pharmacy/patient/data/:appid', {
          templateUrl: 'Pharmacy_Patient_Case_View.html',
          controller: 'PHPTCaseViewcontroller',
          resolve : {auth: ["$q", "PharmacySession", function($q, PharmacySession) {
                          return PharmacySession.isValid();
                    }]}
      })
      .when('/pharmacy/change_password', {
          templateUrl: 'Change_Password.html',
          controller: 'PHPwdChngcontroller',
          resolve : {auth: ["$q", "PharmacySession", function($q, PharmacySession) {
                          return PharmacySession.isValid();
                    }]}
      })

      //Laboratory URL
      .when('/laboratory', {
          templateUrl: 'Laboratory_Dashboard.html',
          resolve : {auth: ["$q", "LaboratorySession", function($q, LaboratorySession) {
                          return LaboratorySession.isValid();
                    }]}
      })
      .when('/admin/laboratory/registration', {
          templateUrl: 'Laboratory_Registration.html',
          controller: 'Labcontroller',
          resolve : {auth: ["$q", "AdminSession", function($q, AdminSession) {
                          return AdminSession.isValid();
                    }]}
      })
      .when('/hospital/laboratory/registration', {
          templateUrl: 'Laboratory_Registration.html',
          controller: 'Labcontroller',
          resolve : {auth: ["$q", "HospitalSession", function($q, HospitalSession) {
                          return HospitalSession.isValid();
                    }]}
      })
      .when('/laboratory/profile', {
          templateUrl: 'Laboratory_Profile.html',
          controller: 'Labviewcontroller',
          resolve : {auth: ["$q", "LaboratorySession", function($q, LaboratorySession) {
                          return LaboratorySession.isValid();
                    }]}
      })
      .when('/laboratory/update', {
          templateUrl: 'Laboratory_Update.html',
          controller: 'Labviewcontroller',
          resolve : {auth: ["$q", "LaboratorySession", function($q, LaboratorySession) {
                          return LaboratorySession.isValid();
                    }]}
      })
      .when('/laboratory/fees', {
          templateUrl: 'Laboratory_Fees.html',
          controller: 'Labfeescontroller',
          resolve : {auth: ["$q", "LaboratorySession", function($q, LaboratorySession) {
                          return LaboratorySession.isValid();
                    }]}
      })
      .when('/laboratory/patient/investigation_detail', {
          templateUrl: 'Laboratory_Patient_Report.html',
          controller: 'Labpatientcontroller',
          resolve : {auth: ["$q", "LaboratorySession", function($q, LaboratorySession) {
                          return LaboratorySession.isValid();
                    }]}
      })
      .when('/laboratory/patient/investigation/upload/:appid', {
          templateUrl: 'Laboratory_HO_Investigation_Upload.html',
          controller: 'LbHoInvUploadController',
          resolve : {auth: ["$q", "LaboratorySession", function($q, LaboratorySession) {
                          return LaboratorySession.isValid();
                    }]}
      })
      .when('/laboratory/patient/data/:appid', {
          templateUrl: 'Laboratory_Patient_Case_View.html',
          controller: 'LbPTCaseViewcontroller',
          resolve : {auth: ["$q", "LaboratorySession", function($q, LaboratorySession) {
                          return LaboratorySession.isValid();
                    }]}
      })
      .when('/laboratory/change_password', {
          templateUrl: 'Change_Password.html',
          controller: 'LabPwdChngcontroller',
          resolve : {auth: ["$q", "LaboratorySession", function($q, LaboratorySession) {
                          return LaboratorySession.isValid();
                    }]}
      })

      //Patient URL

      .when('/patient', {
          templateUrl: 'Patient_Dashboard.html',
          resolve : {auth: ["$q", "PatientSession", function($q, PatientSession) {
                          return PatientSession.isValid();
                    }]}
      })
      .when('/patient/registration', {
          templateUrl: 'Patient_Registration.html',
          controller: 'PTcontroller',
          resolve : {title: ["Title", function(Title) {
               return Title;
                    }]}

          /*,
          resolve : {auth: ["$q", "PatientSession", function($q, PatientSession) {
                          return PatientSession.isValid();
                    }]}*/
      })
      .when('/patient/profile', {
          templateUrl: 'Patient_Profile.html',
          controller: 'PTviewcontroller',
          resolve : {auth: ["$q", "PatientSession", function($q, PatientSession) {
                          return PatientSession.isValid();
                    }]}
      })
      .when('/patient/update', {
          templateUrl: 'Patient_Update.html',
          controller: 'PTviewcontroller',
          resolve : {auth: ["$q", "PatientSession", function($q, PatientSession) {
                          return PatientSession.isValid();
                    }]}
      })
      .when('/patient/case_history', {
          templateUrl: 'Patient_Case_History.html',
          controller: 'PTCasecontroller',
          resolve : {auth: ["$q", "PatientSession", function($q, PatientSession) {
                          return PatientSession.isValid();
                    }]}
      })
      .when('/patient/patient_case_history/:appid', {
          templateUrl: 'Patient_Case_View.html',
          controller: 'PTCaseViewcontroller',
          resolve : {auth: ["$q", "PatientSession", function($q, PatientSession) {
                          return PatientSession.isValid();
                    }]}
      })
      .when('/patient/change_password', {
          templateUrl: 'Change_Password.html',
          controller: 'PTPwdChngcontroller',
          resolve : {auth: ["$q", "PatientSession", function($q, PatientSession) {
                          return PatientSession.isValid();
                    }]}
      })

      //Appointment URL

      .otherwise({
        redirectTo: '/'
      });

      $locationProvider.html5Mode(true);
  }])

.controller('LogoutController' , function($http,$scope,$location,$window){
  $scope.logout = function () {

    $http.get('/logout').success(function(data)
      {
          if(data.status===200)
            $location.path('/')
      }
    );
  }
})

.service('Title', ['$rootScope',function($rootScope){

        $rootScope.login = false;
        $rootScope.title = "UMediverse Care";
        $rootScope.logo = "/logo/logo.jpg";
  }])

.service('AuthTSession', ['$http','$q','$rootScope',function($http,$q,$rootScope){
      return {
              isValid: function() {
                  return $http.get('/admin/session')
                      .then(function(response) {
                          if (response.data.session === 'Patient'|| response.data.session === 'Doctor' ) {
                            $rootScope.title = "UMediverse Care";
                            $rootScope.logo = "/logo/logo.jpg";
                            $rootScope.login = true;

                              return response.data;
                          } else {
                              // invalid response
                              return $q.reject({ authenticated: false });
                          }

                      }, function(response) {
                          // something went wrong
                          return $q.reject({ authenticated: false });
                      });
              }
          };
  }])

.service('PatientSession', ['$http','$q','$rootScope',function($http,$q,$rootScope){
    return {
            isValid: function() {
                return $http.get('/admin/session')
                    .then(function(response) {
                        if (response.data.session === 'Patient') {
                          $rootScope.title = response.data.user_data[0].title;
                          $rootScope.logo = response.data.user_data[0].logo;
                          $rootScope.login = true;

                            return response.data;
                        } else {
                            // invalid response
                            return $q.reject({ authenticated: false });
                        }

                    }, function(response) {
                        // something went wrong
                        return $q.reject({ authenticated: false });
                    });
            }
        };
}])


.service('DoctorSession', ['$http','$q','$rootScope',function($http,$q,$rootScope){
    return {
            isValid: function() {
                return $http.get('/admin/session')
                    .then(function(response) {
                        if (response.data.session === 'Doctor' || response.data.dr_data) {
                          $rootScope.title = response.data.user_data[0].title;
                          $rootScope.logo = response.data.user_data[0].logo;
                          $rootScope.login = true;

                            return response.data;
                        } else {
                            // invalid response
                            return $q.reject({ authenticated: false });
                        }

                    }, function(response) {
                        // something went wrong
                        return $q.reject({ authenticated: false });
                    });
            }
        };
}])

.service('HospitalSession', ['$http','$q','$rootScope',function($http,$q,$rootScope){
    return {
            isValid: function() {
                return $http.get('/admin/session')
                    .then(function(response) {
                        if (response.data.session === 'Hospital') {
                          $rootScope.login = true;
                          $rootScope.title = response.data.user_data[0].title;
                          $rootScope.logo = response.data.user_data[0].logo;
                          $rootScope.formula = response.data.user_data[0].formula;
                          $rootScope.dr_id = "";
                          if(response.data.dr_data)
                          {
                            $rootScope.dr_id = response.data.dr_data[0].did;
                            $rootScope.dr_name = "Dr. " + response.data.dr_data[0].name.fname + " " + response.data.dr_data[0].name.lname;
                            $rootScope.dr_img = response.data.dr_data[0].img;
                          }
                            return response.data;
                        } else {
                            // invalid response
                            return $q.reject({ authenticated: false });
                        }

                    }, function(response) {
                        // something went wrong
                        return $q.reject({ authenticated: false });
                    });
            }
        };
}])

.service('StaffSession', ['$http','$q','$rootScope',function($http,$q,$rootScope){
    return {
            isValid: function() {
                return $http.get('/admin/session')
                    .then(function(response) {
                        if (response.data.session === 'Staff') {
                          $rootScope.login = true;
                          $rootScope.title = response.data.user_data[0].title;
                          $rootScope.logo = response.data.user_data[0].logo;
                            return response.data;
                        } else {
                            // invalid response
                            return $q.reject({ authenticated: false });
                        }

                    }, function(response) {
                        // something went wrong
                        return $q.reject({ authenticated: false });
                    });
            }
        };
}])


.service('AdminSession', ['$http','$q','$rootScope',function($http,$q,$rootScope){
    return {
            isValid: function() {
                return $http.get('/admin/session')
                    .then(function(response) {
                        if (response.data.session === 'Admin') {
                          $rootScope.login = true;
                          $rootScope.title = response.data.user_data[0].title;
                          $rootScope.logo = response.data.user_data[0].logo;
                            return response.data;
                        } else {
                            // invalid response
                            return $q.reject({ authenticated: false });
                        }

                    }, function(response) {
                        // something went wrong
                        return $q.reject({ authenticated: false });
                    });
            }
        };
}])

.service('AppointmentSession', ['$http','$q','$rootScope',function($http,$q,$rootScope){
    return {
            isValid: function() {
                return $http.get('/admin/session')
                    .then(function(response) {

                        if (response.data.session === 'Staff' || response.data.session === 'Doctor') {
                          $rootScope.login = true;
                          $rootScope.title = response.data.user_data[0].title;
                          $rootScope.logo = response.data.user_data[0].logo;
                            return response.data;
                        } else {
                            // invalid response
                            return $q.reject({ authenticated: false });
                        }

                    }, function(response) {
                        // something went wrong
                        return $q.reject({ authenticated: false });
                    });
            }
        };
}])
.service('PharmacySession', ['$http','$q','$rootScope',function($http,$q,$rootScope){
    return {
            isValid: function() {
                return $http.get('/admin/session')
                    .then(function(response) {

                        if (response.data.session === 'Pharmacy') {
                          $rootScope.login = true;
                          $rootScope.title = response.data.user_data[0].title;
                          $rootScope.logo = response.data.user_data[0].logo;
                            return response.data;
                        } else {
                            // invalid response
                            return $q.reject({ authenticated: false });
                        }

                    }, function(response) {
                        // something went wrong
                        return $q.reject({ authenticated: false });
                    });
            }
        };
}])
.service('LaboratorySession', ['$http','$q','$rootScope',function($http,$q,$rootScope){
    return {
            isValid: function() {
                return $http.get('/admin/session')
                    .then(function(response) {

                        if (response.data.session === 'Laboratory') {
                          $rootScope.login = true;
                          $rootScope.title = response.data.user_data[0].title;
                          $rootScope.logo = response.data.user_data[0].logo;
                            return response.data;
                        } else {
                            // invalid response
                            return $q.reject({ authenticated: false });
                        }

                    }, function(response) {
                        // something went wrong
                        return $q.reject({ authenticated: false });
                    });
            }
        };
}])


.run(["$rootScope", "$location","$window", function($rootScope, $location,$window) {
  $rootScope.$on("$routeChangeError", function(event, current, previous, eventObj) {
    if (eventObj.authenticated === false) {
      $window.alert("Un-Authorized User");
      $location.path("/");
    }
  });
}]);
