angular.module('TabModule',[]).controller('TabCtrl', function ($scope, $window) {
});
