var TreatmentDrData = angular.module('TreatmentDrData', ['ui.bootstrap']);

TreatmentDrData.controller('doctorTreatmentController' , function($scope, $http,$location,$window,$route,$uibModal, $log){
    $scope.dadetails={};
    $scope.d_details={};
    $scope.xu = [];
    $scope.xu.DTCODU = [];
$scope.DTR={};
$scope.DTR.AID={};
    $scope.general = ["+","+1","+2","+3","+4"];
    $scope.CNS = ["Concious","Oriented"];
    $scope.HP = ["Bowel","Bladder","Appetite","Sleep","Allergy","Habit"];
    $scope.HPS = [{"Bowel":["Normal","Up","Down"]},{"Bladder":["Normal","Up","Down"]},{"Appetite":["Normal","Up","Down"]},{"Sleep":["Sound","Disturb"]}];

    $scope.appointment=[];
        $http.get('/patient/appointment/list')
        .success(function(data) {

          if(data.status===200)
          {
          data = data.data;

            $scope.dadetails = data;



              for(var y of data) {
                if(y.case_detail.visit_detail.is_visited == false || y.case_detail.visit_detail.is_visited === "No")
                {
                  $scope.appointment.push(y);
                }
              }

           if($scope.appointment != "")
           {
             $scope.DTR.AID=$scope.appointment[0].case_detail.visit_detail._id;
             $http.get('/doctor/patient/' + $scope.DTR.AID)
             .success(function(data) {
               pdata(data.data[0]);
              })
              .error(function(data) {

              });
          }

        }
        })
        .error(function(data) {

        });

        function pdata(data) {

          $scope.DTR.past = [];
          $scope.DTR.family =[];
           $scope.DTR.drug = [];
           $scope.DTR.personal =[];
           $scope.DTR.pasty = [];
           $scope.DTR.familyy =[];
            $scope.DTR.drugy = [];
            $scope.DTR.personaly =[];
            $scope.DTR.pastm = [];
            $scope.DTR.familym =[];
            $scope.DTR.drugm = [];
            $scope.DTR.personalm =[];
            $scope.DTR.pastd = [];
            $scope.DTR.familyd =[];
            $scope.DTR.drugd = [];
            $scope.DTR.personald =[];
                 $scope.dpddata = data;
                 if(!data.history)
                 {
                   $scope.dpddata.history = [];
                   $scope.dpddata.history.past = [];
                   $scope.dpddata.history.family = [];
                   $scope.dpddata.history.drug = [];
                   $scope.dpddata.history.personal = [];

                 }
                 if($scope.dpddata.history.past)
                 $scope.DTR.past = $scope.dpddata.history.past;
                 if($scope.dpddata.history.family)
                 $scope.DTR.family = $scope.dpddata.history.family;
                 if($scope.dpddata.history.drug)
                 $scope.DTR.drug = $scope.dpddata.history.drug;
                 if($scope.dpddata.history.personal)
                 $scope.DTR.personal = $scope.dpddata.history.personal;
                 var today = new Date();
                 var nowyear = today.getFullYear();
                 var nowmonth = today.getMonth();
                 var nowday = today.getDate();

                   $scope.DTR.pid = data._id;
                   birth = new Date(data.bod);
                   var birthyear = birth.getFullYear();
                   $scope.age = nowyear - birthyear;

                   for(i in $scope.DTR.past)
                   {

                     $scope.DTR.pasty[i] = {};
                     $scope.DTR.pastm[i] = {};
                     $scope.DTR.pastd[i] = {};
                     var day = $scope.DTR.past[i].duration;
                     if(day>364)
                     {
                       $scope.DTR.pasty[i] = day%365;
                       day = day/365;
                     }
                     if(day>29)
                     {
                       $scope.DTR.pastm[i] = day%30;
                       day = day/30;
                     }
                     $scope.DTR.pastd[i] = day;
                   }
                   for(i in $scope.DTR.family)
                   {
                     $scope.DTR.familyy[i] = {};
                     $scope.DTR.familym[i] = {};
                     $scope.DTR.familyd[i] = {};
                     var day = $scope.DTR.family[i].duration;
                     if(day>364)
                     {
                       $scope.DTR.pastfamilyy[i] = day%365;
                       day = day/365;
                     }
                     if(day>29)
                     {
                       $scope.DTR.familym[i] = day%30;
                       day = day/30;
                     }
                     $scope.DTR.familyd[i] = day;
                   }
                   for(i in $scope.DTR.drug)
                   {
                     $scope.DTR.drugy[i] = {};
                     $scope.DTR.drugm[i] = {};
                     $scope.DTR.drugd[i] = {};
                     var day = $scope.DTR.drug[i].duration;
                     if(day>364)
                     {
                       $scope.DTR.drugy[i] = day%365;
                       day = day/365;
                     }
                     if(day>29)
                     {
                       $scope.DTR.drugm[i] = day%30;
                       day = day/30;
                     }
                     $scope.DTR.drugd[i] = day;
                   }
                   for(i in $scope.DTR.personal)
                   {
                     $scope.DTR.personaly[i] = {};
                     $scope.DTR.personalm[i] = {};
                     $scope.DTR.personald[i] = {};
                     var day = $scope.DTR.personal[i].duration;
                     if(day>364)
                     {
                       $scope.DTR.personaly[i] = day%365;
                       day = day/365;
                     }
                     if(day>29)
                     {
                       $scope.DTR.personalm[i] = day%30;
                       day = day/30;
                     }
                     $scope.DTR.personald[i] = day;
                   }

        }

        $http.get('/doctor/treatment')
        .success(function(data) {
          if(data.status === 200)
          {
            $scope.data = data.data[0];

            for(hf in $scope.data.treatment.history.family)
              {  if(angular.isUndefined($scope.fmly.DTHF))
                {
                  $scope.fmly.DTHF=[];
                }
                $scope.fmly.DTHF[$scope.data.treatment.history.family[hf]] = $scope.data.treatment.history.family[hf];}
            for(hp in $scope.data.treatment.history.personal)
            {  if(angular.isUndefined($scope.prsnl.DTHP))
              {
                $scope.prsnl.DTHP=[];
              }

               $scope.prsnl.DTHP[$scope.data.treatment.history.personal[hp]] = $scope.data.treatment.history.personal[hp];
             }
             for(hp in $scope.HP)
             {  if(angular.isUndefined($scope.prsnl.DTHP))
               {
                 $scope.prsnl.DTHP=[];
               }

                $scope.prsnl.DTHP[$scope.HP[hp]] = $scope.HP[hp];
            }
          }
            else {
              $location.path("/doctor");

            }


          })
        .error(function(data) {

        });

       $scope.patientData = function() {

            $http.get('/doctor/patient/' + $scope.DTR.AID)
            .success(function(data) {
              pdata(data.data[0]);
                 })
            .error(function(data) {

            });
         };

          $scope.sco = [];
          $scope.sdu = [];
          $scope.sadd = [];

          $scope.caldu = function(coname) {
            $scope.DTR.DTCODU = [];
            $scope.xu.DTCODU[coname] = ($scope.xu.year[coname]*365)+($scope.xu.month[coname]*30)+($scope.xu.day[coname]);
            $scope.DTR.DTCODU = $scope.xu.DTCODU;
          }

          $scope.Y= [];
          $scope.Morn = function() {

            $scope.Y.DTMedTimeM= [];
            for(i in $scope.x.DTMedTimeM)
            {
              if($scope.x.DTMedTimeM[i] == true)
              $scope.Y.DTMedTimeM[i] = "M";
            }
            $scope.DTR.DTMedTimeM = $scope.Y.DTMedTimeM;

          }

          $scope.After = function() {

            $scope.Y.DTMedTimeA= [];

            for(i in $scope.x.DTMedTimeA)
            {
              if($scope.x.DTMedTimeA[i] == true)
              $scope.Y.DTMedTimeA[i] = "A";
            }
            $scope.DTR.DTMedTimeA = $scope.Y.DTMedTimeA;
          }

          $scope.even = function() {

            $scope.Y.DTMedTimeE= [];
            for(i in $scope.x.DTMedTimeE)
            {
              if($scope.x.DTMedTimeE[i] == true)
              $scope.Y.DTMedTimeE[i] = "E";
            }
            $scope.DTR.DTMedTimeE = $scope.Y.DTMedTimeE;

          }

          $scope.night = function() {

            $scope.Y.DTMedTimeN= [];
            for(i in $scope.x.DTMedTimeN)
            {
              if($scope.x.DTMedTimeN[i] == true)
              $scope.Y.DTMedTimeN[i] = "N";
            }
            $scope.DTR.DTMedTimeN = $scope.Y.DTMedTimeN;

          }


        $scope.showeco = function() {
          if($scope.DTR.DTECO)
          {

            if($scope.data.treatment.co.filter(function(e) { return e.name == $scope.DTR.DTECO; }).length <= 0)
            {
              $scope.data.treatment.co.push({'name' :$scope.DTR.DTECO});
              $http.post('/doctor/treatment/co', {DCo:$scope.DTR.DTECO})
              .success(function(data) {});
              $scope.DTR.DTECO = [];
            }

          }
        }
        $scope.showCVS = function() {
          if($scope.DTR.ECVS1)
          { if(!($scope.data.treatment.examination[0].status.includes($scope.DTR.ECVS1)))
            {
              $scope.data.treatment.examination[0].status.push($scope.DTR.ECVS1);
              $http.post('/doctor/treatment/examination/cvs', {DCVS:$scope.DTR.ECVS1})
              .success(function(data) {});
              $scope.DTR.ECVS1 = [];
            }
          }
        }
        $scope.delCVS = function(cvs) {
          if(cvs)
          {
              $scope.data.treatment.examination[0].status.delete(cvs);
              $http.post('/doctor/treatment/examination/cvs/delete', {DCVS:cvs})
              .success(function(data) {});
            }
        }
        $scope.showRS = function() {
          if($scope.DTR.ERS1)
          {
            if(!($scope.data.treatment.examination[1].status.includes($scope.DTR.ERS1)))
              {
              $scope.data.treatment.examination[1].status.push($scope.DTR.ERS1);
              $http.post('/doctor/treatment/examination/rs', {DRS:$scope.DTR.ERS1})
              .success(function(data) {});
              $scope.DTR.ERS1 = [];
            }
          }
        }
        $scope.showGS = function() {
          if($scope.DTR.EGS1)
          {
            if(!($scope.data.treatment.examination[2].status.includes($scope.DTR.EGS1)))
              {
              $scope.data.treatment.examination[2].status.push($scope.DTR.EGS1);
              $http.post('/doctor/treatment/examination/gs', {DGS:$scope.DTR.EGS1})
              .success(function(data) {});
              $scope.DTR.EGS1 = [];
              }
            }
        }
        $scope.showCNS = function() {
          if($scope.DTR.CNS1)
          {
            if(!($scope.data.treatment.examination[3].status.includes($scope.DTR.CNS1)))
              {
              $scope.data.treatment.examination[3].status.push($scope.DTR.CNS1);
              $http.post('/doctor/treatment/examination/cns', {DCNS:$scope.DTR.CNS1})
              .success(function(data) {});
              $scope.DTR.CNS1 = [];
            }
          }
        }

          $scope.showHF = function() {
            $scope.shf = $scope.DTR.DTHF;

            if($scope.shf != null)
            {
            $scope.shf = Object.keys($scope.shf).filter(function(k){return $scope.shf[k]});
          }

        }

        $scope.showHP = function() {
            $scope.shp = $scope.DTR.DTHP;

            if($scope.shp != null)
            {
            $scope.shp = Object.keys($scope.shp).filter(function(k){return $scope.shp[k]});
          }

        }

        $scope.showEHP = function() {

              $scope.data.treatment.history.personal.push(  $scope.DTR.DTEHP);
              $scope.DTR.DTEHP = [];

          }

          $scope.pasts = [];
          $scope.addEFMLY= function(hf) {
            if(angular.isUndefined($scope.DTR.family))
            {
              $scope.DTR.family=[];
            }
            if(angular.isUndefined($scope.fmly.DTHFR))
            {
                $scope.fmly.DTHFR = [];

              }



            if(($scope.fmly.DTHF !== undefined)  && ($scope.DTR.family.filter(function(e) { return e.name == $scope.fmly.DTHF[hf]; }).length <= 0))
            {
              if(($scope.fmly.DTHF[hf] !== undefined))
              {
                var duration = ($scope.fmly.year[hf]*365)+($scope.fmly.month[hf]*30)+($scope.fmly.day[hf]);

                $scope.DTR.family.push({"name":$scope.fmly.DTHF[hf],"relation":$scope.fmly.DTHFR[hf],"duration":duration});
                $scope.fmly.DTHF[hf]= undefined;
                $scope.fmly.DTHFR[hf]= undefined;
                $scope.fmly.year[hf] =0;
                $scope.fmly.month[hf]=0;
                $scope.fmly.day[hf]=0;
              }

            }
          };

          $scope.removeEFMLY = function(index) {
          //var index = $scope.DTR.family.indexOf({"name":familyToRemove});
          $scope.DTR.family.splice(index, 1);
          //delete $scope.DTR.family[index];

          };

          $scope.addEPRSNL= function(hp,n) {
            if(angular.isUndefined($scope.DTR.personal))
            {
              $scope.DTR.personal=[];
            }

            if(($scope.prsnl.DTHP[hp] !== undefined) && ($scope.DTR.personal.filter(function(e) { return e.name == $scope.prsnl.DTHP[hp]; }).length <= 0))
            {
              var duration = ($scope.prsnl.year[hp]*365)+($scope.prsnl.month[hp]*30)+($scope.prsnl.day[hp]);

              $scope.DTR.personal.push({"name":$scope.prsnl.DTHP[hp],"status":$scope.prsnl.DTHPS[hp],"duration":duration});
              if(n === 2)
              {
                $scope.prsnl.DTHPS[hp]= undefined;
              }
              else if(n === 0)
              {
                $scope.prsnl.DTHP[hp] = undefined;
                $scope.prsnl.DTHPS[hp]= undefined;
              }
              $scope.prsnl.year[hp] =0;
              $scope.prsnl.month[hp]=0;
              $scope.prsnl.day[hp]=0;
            }

            };

          $scope.removeEPRSNL = function(index) {
          //var index = $scope.DTR.personal.indexOf(index);

          $scope.DTR.personal.splice(index, 1);
          //delete $scope.DTR.personal[index];

          };

          $scope.addEPST= function() {
            if(angular.isUndefined($scope.DTR.past))
            {
              $scope.DTR.past=[];
            }
            if(angular.isUndefined($scope.DTR.pasty))
            {
              $scope.DTR.pasty=[];
            }
            if(angular.isUndefined($scope.DTR.pastm))
            {
              $scope.DTR.pastm=[];
            }
            if(angular.isUndefined($scope.DTR.pastd))
            {
              $scope.DTR.pastd=[];
            }

              if((typeof $scope.DTR.DTEHPTName1 !== 'undefined') && ($scope.DTR.past.filter(function(e) { return e.name == $scope.DTR.DTEHPTName1; }).length <= 0))
              {
                $scope.DTR.past.push({"name":$scope.DTR.DTEHPTName1,"duration":0});
                for(key in $scope.DTR.past)
                {
                  if($scope.DTR.past[key].name==$scope.DTR.DTEHPTName1)
                  {

                    $scope.DTR.pasty[key] = 0;
                    $scope.DTR.pastm[key] = 0;
                    $scope.DTR.pastd[key] = 0;
                  }
                }
              }

              $scope.DTR.DTEHPTName1=undefined;

            };

          $scope.removeEPST = function(index) {

          $scope.DTR.past.splice(index, 1);

          };

          $scope.pastname= function(name,index) {
              $scope.DTR.past[index].name=name;
            };


          $scope.drugs = [];
          $scope.addEDRG= function() {
            if(angular.isUndefined($scope.DTR.drug))
            {
              $scope.DTR.drug=[];
            }
            if(angular.isUndefined($scope.DTR.drugy))
            {
              $scope.DTR.drugy=[];
            }
            if(angular.isUndefined($scope.DTR.drugm))
            {
              $scope.DTR.drugm=[];
            }
            if(angular.isUndefined($scope.DTR.drugd))
            {
              $scope.DTR.drugd=[];
            }
            if((typeof $scope.DTR.DTEHDRGName1 !== 'undefined') && ($scope.DTR.drug.filter(function(e) { return e.name == $scope.DTR.DTEHDRGName1; }).length <= 0))
            {
              $scope.DTR.drug.push({"name":$scope.DTR.DTEHDRGName1,"duration":0});
              for(key in $scope.DTR.drug)
              {
                if($scope.DTR.drug[key].name==$scope.DTR.DTEHDRGName1)
                {

                  $scope.DTR.drugy[key] = 0;
                  $scope.DTR.drugm[key] = 0;
                  $scope.DTR.drugd[key] = 0;
                }
              }
            }
              $scope.DTR.DTEHDRGName1=undefined;


            };

          $scope.removeEDRG = function(index) {

          $scope.DTR.drug.splice(index, 1);

          };
          $scope.pst = [];
          $scope.pst.DTEHPTDU = [];
          $scope.fmly = [];
          $scope.fmly.DTHFDU = [];
          $scope.drg = [];
          $scope.drg.DTEHDRGDU = [];
          $scope.prsnl = [];
          $scope.prsnl.DTHPDU = [];

          $scope.pastdu = function(index) {

            $scope.DTR.past[index].duration = ($scope.pst.year[index]*365)+($scope.pst.month[index]*30)+($scope.pst.day[index]);

          }

          $scope.drugdu = function(index) {


            $scope.DTR.drug[index].duration = ($scope.drg.year[index]*365)+($scope.drg.month[index]*30)+($scope.drg.day[index]);

          }
          $scope.personaldu = function(coname) {

            $scope.DTR.DTHPDU = [];
            $scope.prsnl.DTHPDU[coname] = ($scope.prsnl.year[coname]*365)+($scope.prsnl.month[coname]*30)+($scope.prsnl.day[coname]);
            $scope.DTR.DTHPDU = $scope.prsnl.DTHPDU;

          }

            $scope.showerep = function() {
              if($scope.DTR.DTERep)
              {
                if(!($scope.data.treatment.report.includes($scope.DTR.DTERep)))
                  {
                    $scope.data.treatment.report.push($scope.DTR.DTERep);
                    $http.post('/doctor/treatment/report', {DRep:$scope.DTR.DTERep})
                    .success(function(data) {});
                    $scope.DTR.DTERep = [];
                  }
              }
            }

          $scope.showedig = function() {
            if($scope.DTR.DTEDig)
            {
              if(!($scope.data.treatment.dignosis.includes($scope.DTR.DTEDig)))
                {
                  $scope.data.treatment.dignosis.push($scope.DTR.DTEDig);
                  $http.post('/doctor/treatment/dignosis', {DDig:$scope.DTR.DTEDig})
                  .success(function(data) {});
                  $scope.DTR.DTEDig = [];
                }
              }
            }

          $scope.showeadv = function() {
            if($scope.DTR.DTEAdv)
            {
              if(!($scope.data.treatment.advise.includes($scope.DTR.DTEAdv)))
                {
                  $scope.data.treatment.advise.push($scope.DTR.DTEAdv);
                  $http.post('/doctor/treatment/advise', {DAdv:$scope.DTR.DTEAdv})
                  .success(function(data) {});
                  $scope.DTR.DTEAdv = [];
                }
              }
            }

        $scope.Meds = []
        $scope.addEMed= function(i) {
            if($scope.DTR.DTMedName[i])
            {
              $scope.Meds.push({});
              if(!($scope.data.treatment.medicine.includes($scope.DTR.DTMedName[i])))
              {

                  $scope.data.treatment.medicine.push($scope.DTR.DTMedName[i]);
                  $http.post('/doctor/treatment/medicine/add', {DMed:$scope.DTR.DTMedName[i]})
                  .success(function(data) {});
                }
            }
          };

        $scope.removeEMed = function(medToRemove) {
        var index = $scope.Meds.indexOf(medToRemove);
        $scope.Meds.splice(index, 1);
        delete $scope.DTR.DTMedName[index+1];
        };

           $scope.previous = function () {
             var modalInstance = $uibModal.open({
               templateUrl: 'Treatment_Previous.html',
               controller: 'PreviousTreatmentcontroller',

               resolve: {
                 previous_tr: function () {

                   return $scope.dpddata.case_detail;

                 }
               }
             });
           };

           $scope.view = function () {
             var modalInstance = $uibModal.open({
               templateUrl: 'Treatment_Patient_Profile.html',
               controller: 'PatientViewcontroller',

               resolve: {
                 view_more: function () {
                   return $scope.dpddata;
                 }
               }
             });
           };

           $scope.finish = function () {
             if($scope.DTR.AID === undefined )
             {
               $window.alert("Select Patient...");
             }
             else
             {
              var modalInstance = $uibModal.open({
               templateUrl: 'Treatment_View.html',
               controller: 'TreatmentViewcontroller',

               resolve: {
                 treat: function () {
                   return $scope.DTR;
                 }
               }
              });
            }
           };

});
TreatmentDrData.controller('PatientViewcontroller' , function($scope, $http,$uibModalInstance, view_more){
 $scope.data = view_more;

  $scope.ok = function () {
    $uibModalInstance.dismiss('cancel');
  };

});
TreatmentDrData.controller('TreatmentViewcontroller' , function($scope, $http,$location,$uibModalInstance,$window, treat){
 $scope.DTR = treat;
 $scope.page = "view";
$scope.ok = function () {
      if (confirm('Do you want to complete treatment?')) {
      $http.post('/patient/treatment/data/insert', $scope.DTR)
      .success(function(data) {

               //$scope.ptddata = data;

               if(data.status === 200)
               {
                  $window.alert(data.error);
                  $scope.page = "print";
               }


           })
      .error(function(data) {

      });
  }
  };
  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };
  $scope.done = function () {
      $window.location.reload();
  };
$scope.print = function () {
  var printContents = document.getElementById("printTreat").innerHTML;
  var popupWin = window.open('', '', '');
  popupWin.document.open();
  popupWin.document.write('<html><head></head><body onload="window.print()">' + printContents + '</body></html>');
  popupWin.document.close();
}

});
TreatmentDrData.controller('PreviousTreatmentcontroller' , function($scope, $http,$uibModalInstance, previous_tr){

  $scope.data = previous_tr;


   $scope.ok = function () {
     $uibModalInstance.dismiss('cancel');
   };

   $scope.visiting_index = 1;

    $scope.next = function () {
        if ($scope.visiting_index >= $scope.data.visit_detail.length - 1) {
            //$scope.visiting_index = 0;
        } else {
            $scope.visiting_index++;
        }
      }

      $scope.previous = function () {
          if ($scope.visiting_index < 2) {
              //$scope.visiting_index = 0;
          } else {
              $scope.visiting_index--;
          }
        }


});

TreatmentDrData.filter('range', function() {
  return function(input, min, max) {
    min = parseInt(min); //Make string input int
    max = parseInt(max);
    for (var i=min; i<max; i++)
      input.push(i);
    return input;
  };
});
TreatmentDrData.filter('setDecimal', function ($filter) {
    return function (input, places) {
        if (isNaN(input)) return input;
        // If we want 1 decimal place, we want to mult/div by 10
        // If we want 2 decimal places, we want to mult/div by 100, etc
        // So use the following to create that factor
        var factor = "1" + Array(+(places > 0 && places + 1)).join("0");

        return Math.floor(input * factor) / factor;
    };
});
