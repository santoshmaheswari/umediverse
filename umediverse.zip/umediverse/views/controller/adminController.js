var AdminData = angular.module('AdminData', []);
AdminData.controller('ADPwdChngcontroller', function($scope, $http,$location,$window) {
  $scope.change = function() {
    if (confirm('Do you want to Change Password?')) {

  $http.post('/admin/change_password', $scope.Pwd)
             .success(function(data) {
            $scope.Pwd = {}; // clear the form so our user is ready to enter another
            if(data.status === 200)
            {
              $location.path("/admin");
              $window.alert(data.error);
            }
            else {
              $window.alert(data.error);
            }

        })
   .error(function(data) {
            
   });
 }
 }
});
