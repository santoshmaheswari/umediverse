var app=angular.module('AppointmentData' , []);
app.controller('StfappointmentCtrl' , function($scope, $http,$location,$window,$route){

  $scope.details=[];

      $http.get('/hospital/doctor/data')
      .success(function(data) {
        if(data.status === 200)
        {

          $scope.ddetails = data.data;
        }

      })
      .error(function(data) {

      });

        $http.get('/appointment/fees/')
            .success(function(data) {
              if(data.status === 200)
              {
                for(var fee of data.data)
                {
                  $scope.hfees = fee.case_fees;
                }
              }

            })
            .error(function(data) {


            });


        $scope.get_fees = function(value)
                         {

                             $scope.AP.Fees = value;
                         }

        $scope.findvalue = function() {

          $http.post('/appointment/data/',$scope.PT)
          .success(function(data) {
            if(data.status === 200)
            {
                   $scope.P = data.data[0];
                 }
                 else {
                   $window.alert(data.error);
                 }

               })
          .error(function(data) {

          });
       };

       $scope.submit = function() {
         $scope.AP.pid = $scope.P._id;
           if (confirm('Do you want to confirm appointment?')) {
         $http.post('/appointment/',$scope.AP)
         .success(function(data) {
            $scope.AP = [];
            $scope.PT = [];

                  if(data.status === 200)
                  {
                    //$location.path("/staff/appointment");
                    $window.alert(data.error);
                    $route.reload();
                  }
                  else {
                    console.log(data);
                    $window.alert(data.error);

                  }

              })
         .error(function(data) {

         });
       }
     }
});

app.controller('DrappointmentCtrl' , function($scope, $http,$location,$window,  $route){




        $http.get('/appointment/fees/')
            .success(function(data) {
              if(data.status === 200)
              {
                for(var fee of data.data)
                {
                  $scope.hfees = fee.case_fees;
                }
              }

            })
            .error(function(data) {

            });


        $scope.get_fees = function(value)
                         {

                             $scope.AP.Fees = value;
                         }

        $scope.findvalue = function() {

          $http.post('/appointment/data/',$scope.PT)
          .success(function(data) {
            if(data.status === 200)
            {
                   $scope.P = data.data[0];
                 }
                 else {
                   $window.alert(data.error);
                 }


               })
          .error(function(data) {

          });
       };

       $scope.submit = function() {
         $scope.AP.pid = $scope.P._id;
if (confirm('Do you want to confirm appointment?')) {
         $http.post('/appointment/',$scope.AP)
         .success(function(data) {

            $scope.AP = [];
            $scope.PT = [];

                  if(data.status === 200)
                  {
                    //$location.path("/doctor/appointment");
                    $window.alert(data.error);
                    $route.reload();

                  }
                  else {
                    $window.alert(data.error);

                  }

              })
         .error(function(data) {

         });
       };
     }

});
