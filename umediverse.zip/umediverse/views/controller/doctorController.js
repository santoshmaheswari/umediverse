var DoctorData = angular.module('DoctorData', []);

DoctorData.controller('DRviewcontroller' , function($scope, $http,$location,$window){

  $scope.details=[];



  $http.get('/doctor/data/')
     .success(function(data) {
       if(data.status === 200)
       {
         $scope.dr = data.data[0];
         $scope.dr.bod = new Date($scope.dr.bod);
         $scope.dr.fname  = $scope.dr.name.fname;
         $scope.dr.mname  = $scope.dr.name.mname;
         $scope.dr.lname  = $scope.dr.name.lname;
         $scope.dr.street  = $scope.dr.add.street;
         $scope.dr.l_mark  = $scope.dr.add.l_mark;
         $scope.dr.city  = $scope.dr.add.city;
         $scope.dr.pincode  = $scope.dr.add.pincode;
         $scope.dr.state  = $scope.dr.add.state;
         $scope.dr.country  = $scope.dr.add.country;
         $scope.dr.dist  = $scope.dr.add.dist;
         $scope.dr.oldpincode  = $scope.dr.add.pincode;
       }
       else {
         $location.path("/doctor");

       }


     })
     .error(function(data) {

     });
     $scope.update = function() {
       if (confirm('Do you want to Update Profile')) {


             var fd = new FormData();
             for(var key in $scope.dr){

               fd.append(key, $scope.dr[key]);
             }
               $http.post('/doctor/update', fd,
               {
                   transformRequest: angular.identity,
                   headers: {'Content-Type': undefined}
               })
                .success(function(data) {
               $scope.DR = {}; // clear the form so our user is ready to enter another

               if(data.status === 200)
               {
                 $location.path("/doctor/profile");
                 $window.alert(data.error);
               }

           })
      .error(function(data) {

      });
    }

}

});

DoctorData.controller('DRPwdChngcontroller' , function($scope, $http,$location,$window){

      $scope.change = function() {
        if (confirm('Do you want to Change Password?')) {

      $http.post('/doctor/change_password', $scope.Pwd)
                 .success(function(data) {
                $scope.Pwd = {}; // clear the form so our user is ready to enter another
                if(data.status === 200)
                {
                  $location.path("/doctor");
                  $window.alert(data.error);
                }
                else {
                  $window.alert(data.error);
                }

            })
       .error(function(data) {

       });
     }
     }


});


DoctorData.controller('DHcontroller' , function($scope, $http,$location){

  $scope.details=[];
  $http.get('/doctor/hospital/')
     .success(function(data) {
       if(data.status === 200)
       {
         $scope.dhdata = data.data;
       }
         else {
           $location.path("/doctor");

         }

     })
     .error(function(data) {

     });

});

DoctorData.controller('DDashcontroller' , function($scope, $http,$location,$routeParams,DoctorSession){

         $http.get('/doctor/hospital/s/' + $routeParams.hid)
         .success(function(data) {
           if(data.status===200)
           {
           DoctorSession.isValid();
         }

           })
           .error(function(data) {

           });


});

//doctor registration controller
DoctorData.controller('DRcontroller' , function($scope, $http,$location,$window/*captcha*/){

    $scope.DR = {};
    //$scope.Captcha = function() {captch.Captcha();};

    $scope.verify_did = function() {
      if($scope.DR["DReg"])
      {
        var fd = new FormData();
        fd.append("DReg", $scope.DR["DReg"]);
        $http.post('/doctor/id/verify',fd,
        {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        })
        .success(function(data) {
          if(data.status === 200)
          {
            $scope.id_status = "";
          }
          else {
            $scope.id_status = "Already Registered";
          }
        }).error(function(data) {

        });
      }
    }

    $scope.verify = function() {
      if($scope.DR["DUName"])
      {
        var fd = new FormData();
        fd.append("DUName", $scope.DR["DUName"]);
        $http.post('/doctor/username/verify',fd,
        {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        })
        .success(function(data) {
          if(data.status === 200)
          $scope.user_status = data.error;
        }).error(function(data) {

        });
      }
    }

    $scope.Reset = function() {
      $scope.id_status = "";
      $scope.user_status = "";
    }

     // when submitting the add form, send the text to the node API
       $scope.DRsubmit = function() {
         if($scope.user_status === "Available" || $scope.user_status === "")
         {
         if (confirm('Do you want to confirm registration?')) {

         var fd = new FormData();
         for(var key in $scope.DR){
           fd.append(key, $scope.DR[key]);
       }

       $http.post('/doctor/registration', fd,
       {
           transformRequest: angular.identity,
           headers: {'Content-Type': undefined}
       })
        .success(function(data) {
                   $scope.DR = {}; // clear the form so our user is ready to enter another

                   if(data.status === 200)
                   {
                     $location.path("/doctor/registration");
                     $window.alert(data.error);
                   }

               })
          .error(function(data) {

          });
       }
     }
     else if($scope.user_status === "Already Registered") {
       $window.alert("Username Already Registered");
     }
     else if($scope.id_status === "Already Registered")
     {
       $window.alert("Registration Number Already Registered");
     }
     };


});
DoctorData.controller('DRCaseViewcontroller' ,['$scope', '$http','$routeParams', function($scope, $http,$routeParams){

       $http.get('/doctor/patient/' + $routeParams.appid)
       .success(function(data) {

            if(data.status === 200)
            {
              $scope.caseiddetail = data.data[0];

            }

        })
        .error(function(data) {

        });

  }]);

DoctorData.controller('DRCasecontroller' , function($scope, $http,$location){

$scope.DT={};

  $scope.printDiv = function(divName) {
  var printContents = document.getElementById(divName).innerHTML;
  var popupWin = window.open('', '_parent', '');
  popupWin.document.open();
  popupWin.document.write('<html><head></head><body onload="window.print()">' + printContents + '</body></html>');
  popupWin.document.close();
}

          $http.get('/doctor/case_report')
          .success(function(data) {
            if(data.status === 200)
            {
               $scope.casedetail = data.data;
             }
               else {
                  $location.path("/doctor");
                }

           })
           .error(function(data) {

           });

            $scope.SearchData = function() {

                 $http.post('/doctor/case_report/bydate',$scope.DT)
                 .success(function(data) {
                   if(data.status === 200)
                   {
                      $scope.casedetail = data.data;
                    }
                      else {
                         $location.path("/doctor");
                       }

                  })
                  .error(function(data) {

                  });

            }
});

DoctorData.controller('DRInvcontroller' ,['$scope', '$http','$location','$window', function($scope, $http,$location,$window){
       $http.get('/doctor/patient/investigation/data')
       .success(function(data) {

            if(data.status === 200)
            {
              $scope.invdetail = data.data;
            }

        })
        .error(function(data) {

        });

        $scope.labName = function(i) {
          $http.post('/laboratory/getName',{LabId:$scope.PT.LabId})
          .success(function(data) {
            if(data.status === 200)
            {
               $scope.PT.LabName = data.name;
            }

           })
           .error(function(data) {

           });

        }

        $scope.setIndex = function(i) {
          for(x in $scope.invdetail)
          {

            if($scope.invdetail[x].case_detail.visit_detail._id === i)
            {

              $scope.PT.id = $scope.invdetail[x]._id;
              $scope.PT.case = $scope.invdetail[x].case_detail._id;
              $scope.PT.visit = $scope.invdetail[x].case_detail.visit_detail._id;
              $scope.PT.app_date = $scope.invdetail[x].case_detail.visit_detail.app_date;
              $scope.invst = $scope.invdetail[x].case_detail.visit_detail.treatment.report;
              $scope.PT.dir_name = $scope.invdetail[x].dir_name;
              break;

            }
          }

        }

        $scope.uploadInv = function() {
          if (confirm('Do you want to upload investigation?')) {

          var fd = new FormData();
          for(var key in $scope.PT){
            fd.append(key, $scope.PT[key]);
        }
        $http.post('/doctor/patient/investigation/upload', fd,
        {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        })
         .success(function(data) {
                    $scope.PT = {}; // clear the form so our user is ready to enter another
                    if(data.status === 200)
                    {

                      $window.alert(data.error);
                      $window.location.reload();
                    }

                })
           .error(function(data) {

           });
        }
      };
  }]);
