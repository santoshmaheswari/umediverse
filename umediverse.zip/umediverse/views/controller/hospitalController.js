var HospitalData = angular.module('HospitalData', ['ui.bootstrap']);

HospitalData.controller('HOviewcontroller' , function($scope, $http,$location,$window){

  $scope.details=[];
  $http.get('/hospital/data/')
     .success(function(data) {
       if(data.status === 200)
       {
       $scope.ho = data.data[0];
       $scope.ho.est_date = new Date($scope.ho.est_date);

       $scope.ho.street  = $scope.ho.add.street;
       $scope.ho.l_mark  = $scope.ho.add.l_mark;
       $scope.ho.city  = $scope.ho.add.city;
       $scope.ho.pincode  = $scope.ho.add.pincode;
       $scope.ho.state  = $scope.ho.add.state;
       $scope.ho.country  = $scope.ho.add.country;
       $scope.ho.dist  = $scope.ho.add.dist;
       $scope.ho.x  = $scope.ho.location.x;
       $scope.ho.y  = $scope.ho.location.y;
       $scope.ho.oldpincode  = $scope.ho.add.pincode;
      }
      else {
        $location.path("/hospital");
      }



     })
     .error(function(data) {

     });

     $scope.update = function() {
       if (confirm('Do you want to Update Profile?')) {


             var fd = new FormData();
             for(var key in $scope.ho){

               fd.append(key, $scope.ho[key]);
             }
               $http.post('/hospital/update', fd,
               {
                   transformRequest: angular.identity,
                   headers: {'Content-Type': undefined}
               })
                .success(function(data) {
               $scope.ho = {}; // clear the form so our user is ready to enter another

               if(data.status === 200)
               {
                 $location.path("/hospital/profile");
                 $window.alert(data.error);
               }

           })
      .error(function(data) {

      });
    }
}

});

HospitalData.controller('HOPwdChngcontroller' , function($scope, $http,$location,$window){

      $scope.change = function() {
        if (confirm('Do you want to Change Password?')) {

      $http.post('/hospital/change_password', $scope.Pwd)
                 .success(function(data) {
                $scope.Pwd = {}; // clear the form so our user is ready to enter another
                if(data.status === 200)
                {
                  $location.path("/hospital");
                  $window.alert(data.error);
                }
                else {
                  $window.alert(data.error);
                }

            })
       .error(function(data) {

       });
     }
   }


});


HospitalData.controller('DoctorApproveController' , function($scope, $http,$location,$window){

  $scope.getdata = function() {

      $http.get('/doctor/approve/' + $scope.DR.DDET)
      .success(function(data) {
        if(data.status === 500)
        {
          $location.path("/hospital");
          $window.alert(data.error);
        }
        else {
          $scope.details = data.data;
        }

        })
        .error(function(data) {

        });
  }

  $scope.Reset = function() {
    $scope.details = "";
}

  $scope.doctorsubmit = function() {

      if($scope.details)
      {
        $scope.DR.name  = $scope.details[0].name;

        if (confirm('Do you want to Approve Doctor?')) {

        $http.post('/hospital/doctor/approve', $scope.DR)
         .success(function(data) {
                  if(data.status === 200)
                  {
                    $location.path("/hospital");
                    $window.alert(data.error);
                  }
                  else {
                    $window.alert(data.error);
                  }

              })
         .error(function(data) {

         });
       }
      }
else {
  $window.alert("Enter Proper Detail");
}


    };

  });

HospitalData.controller('doctorShiftAddController' , function($scope, $http,$location,$window){
 $scope.HDS = [];
 $scope.HDS.ST = [];
 $scope.HDS.ET = [];
 $scope.ST = [];
 $scope.ST.H= [];
 $scope.ST.M= [];
 $scope.ET= [];
 $scope.ET.H= [];
 $scope.ET.M= [];

        $http.get('/hospital/doctor/no_shift/data')
        .success(function(data) {

          if(data.status === 200)
          {
            $scope.ddetails = data.data;
          }


        })
        .error(function(data) {

        });

       $scope.doctorShift = function() {

        if (confirm('Do you want to submit data?')) {

            $http.post('/hospital/doctor/shift/s', {ST:$scope.HDS.ST,ET:$scope.HDS.ET,DR:$scope.HDS.DR
                                                    ,session:$scope.HDS.session,TP:$scope.HDS.TP,Day:$scope.HDS.Day})
            .success(function(data) {
                     if(data.status === 200)
                     {
                       $location.path("/hospital");
                       $window.alert(data.error);
                     }
                     else {
                        $window.alert(data.error);
                     }

                 })
            .error(function(data) {

            });
          }
         };
         $scope.shifts = [];

         $scope.delShift = function(del) {
           var index = $scope.shifts.indexOf(del);
           $scope.shifts.splice(index, 1);
         }
          $scope.addShift = function() {
          $scope.shifts.push({});
         }
         $scope.CalST = function(i) {
          $scope.HDS.ST[i] = $scope.ST.H[i]+($scope.ST.M[i]/100);

         }
         $scope.CalET = function(i) {
           $scope.HDS.ET[i] = $scope.ET.H[i]+($scope.ET.M[i]/100);

         }

});

HospitalData.controller('doctorShiftViewController' , function($scope, $http,$location,$window,$uibModal){
$scope.HDSData  = [];
$scope.HDSData.shift  = [];
  $scope.ST = [];
  $scope.ST.H= [];
  $scope.ST.M= [];
  $scope.ET= [];
  $scope.ET.H= [];
  $scope.ET.M= [];
$scope.Mo = [];
$scope.Tue = [];
$scope.Thu = [];
$scope.Wed = [];
$scope.Fri = [];
$scope.Sat = [];
$scope.Sun = [];



        $http.get('/hospital/doctor/shift/data')
        .success(function(data) {
          if(data.status === 200)
          {
            $scope.ddetails = data.data;
          }

        })
        .error(function(data) {

        });

       $scope.searchShift = function() {

         $http.get('/hospital/doctor/shift/data/'+$scope.HDSView.DR)
         .success(function(data) {
           if(data.status === 200)
           {
             $scope.HDSData = data.data[0].doctor;
             for(i in $scope.HDSData.shift)
             {
               if($scope.HDSData.shift[i].start.split(".")[0])
               {
                 $scope.ST.H[i] = parseInt($scope.HDSData.shift[i].start.split(".")[0]);
               }
               else {
                 $scope.ST.H[i] = 0;
               }
               if($scope.HDSData.shift[i].start.split(".")[1])
               {
                 $scope.ST.M[i] = parseInt($scope.HDSData.shift[i].start.split(".")[1]);
               }
               else {
                 $scope.ST.M[i] = 0;
               }
               if($scope.HDSData.shift[i].end.split(".")[0])
               {
                 $scope.ET.H[i] = parseInt($scope.HDSData.shift[i].end.split(".")[0]);
               }
               else {
                 $scope.ET.H[i] = 0;
               }
               if($scope.HDSData.shift[i].end.split(".")[1])
               {
                 $scope.ET.M[i] = parseInt($scope.HDSData.shift[i].end.split(".")[1]);
               }
               else {
                 $scope.ET.M[i] = 0;
               }


               for(j in $scope.HDSData.shift[i].day)
               {
                 if($scope.HDSData.shift[i].day[j] === "Monday")
                 {
                   $scope.Mo[i] = true;
                 }
                 else if($scope.HDSData.shift[i].day[j] === "Tuesday")
                 {
                   $scope.Tue[i] = true;
                 }
                 else if($scope.HDSData.shift[i].day[j] === "Wednesday")
                 {
                   $scope.Wed[i] = true;
                 }
                 else if($scope.HDSData.shift[i].day[j] === "Thursday")
                 {
                   $scope.Thu[i] = true;
                 }
                 else if($scope.HDSData.shift[i].day[j] === "Friday")
                 {
                   $scope.Fri[i] = true;
                 }
                 else if($scope.HDSData.shift[i].day[j] === "Saturday")
                 {
                   $scope.Sat[i] = true;
                 }
                 else if($scope.HDSData.shift[i].day[j] === "Sunday")
                 {
                   $scope.Sun[i] = true;
                 }

               }
             }
           }

         })
         .error(function(data) {

         });
       }

       $scope.CalST = function(i) {
        $scope.HDSData.shift[i].start = $scope.ST.H[i]+($scope.ST.M[i]/100);
       }
       $scope.CalET = function(i) {
         $scope.HDSData.shift[i].end = $scope.ET.H[i]+($scope.ET.M[i]/100);
       }
       $scope.addShift = function() {
       $scope.HDSData.shift.push({day:[],session:'Morning',patient_count:0});
       var i = $scope.HDSData.shift.length-1;
       $scope.ET.H[i] = 0;
       $scope.ET.M[i] = 0;
       $scope.ST.H[i] = 0;
       $scope.ST.M[i] = 0;
      }


      $scope.updateShift = function () {
        var  length = $scope.HDSData.shift.length;
        for (var i = 0; i < length; i++) {
          if($scope.HDSData.shift[i].day)
            $scope.HDSData.shift[i].day.length = 0;
        }
        for(i=0;i<length;i++)
        {
          if($scope.Mo[i] === true)
          {

            $scope.HDSData.shift[i].day.push("Monday");
          }

          if($scope.Tue[i] === true)
          {
            $scope.HDSData.shift[i].day.push("Tuesday");
          }
          if($scope.Wed[i] === true)
          {
            $scope.HDSData.shift[i].day.push("Wednesday");
          }
          if($scope.Thu[i] === true)
          {
            $scope.HDSData.shift[i].day.push("Thursday");
          }
          if($scope.Fri[i] === true)
          {
            $scope.HDSData.shift[i].day.push("Friday");
          }
          if($scope.Sat[i] === true)
          {
            $scope.HDSData.shift[i].day.push("Saturday");
          }
          if($scope.Sun[i] === true)
          {
            $scope.HDSData.shift[i].day.push("Sunday");
          }

        }
        if (confirm('Do you want to Update Shift?')) {

            $http.post('/hospital/doctor/shift/update/s', $scope.HDSData)
            .success(function(data) {

                     if(data.status === 200)
                     {
                        $window.alert(data.error);
                     }


                 })
            .error(function(data) {

                   });
        }

      }

});

HospitalData.controller('doctorRelieveController' , function($scope, $http,$location,$window){

        $http.get('/hospital/doctor/data')
        .success(function(data) {
          if(data.status === 200)
          {
            $scope.ddetails = data.data;
          }
          else {
            $location.path("/hospital");
          }


        })
        .error(function(data) {

        });

       $scope.doctorRelieve = function() {
         if (confirm('Do you want to Relive Doctor?')) {

            $http.post('/hospital/doctor/relieve', $scope.DRR)
            .success(function(data) {
                     if(data.status === 200)
                     {
                       $location.path("/hospital");
                       $window.alert(data.error);
                     }
                     else {
                        $window.alert(data.error);
                     }

                 })
            .error(function(data) {

            });
          }
         };

         $scope.doctorSelected = function(i) {
           $scope.details = $scope.ddetails[i];
        }

});


HospitalData.controller('HOcontroller' , function($scope, $http,$location,$window){

//hospital registration controller
    $scope.HO = {};
$scope.contacts = [];

        $scope.verify_hid = function() {
          if($scope.HO["HLic"])
          {
            var fd = new FormData();
            fd.append("HLic", $scope.HO["HLic"]);
            $http.post('/hospital/id/verify',fd,
            {
                transformRequest: angular.identity,
                headers: {'Content-Type': undefined}
            })
            .success(function(data) {
              if(data.status === 200)
              {
                $scope.id_status = "Available";
              }
              else {
                $scope.id_status = "Already Registered";
              }
            }).error(function(data) {

            });
          }
        }

        $scope.Reset = function() {
          $scope.user_status = "";
          $scope.id_status = "";
        }



       // when landing on the page, get all todos and show them
       $scope.verify = function() {
         if($scope.HO["HUName"])
         {
          var fd = new FormData();
          fd.append("HUName", $scope.HO["HUName"]);
           $http.post('/hospital/username/verify',fd,
           {
               transformRequest: angular.identity,
               headers: {'Content-Type': undefined}
           })
           .success(function(data) {
             if(data.status === 200)
             $scope.user_status = data.error;
           }).error(function(data) {

           });
         }
       }
       // when submitting the add form, send the text to the node API
       $scope.HOsubmit = function() {
         if($scope.user_status === "Available")
         {
         if (confirm('Do you want to complete registration?')) {

         var fd = new FormData();
       for(var key in $scope.HO){

           fd.append(key, $scope.HO[key]);

       }
console.log("Hospital");
       $http.post('/hospital/registration', fd,
       {
           transformRequest: angular.identity,
           headers: {'Content-Type': undefined}
       })

          .success(function(data) {
                   $scope.HO = {}; // clear the form so our user is ready to enter another


                   if(data.status === 200)
                   {
                     $location.path("/");
                     $window.alert(data.error);
                   }

               })
          .error(function(data) {

          });
        }
      }
      else {
        $window.alert("Username Already Registered");
      }
       };

       $scope.addContact = function() {
           $scope.contacts.push({});
         };

       $scope.removeContact = function(contactToRemove) {
       var index = $scope.contacts.indexOf(contactToRemove);
       $scope.contacts.splice(index, 1);
     };
    // delete a todo after checking it

});

  HospitalData.controller('HOFeesController' , function($scope, $http,$location,$window){


      $http.get('/hospital/fees/')
         .success(function(data) {
           if(data.status === 200)
           {
             $scope.fee = data.data[0].case_fees;
           }
           else {
             $location.path("/hospital");
           }


         })
         .error(function(data) {

         });

        $scope.Feesvalue = function() {

          if (confirm('Do you want to update fees?')) {

              $http.post('/hospital/fees/',$scope.fee)
              .success(function(data) {


                       if(data.status === 200)
                       {
                         $location.path("/hospital");
                         $window.alert(data.error);
                       }

                   })
              .error(function(data) {

              });
            }
           };
    });

    HospitalData.controller('HospitalDoctorDetailController' , function($scope, $http,$location,$window,SharedScope){


        $http.get('/hospital/doctor/data')
           .success(function(data) {
             if(data.status === 200)
             {
               data  = data.data;
               $scope.hdrdetails = data;


               var did = new Array();
               data.forEach(function(datas) {

                dlength = did.length;
                 for(var i=0;i<dlength;i++)
                 {

                   if(did[i] === datas.doctor._id)
                   {
                     break;
                   }
                 }
                 if(i>=dlength)
                 {
                   did.push(datas.doctor._id);
                 }


               });

               $http.post('/doctor/hospital/data',{did : did})
               .success(function(data) {
                 if(data.status === 200)
                 {
                   data = data.data;
                   $scope.dhospitaldetails = data;
                   for(var j in $scope.hdrdetails)
                   {

                     for(var i in data)
                     {

                       if($scope.hdrdetails[j].doctor._id === data[i].did)
                       {
                         $scope.hdrdetails[j].doctor.dr = data[i];

                       }

                     }
                    /* if($scope.hdrdetails[j].doctor.is_present==true)
                     {
                       $scope.hdrdetails[j].doctor.is_present="Yes";
                     }
                     else {
                       $scope.hdrdetails[j].doctor.is_present="No"
                     }*/
                     var today = new Date();
                     var nowyear = today.getFullYear();
                     var nowmonth = today.getMonth();
                     var nowday = today.getDate();

                       doj = new Date($scope.hdrdetails[j].doctor.doj);
                       var dojyear = doj.getFullYear();
                       var dojmonth = doj.getMonth();
                       $scope.hdrdetails[j].doctor.expYear = nowyear - dojyear;
                       $scope.hdrdetails[j].doctor.expMonth = nowmonth - dojmonth;
                   }
                 }
                   else {
                      $location.path("/hospital");
                    }


               })
               .error(function(data) {

               });
             }
             else {
               $location.path("/hospital");
             }


           })
           .error(function(data) {

           });

           $scope.View_Data = function(data) {

             SharedScope.sharingData(data);
             $location.path("/hospital/doctor/data/view");

              };


      });

      HospitalData.controller('HDrViewcontroller' , function($scope, $http,$routeParams,$location,$window,SharedScope){


        $scope.drdata  = SharedScope.Data;

                $http.get('/hospital/doctor/data/' + $scope.drdata._id)
                 .success(function(data) {
                   if(data.status === 200)
                   {
                     $scope.doctor = data.data[0];
                   }
                   else {
                     $location.path("/hospital");
                   }


                 })
                 .error(function(data) {

                 });

                 $scope.View_Data = function() {
                   var data = ({"designation":$scope.drdata.designation,"salary":$scope.drdata.salary,
                                "special_fees":$scope.drdata.special_fees,"name":$scope.doctor.name,"did":$scope.doctor.did,"img":$scope.doctor.img})

                   //data.push(doctor)
                   SharedScope.sharingData(data);
                   $location.path("/hospital/doctor/update");
                    };

                    $scope.reload = function() {
                      SharedScope.sharingData(SharedScope.Data);
                    }
      });

      HospitalData.controller('HdoctorUpdateController' , function($scope, $http,$routeParams,$location,$window,SharedScope){


        $scope.hdr  = SharedScope.Data;

        $scope.update = function() {
          if (confirm('Do you want to update Doctor Profile?')) {

              $http.post('/hospital/doctor/update',$scope.hdr)
              .success(function(data) {
                       //$scope.PT = {}; // clear the form so our user is ready to enter another

                       if(data.status === 200)
                       {
                         $location.path("/hospital/doctor/detail");
                         $window.alert(data.error);
                       }

                   })
              .error(function(data) {

              });
            }
           };

           $scope.reload = function() {
             SharedScope.sharingData(SharedScope.Data);
           }


      });

      HospitalData.controller('HospitalStaffDetailController' , function($scope, $http,$location,$window,SharedScope){


          $http.get('/hospital/staff/data')
             .success(function(data) {
               if(data.status === 200)
               {
                data = data.data;
                 $scope.hstfdetails = data;


                 var sid = new Array();
                 data.forEach(function(datas) {

                  dlength = sid.length;
                   for(var i=0;i<dlength;i++)
                   {

                     if(sid[i] === datas.staff._id)
                     {
                       break;
                     }
                   }
                   if(i>=dlength)
                   {
                     sid.push(datas.staff._id);
                   }


                 });


                 $http.post('/staff/hospital/data',{sid : sid})
                 .success(function(data) {
                   if(data.status === 200)
                   {
                      data = data.data;
                     $scope.shospitaldetails = data;
                     for(var j in $scope.hstfdetails)
                     {

                       for(var i in data)
                       {

                         if($scope.hstfdetails[j].staff._id === data[i]._id)
                         {
                           $scope.hstfdetails[j].staff.stf = data[i];

                         }

                       }
                       /*if($scope.hdrdetails[j].doctor.is_present==true)
                       {
                         $scope.hdrdetails[j].doctor.is_present="Yes";
                       }
                       else {
                         $scope.hdrdetails[j].doctor.is_present="No"
                       }*/
                       var today = new Date();
                       var nowyear = today.getFullYear();
                       var nowmonth = today.getMonth();
                       var nowday = today.getDate();

                         doj = new Date($scope.hstfdetails[j].staff.doj);
                         var dojyear = doj.getFullYear();
                         var dojmonth = doj.getMonth();
                         $scope.hstfdetails[j].staff.expYear = nowyear - dojyear;
                         $scope.hstfdetails[j].staff.expMonth = nowmonth - dojmonth;
                     }



                   }
                 })
                 .error(function(data) {

                 });



               }
             })
             .error(function(data) {

             });

             $scope.View_Data = function(data) {
               SharedScope.sharingData(data);
               $location.path("/hospital/staff/data/view");
            };
        });

  HospitalData.controller('HStaffViewcontroller' , function($scope, $http,SharedScope,$location){

          $scope.stfdata  = SharedScope.Data;

                  $http.get('/hospital/s/staff/data/' + $scope.stfdata._id)
                   .success(function(data) {
                      if(data.status === 200)
                      {
                       $scope.STF= data.data[0];
                       $scope.STF.salary = $scope.stfdata.salary;
                       $scope.STF.designation = $scope.stfdata.designation;
                       $scope.STF.doj = $scope.stfdata.doj;
                       data.data[0].salary = $scope.stfdata.salary;
                       data.data[0].designation = $scope.stfdata.designation;
                       SharedScope.sharingData(data.data[0]);
                     }
                     else {
                       $location.path("/hospital/staff/detail");
                     }

                   })
                   .error(function(data) {

                   });


  });
  HospitalData.controller('HospitalStaffUpdateController' , function($scope, $http,$location,SharedScope,$window){


  $scope.STF = SharedScope.Data;
  $scope.STF.fname  = $scope.STF.name.fname;
  $scope.STF.mname  = $scope.STF.name.mname;
  $scope.STF.lname  = $scope.STF.name.lname;
  $scope.STF.street  = $scope.STF.add.street;
  $scope.STF.l_mark  = $scope.STF.add.l_mark;
  $scope.STF.city  = $scope.STF.add.city;
  $scope.STF.pincode  = $scope.STF.add.pincode;
  $scope.STF.state  = $scope.STF.add.state;
  $scope.STF.country  = $scope.STF.add.country;
  $scope.STF.dist  = $scope.STF.add.dist;
  $scope.STF.rname  = $scope.STF.reference.name;
  $scope.STF.rcontact  = $scope.STF.reference.contact;
  $scope.STF.rrelation  = $scope.STF.reference.relation;

       $scope.staffUpdate = function() {
         if (confirm('Do you want to Update Staff Profile?')) {

         var fd = new FormData();
         for(var key in $scope.STF){

           fd.append(key, $scope.STF[key]);
         }
           $http.post('/staff/update', fd,
           {
               transformRequest: angular.identity,
               headers: {'Content-Type': undefined}
           })
            .success(function(data) {
                $scope.staff = [];

                     if(data.status === 200)
                     {
                       $location.path("/hospital/staff/detail");
                       $window.alert(data.error);
                     }

                 })
            .error(function(data) {

            });
          }
         };
  });


  HospitalData.factory('SharedScope', function() {
            var sharedData = {};

            sharedData.Data = '';

            sharedData.sharingData = function(data) {

                this.Data = data;
            };

            return sharedData;
  });
