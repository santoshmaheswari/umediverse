var Laboratorydata = angular.module('Laboratorydata', []);

Laboratorydata.controller('Labcontroller' , function($scope, $http,$location,$window){

  //hospital registration controller
      $scope.LB = {};
  $scope.contacts = [];
          $scope.verify_lid = function() {
            if($scope.LB["LLic"])
            {
              var fd = new FormData();
              fd.append("LLic", $scope.LB["LLic"]);
              $http.post('/laboratory/id/verify',fd,
              {
                  transforLBequest: angular.identity,
                  headers: {'Content-Type': undefined}
              })
              .success(function(data) {
                if(data.status === 200)
                {
                  $scope.id_status = "";
                }
                else {
                  $scope.id_status = "Already Registered";
                }
              }).error(function(data) {

              });
            }
          }
         // when landing on the page, get all todos and show them
         $scope.verify = function() {
           if( $scope.LB["LUName"])
           {
            var fd = new FormData();
            fd.append("LUName", $scope.LB["LUName"]);
             $http.post('/laboratory/username/verify',fd,
             {
                 transforLBequest: angular.identity,
                 headers: {'Content-Type': undefined}
             })
             .success(function(data) {
               if(data.status === 200)
               $scope.user_status = data.error;
             }).error(function(data) {

             });
           }
         }

         $scope.Reset = function() {
           $scope.user_status = "";
           $scope.id_status = "";
         }
         // when submitting the add form, send the text to the node API
         $scope.LBsubmit = function() {
           if($scope.user_status === "Available")
            {
           if (confirm('Do you want to complete registration?')) {

           var fd = new FormData();
         for(var key in $scope.LB){

             fd.append(key, $scope.LB[key]);

         }

         $http.post('/laboratory/registration', fd,
         {
             transforLBequest: angular.identity,
             headers: {'Content-Type': undefined}
         })

            .success(function(data) {
                     $scope.LB = {}; // clear the form so our user is ready to enter another

                     if(data.status === 200)
                     {
                       $location.path("/hospital");
                       $window.alert(data.error);
                     }

                 })
            .error(function(data) {

            });
          }
        }
        else {
          $window.alert("Username Already Registered");
        }
         };

});

Laboratorydata.controller('LabPwdChngcontroller' , function($scope, $http,$location,$window){

      $scope.change = function() {
        if (confirm('Do you want to Change Password?')) {

      $http.post('/laboratory/change_password', $scope.Pwd)
                 .success(function(data) {
                $scope.Pwd = {}; // clear the form so our user is ready to enter another
                if(data.status === 200)
                {
                  $location.path("/laboratory");
                  $window.alert(data.error);
                }
                else {
                  $window.alert(data.error);
                }

            })
       .error(function(data) {

       });
     }
     }


});


Laboratorydata.controller('Labviewcontroller' , function($scope, $http,$location,$window){

  $scope.details=[];
  $http.get('/laboratory/data/')
     .success(function(data) {
       if(data.status === 200)
       {
       $scope.lb = data.data[0];
       $scope.lb.est_date = new Date($scope.lb.est_date);

       $scope.lb.street  = $scope.lb.add.street;
       $scope.lb.l_mark  = $scope.lb.add.l_mark;
       $scope.lb.city  = $scope.lb.add.city;
       $scope.lb.pincode  = $scope.lb.add.pincode;
       $scope.lb.state  = $scope.lb.add.state;
       $scope.lb.country  = $scope.lb.add.country;
       $scope.lb.dist  = $scope.lb.add.dist;
       $scope.lb.x  = $scope.lb.location.x;
       $scope.lb.y  = $scope.lb.location.y;
       $scope.lb.oldpincode  = $scope.lb.add.pincode;

    }
      else {
         $location.path("/laboratory");
       }

     })
     .error(function(data) {

     });

     $scope.update = function() {
       if (confirm('Do you want to Update Profile?')) {
             var fd = new FormData();
             for(var key in $scope.lb){
               fd.append(key, $scope.lb[key]);
             }
               $http.post('/laboratory/update', fd,
               {
                   transforLBequest: angular.identity,
                   headers: {'Content-Type': undefined}
               })
              .success(function(data) {
               $scope.lb = {}; // clear the form so our user is ready to enter another

               if(data.status === 200)
               {
                 $location.path("/laboratory/profile");
                 $window.alert(data.error);
               }

           })
      .error(function(data) {

      });
    }
}

});

Laboratorydata.controller('Labpatientcontroller' , function($scope, $http,$location,$window){
    $http.get('/laboratory/patient/data/')
       .success(function(data) {
         if(data.status === 200)
         {
        $scope.lpdata = data.data;
        var did = new Array();
        data.data.forEach(function(datas) {
          dlength = did.length;
          for(var i=0;i<dlength;i++)
          {
            if(did[i] === datas.case_detail.doctor_id)
            {
              break;
            }
          }
          if(i>=dlength)
          {
            did.push(datas.case_detail.doctor_id);
          }
        });
        $http.post('/doctor/case_history/data',{did : did})
        .success(function(data) {
          if(data.status === 200)
          {
            data = data.data;
            $scope.dcasedetails = data;
            for(var j in $scope.lpdata)
            {

              for(var i in data)
              {
                if($scope.lpdata[j].case_detail.doctor_id === data[i].did)
                {
                  $scope.lpdata[j].doctor = data[i];

                }
              }
            }
          }
            else {
               $location.path("/laboratory");
             }

        })
        .error(function(data) {

        });

      }
    }).error(function(data) {

    });
    $scope.Search = function(id) {
      if(id !=null)
      {
        $location.path("/laboratory/patient/data/" + id);
      }
    }

});

Laboratorydata.controller('LbPTCaseViewcontroller' , function($scope, $http,$routeParams, $window,  $location){

    $http.get('/laboratory/patient/data/s/' + $routeParams.appid)
           .success(function(data) {

             if(data.status === 200)
             {
               $scope.lcaseviewdetails = data.data[0];
               var today = new Date();
               var nowyear = today.getFullYear();
               birth = new Date($scope.lcaseviewdetails.bod);
               var birthyear = birth.getFullYear();
               $scope.age = nowyear - birthyear;
               $http.post('/doctor/case_history/data',{did : $scope.lcaseviewdetails.case_detail.doctor_id})
               .success(function(data) {
                 if(data.status === 200)
                 {
                         $scope.lcaseviewdetails.doctor = data.data[0];
                  }       else {
                            $location.path("/laboratory");
                          }


               })
               .error(function(data) {

               });
               $http.post('/hospital/case_history/data',{hid:$scope.lcaseviewdetails.case_detail.hospital_id})
               .success(function(data) {
                       if(data.status === 200)
                       {
                         $scope.lcaseviewdetails.hospital = data.data[0];
                       }
                        else {
                           $location.path("/laboratory");
                         }

               })
               .error(function(data) {

               });

             }
           })
           .error(function(data) {
             $location.path("/laboratory");


           });
           $scope.LPT = [];
           $scope.uploadLInv = function(id,name) {
             if (confirm('Do you want to upload investigation?')) {

             var fd = new FormData();

            for(var key in $scope.LPT){
               fd.append(key, $scope.LPT[key]);
           }

           fd.append('case',$scope.lcaseviewdetails.case_detail._id);
           fd.append('visit',$scope.lcaseviewdetails.case_detail.visit_detail._id);
           fd.append('PInv',id);
           fd.append('name',name);
           fd.append('id',$scope.lcaseviewdetails._id);
           fd.append('dir_name',$scope.lcaseviewdetails.dir_name);
           $http.post('/laboratory/patient/investigation/upload', fd,
           {
               transformRequest: angular.identity,
               headers: {'Content-Type': undefined}
           })
            .success(function(data) {
                       $scope.LPT = {}; // clear the form so our user is ready to enter another
                       if(data.status === 200)
                       {

                         $window.alert(data.error);
                         $window.reload();
                       }

                   })
              .error(function(data) {

              });
           }
         };

});

Laboratorydata.controller('Labfeescontroller' , function($scope, $http,$location,$window){
$scope.LAB = {};
$scope.LAB.investigation = [];
$scope.LAB.emergency = [];

    $http.get('/laboratory/s/fees/')
       .success(function(data) {
         if(data.status === 200)
         {
           $scope.LAB.investigation = data.data[0].investigation_list;
           $scope.LAB.emergency = data.data[0].emergency_fees;
         }
           else {
             $window.alert(data.error);

            }


       })
       .error(function(data) {

       });

      $scope.Feesvalue = function() {

        if (confirm('Do you want to update fees?')) {

            $http.post('/laboratory/fees/',$scope.LAB)
            .success(function(data) {


                     if(data.status === 200)
                     {
                       $location.path("/laboratory");
                       $window.alert(data.error);
                     }

                 })
            .error(function(data) {

            });
          }
         };

         $scope.add_inv = function() {
           if($scope.LB.new)
           {
               $scope.LAB.investigation.push({'name' :$scope.LB.new,'fees':0});
               $scope.LB.new = [];
             }
         }

         $scope.update_fee = function(i,fee) {
            $scope.LAB.investigation[i].fees=fee;
          }

          $scope.removeInv = function(i) {
            $scope.LAB.investigation.splice(i, 1);
           }

  });
