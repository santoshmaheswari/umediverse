var MedicineDrData = angular.module('MedicineDrData', []);

MedicineDrData.controller('medicineDrController' , function($scope, $http,$location,$window){

      $http.get('/doctor/treatment/medicine/data')
      .success(function(data) {
        if(data.status === 200)
          $scope.d_details = data.data;

      })
      .error(function(data) {
        
      });

});
