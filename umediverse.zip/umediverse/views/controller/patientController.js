var PatientData = angular.module('PatientData', ['ngRoute','ngFileUpload','ui.bootstrap','ngSanitize']);

PatientData.controller('PTviewcontroller' , function($filter,$scope, $http,$location,$window){


      $http.get('/patient/data')
      .success(function(data) {

        if(data.status === 200)
        {

        data.data[0].bod = new Date(data.data[0].bod)//$filter('date')(data[0].bod, 'dd-mm-yyyy');
          $scope.pt = data.data[0];
          $scope.pt.bod = new Date($scope.pt.bod);

          $scope.pt.fname  = $scope.pt.name.fname;
          $scope.pt.mname  = $scope.pt.name.mname;
          $scope.pt.lname  = $scope.pt.name.lname;
          $scope.pt.street  = $scope.pt.add.street;
          $scope.pt.l_mark  = $scope.pt.add.l_mark;
          $scope.pt.city  = $scope.pt.add.city;
          $scope.pt.pincode  = $scope.pt.add.pincode;
          $scope.pt.state  = $scope.pt.add.state;
          $scope.pt.country  = $scope.pt.add.country;
          $scope.pt.dist  = $scope.pt.add.dist;
          $scope.pt.ename  = $scope.pt.emergency.ename;
          $scope.pt.econtact  = $scope.pt.emergency.contact;
          $scope.pt.erelation  = $scope.pt.emergency.relation;
          $scope.pt.oldpincode  = $scope.pt.add.pincode;
        }

        else {
          $location.path("/patient");


         }


      })
      .error(function(data) {

      });

      $scope.update = function() {
        if (confirm('Do you want to Update Profile?')) {


              var fd = new FormData();
              for(var key in $scope.pt){
                fd.append(key, $scope.pt[key]);
              }
                $http.post('/patient/update', fd,
                {
                    transformRequest: angular.identity,
                    headers: {'Content-Type': undefined}
                })
                 .success(function(data) {
                $scope.pt = {}; // clear the form so our user is ready to enter another

                if(data.status === 200)
                {
                  $location.path("/patient/profile");
                  $window.alert(data.error);
                }

            })
       .error(function(data) {

       });
     }
 }
 //$scope.$watch('pt.bod', function (newValue) {
  //  $scope.pt.bod = $filter('date')(newValue, 'dd/MM/yyyy');
//});

});

PatientData.controller('PTPwdChngcontroller' , function($scope, $http,$location,$window){

      $scope.change = function() {
        if (confirm('Do you want to Change Password?')) {

      $http.post('/patient/change_password', $scope.Pwd)
                 .success(function(data) {
                $scope.Pwd = {}; // clear the form so our user is ready to enter another
                if(data.status === 200)
                {
                  $location.path("/patient");
                  $window.alert(data.error);
                }
                else {
                  $window.alert(data.error);
                }

            })
       .error(function(data) {

       });
     }
     }


});


PatientData.controller('PTcontroller' , function($scope, $http,$location, $route,$uibModal,$window){

    $scope.PT = {};

     $scope.verify = function() {
       if($scope.PT["PUName"])
       {
       var fd = new FormData();

        fd.append("PUName", $scope.PT["PUName"]);
       $http.post('/patient/username/verify',fd,
       {
           transformRequest: angular.identity,
           headers: {'Content-Type': undefined}
       })
       .success(function(data) {
         if(data.status === 200)
         $scope.user_status = data.error;
       }).error(function(data) {

       });
     }
     }

     $scope.con_verify = function() {
       if($scope.PT["PMob"])
       {
           var fd = new FormData();
            fd.append("PMob", $scope.PT["PMob"]);

           $http.post('/patient/contact/verify',fd,
           {
               transformRequest: angular.identity,
               headers: {'Content-Type': undefined}
           })
           .success(function(data) {
             if(data.status === 200)
             $scope.contact_status = data.error;
           }).error(function(data) {

           });
        }
     }
     $scope.Reset = function() {
       $scope.contact_status = "";
       $scope.user_status = "";
     }
       // when submitting the add form, send the text to the node API
              $scope.PTsubmit = function() {

              if($scope.user_status === "Available" && $scope.contact_status=== "Available")
                {
                if (confirm('Do you want to complete registration?')) {

              var fd = new FormData();
              for(var key in $scope.PT){

                  fd.append(key, $scope.PT[key]);

              }

              $http.post('/patient/registration', fd,
            	{
            			transformRequest: angular.identity,
            			headers: {'Content-Type': undefined}
            	})
              .success(function(data) {
                        // clear the form so our user is ready to enter another
                       if(data.status === 200)
                       {
                         var ptdata = new Array();
                         ptdata.id = data.id;
                         ptdata.name = $scope.PT.PFName + " " + $scope.PT.PMName + " " + $scope.PT.PLName;
                         ptdata.bod =  $scope.PT.PDob;
                         ptdata.gender = $scope.PT.PGen;
                         ptdata.bloodgroup = $scope.PT.PBG;
                         var URL = window.URL || window.webkitURL;
                         if($scope.PT.file)
                         {
                         ptdata.img = URL.createObjectURL($scope.PT.file);
                       }
                         ptdata.mob = $scope.PT.PMob;

                         $scope.PT = {};
                         var modalInstance = $uibModal.open({
                          templateUrl: 'Patient_Reg_Complete.html',
                          controller: 'PtRegOkcontroller',
                          resolve: {
                            patient: function () {
                              return ptdata;
                            }
                          }
                         });
                         $route.reload();

                       }

                })
                .error(function(data) {

              });
            }
          }
          else if($scope.user_status === "Already Registered" || $scope.contact_status=== "Already Registered") {
            $window.alert("Username/Mobile Already Registered");
          }
          else {
            $window.alert("Fill data propely...");
          }
           };



});

PatientData.controller('PtRegOkcontroller' , function($scope, $http,$uibModalInstance, patient){
  $scope.data = patient;

  $scope.qrcode = '<img src="https://chart.googleapis.com/chart?cht=qr&chs=300x300&chl='+ //for qr image fetch directivity
        $scope.data.id+
        '">';  //for address

   $scope.ok = function () {
     $uibModalInstance.dismiss('cancel');
   };
   $scope.print = function () {
     var printContents = document.getElementById("printData").innerHTML;
     var popupWin = window.open('', '', '');
     popupWin.document.open();
     popupWin.document.write('<html><head></head><body onload="window.print()">' + printContents + '</body></html>');
     popupWin.document.close();
   }
});


PatientData.controller('PTCasecontroller' , function($scope, $http,$location){
          $http.get('/patient/case_history/data')
           .success(function(data) {
             if(data.status === 200)
             {
               data = data.data;
               $scope.casedetails = data;
               var hid = new Array();
               var did = new Array();
               data.forEach(function(datas) {
                 hlength = hid.length;
                 dlength = did.length;

                 for(var i=0;i<hlength;i++)
                 {
                   if(hid[i] === datas.case_detail.hospital_id)
                   {
                     break;
                   }
                 }
                 if(i>=hlength)
                 {
                   hid.push(datas.case_detail.hospital_id);
                 }
                 for(var i=0;i<dlength;i++)
                 {
                   if(did[i] === datas.case_detail.doctor_id)
                   {
                     break;
                   }
                 }
                 if(i>=dlength)
                 {
                   did.push(datas.case_detail.doctor_id);
                 }

               });

               $http.post('/doctor/case_history/data',{did : did})
               .success(function(data) {

                 if(data.status === 200)
                 {
                   data = data.data;
                   $scope.dcasedetails = data;
                   for(var j in $scope.casedetails)
                   {

                     for(var i in data)
                     {
                       if($scope.casedetails[j].case_detail.doctor_id === data[i].did)
                       {
                         $scope.casedetails[j].doctor = data[i];

                       }
                     }
                   }
                 }
                   else {
                      $location.path("/patient");
                    }


               })
               .error(function(data) {

               });

               $http.post('/hospital/case_history/data',{hid:hid})
               .success(function(data) {

                 if(data.status === 200)
                 {
                   data = data.data;
                   $scope.hcasedetails = data;
                   for(var j in $scope.casedetails)
                   {

                     for(var i in data)
                     {
                       if($scope.casedetails[j].case_detail.hospital_id === data[i].hid)
                       {
                         $scope.casedetails[j].hospital = data[i];

                       }
                     }
                   }
                }
                else {
                  $location.path("/patient");
                }

               })
               .error(function(data) {

               });
             }

           })
           .error(function(data) {

           });
});
PatientData.controller('PTCaseViewcontroller' , function($scope, $http,$routeParams){

  $scope.visiting_index = 0;

   $scope.next = function () {
       if ($scope.visiting_index >= $scope.caseviewdetails.case_detail.visit_detail.length - 1) {
           //$scope.visiting_index = 0;
       } else {
           $scope.visiting_index++;
       }
     }

     $scope.previous = function () {
         if ($scope.visiting_index < 1) {
             //$scope.visiting_index = 0;
         } else {
             $scope.visiting_index--;
         }
       }

          $http.get('/patient/case_history/' + $routeParams.appid)
           .success(function(data) {
             if(data.status === 200)
             {
               $scope.caseviewdetails = data.data[0];
               $http.post('/doctor/case_history/data',{did : $scope.caseviewdetails.case_detail.doctor_id})
               .success(function(data) {
                 if(data.status === 200)
                 {
                         $scope.caseviewdetails.doctor = data.data[0];

                }
                  else {
                     $location.path("/patient");
                   }

               })
               .error(function(data) {

               });
               $http.post('/hospital/case_history/data',{hid:$scope.caseviewdetails.case_detail.hospital_id})
               .success(function(data) {
                 if(data.status === 200)
                 {
                         $scope.caseviewdetails.hospital = data.data[0];
                       }
                         else {
                            $location.path("/patient");
                          }

               })
               .error(function(data) {

               });

             }
           })
           .error(function(data) {

           });
});
