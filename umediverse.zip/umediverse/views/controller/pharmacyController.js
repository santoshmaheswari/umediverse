var PharmacyData = angular.module('PharmacyData', []);

PharmacyData.controller('PHcontroller' , function($scope, $http,$location,$window){

  //hospital registration controller
      $scope.PR = {};
  $scope.contacts = [];
          $scope.verify_pid = function() {
            if($scope.PR["PLic"])
            {
              var fd = new FormData();
              fd.append("PLic", $scope.PR["PLic"]);
              $http.post('/pharmacy/id/verify',fd,
              {
                  transformRequest: angular.identity,
                  headers: {'Content-Type': undefined}
              })
              .success(function(data) {
                if(data.status === 200)
                {
                  $scope.id_status = "Available";
                }
                else {
                  $scope.id_status = "Already Registered";
                }
              }).error(function(data) {

              });
            }
          }
         // when landing on the page, get all todos and show them
         $scope.verify = function() {
           if( $scope.PR["PUName"])
           {
            var fd = new FormData();
            fd.append("PUName", $scope.PR["PUName"]);
             $http.post('/pharmacy/username/verify',fd,
             {
                 transformRequest: angular.identity,
                 headers: {'Content-Type': undefined}
             })
             .success(function(data) {
               if(data.status === 200)
               $scope.user_status = data.error;
             }).error(function(data) {

             });
           }
         }

         $scope.Reset = function() {
           $scope.user_status = "";
           $scope.id_status = "";
         }
         // when submitting the add form, send the text to the node API
         $scope.PRsubmit = function() {
           if($scope.user_status === "Available")
            {
           if (confirm('Do you want to complete registration?')) {

           var fd = new FormData();
         for(var key in $scope.PR){

             fd.append(key, $scope.PR[key]);

         }

         $http.post('/pharmacy/registration', fd,
         {
             transformRequest: angular.identity,
             headers: {'Content-Type': undefined}
         })

            .success(function(data) {
                     $scope.PR = {}; // clear the form so our user is ready to enter another

                     if(data.status === 200 && data.data === 'hospital')
                     {
                       $location.path("/hospital");
                       $window.alert(data.error);
                     }
                     else if(data.status === 200)
                     {
                       $location.path("/admin");
                       $window.alert(data.error);
                     }

                 })
            .error(function(data) {

            });
          }
        }
        else {
          $window.alert("Username Already Registered");
        }
         };

});

PharmacyData.controller('PHPwdChngcontroller' , function($scope, $http,$location,$window){

      $scope.change = function() {
        if (confirm('Do you want to Change Password?')) {

      $http.post('/pharmacy/change_password', $scope.Pwd)
                 .success(function(data) {
                $scope.Pwd = {}; // clear the form so our user is ready to enter another
                if(data.status === 200)
                {
                  $location.path("/pharmacy");
                  $window.alert(data.error);
                }
                else {
                  $window.alert(data.error);
                }

            })
       .error(function(data) {

       });
     }
     }


});


PharmacyData.controller('PHviewcontroller' , function($scope, $http,$location,$window){

  $http.get('/pharmacy/data/')
     .success(function(data) {
       if(data.status === 200)
       {
       $scope.ph = data.data[0];
       $scope.ph.est_date = new Date($scope.ph.est_date);

       $scope.ph.street  = $scope.ph.add.street;
       $scope.ph.l_mark  = $scope.ph.add.l_mark;
       $scope.ph.city  = $scope.ph.add.city;
       $scope.ph.pincode  = $scope.ph.add.pincode;
       $scope.ph.state  = $scope.ph.add.state;
       $scope.ph.country  = $scope.ph.add.country;
       $scope.ph.dist  = $scope.ph.add.dist;
       $scope.ph.x  = $scope.ph.location.x;
       $scope.ph.y  = $scope.ph.location.y;
       $scope.ph.oldpincode  = $scope.ph.add.pincode;

    }

    else {
      $location.path("/pharmacy");


     }

     })
     .error(function(data) {

     });

     $scope.update = function() {
       if (confirm('Do you want to Update Profile?')) {
             var fd = new FormData();
             for(var key in $scope.ph){
               fd.append(key, $scope.ph[key]);
             }
               $http.post('/pharmacy/update', fd,
               {
                   transformRequest: angular.identity,
                   headers: {'Content-Type': undefined}
               })
              .success(function(data) {
               $scope.ph = {}; // clear the form so our user is ready to enter another

               if(data.status === 200)
               {
                 $location.path("/pharmacy/profile");
                 $window.alert(data.error);
               }

           })
      .error(function(data) {

      });
    }
}

});

PharmacyData.controller('PHpatientcontroller' , function($scope, $http,$location,$window){
    $http.get('/pharmacy/patient/data/')
       .success(function(data) {
         if(data.status === 200)
         {
           data = data.data;
        $scope.mpdata = data;
        var did = new Array();
        data.forEach(function(datas) {
          dlength = did.length;
          for(var i=0;i<dlength;i++)
          {
            if(did[i] === datas.case_detail.doctor_id)
            {
              break;
            }
          }
          if(i>=dlength)
          {
            did.push(datas.case_detail.doctor_id);
          }
        });
        $http.post('/doctor/case_history/data',{did : did})
        .success(function(data) {
          if(data.status === 200)
          {
            data = data.data;
            $scope.dcasedetails = data;
            for(var j in $scope.mpdata)
            {

              for(var i in data)
              {
                if($scope.mpdata[j].case_detail.doctor_id === data[i].did)
                {
                  $scope.mpdata[j].doctor = data[i];

                }
              }
            }
          }
            else {
               $location.path("/pharmacy");
             }

        })
        .error(function(data) {

        });
      }
    }).error(function(data) {

    });
    $scope.Search = function(id) {

      if(id)
      {
        $location.path("/pharmacy/patient/data/" + id);
      }
    }

});

PharmacyData.controller('PHPTCaseViewcontroller' , function($scope, $http,$routeParams){

    $http.get('/pharmacy/patient/data/s/' + $routeParams.appid)
           .success(function(data) {
             if(data.status === 200)
             {
               $scope.caseviewdetails = data.data[0];
               var today = new Date();
               var nowyear = today.getFullYear();
               birth = new Date($scope.caseviewdetails.bod);
               var birthyear = birth.getFullYear();
               $scope.age = nowyear - birthyear;
               $http.post('/doctor/case_history/data',{did : $scope.caseviewdetails.case_detail.doctor_id})
               .success(function(data) {
                 if(data.status === 200)
                 {
                         $scope.caseviewdetails.doctor = data.data[0];
                       }
                         else {
                            $location.path("/pharmacy");
                          }

               })
               .error(function(data) {

               });
               $http.post('/hospital/case_history/data',{hid:$scope.caseviewdetails.case_detail.hospital_id})
               .success(function(data) {
                 if(data.status === 200)
                 {
                         $scope.caseviewdetails.hospital = data.data[0];
                  }
                  else {
                    $location.path("/pharmacy");
                  }


               })
               .error(function(data) {

               });

             }
           })
           .error(function(data) {

           });



});
