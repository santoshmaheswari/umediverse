var ResetData = angular.module('ResetData', []);

ResetData.controller('ADResetController' , function($routeParams,$window,$http,$location,Shared){
  $http.get('/reset/s/admin/'+ $routeParams.token)
     .success(function(data) {
       if(data.status === 200)
       {
         Shared.sharingData('admin',data.id);
         $location.path("/reset/password");
       }
       else {
         $window.alert(data.error);
         $location.path("/");
       }


     })
     .error(function(data) {

     });
});


ResetData.controller('ForgotController' , function($scope,$window,$http,$location){

  $scope.sendMail = function(s) {
    $http.post(s,$scope.user)
       .success(function(data) {
         if(data.status === 200)
         {
           $window.alert(data.error);
          $location.path("/");
         }
         else {
           $window.alert(data.error);
           $location.path("/");
         }


       })
       .error(function(data) {

       });
  }
});

ResetData.controller('PTResetController' , function($routeParams,$window,$http,$location,Shared){
  $http.get('/reset/s/patient/'+ $routeParams.token)
     .success(function(data) {
       if(data.status === 200)
       {
         Shared.sharingData('patient',data.id);
         $location.path("/reset/password");
       }
       else {
         $window.alert(data.error);
         $location.path("/");
       }


     })
     .error(function(data) {

     });
});

ResetData.controller('LabResetController' , function($routeParams,$window,$http,$location,Shared){
  $http.get('/reset/s/laboratory/'+ $routeParams.token)
     .success(function(data) {
       if(data.status === 200)
       {
         Shared.sharingData('laboratory',data.id);
         $location.path("/reset/password");
       }
       else {
         $window.alert(data.error);
         $location.path("/");
       }


     })
     .error(function(data) {

     });
});
ResetData.controller('DRResetController' , function($routeParams,$window,$http,$location,Shared){
  $http.get('/reset/s/doctor/'+ $routeParams.token)
     .success(function(data) {
       if(data.status === 200)
       {
         Shared.sharingData('doctor',data.id);
         $location.path("/reset/password");
       }
       else {
         $window.alert(data.error);
         $location.path("/");
       }


     })
     .error(function(data) {

     });
});
ResetData.controller('HPResetController' , function($routeParams,$window,$http,$location,Shared){
  $http.get('/reset/s/hospital/'+ $routeParams.token)
     .success(function(data) {
       if(data.status === 200)
       {
         Shared.sharingData('hospital',data.id);
         $location.path("/reset/password");
       }
       else {
         $window.alert(data.error);
         $location.path("/");
       }


     })
     .error(function(data) {

     });
});
ResetData.controller('MedResetController' , function($routeParams,$window,$http,$location,Shared){
  $http.get('/reset/s/medical/'+ $routeParams.token)
     .success(function(data) {
       if(data.status === 200)
       {
         Shared.sharingData('medical',data.id);
         $location.path("/reset/password");
       }
       else {
         $window.alert(data.error);
         $location.path("/");
       }


     })
     .error(function(data) {

     });
});

ResetData.controller('ResetPasswordController' , function($window,$scope,$http,$location,Shared){
  $scope.user = {};

$scope.reset = function() {
$scope.user.id = Shared.id;
$scope.user.type = Shared.data;

  $http.post('/reset/s/password/',$scope.user)
     .success(function(data) {
       if(data.status === 200)
       {
         $window.alert(data.error);
        $location.path("/");
       }
       else {
         $window.alert(data.error);
         $location.path("/");
       }


     })
     .error(function(data) {
      
     });
   }
});

ResetData.factory('Shared', function() {
          var sharedData = {};

          sharedData.Data = '';
          sharedData.id = '';

          sharedData.sharingData = function(data,id) {
              this.Data = data;
              this.id = id;
          };

          return sharedData;
});
