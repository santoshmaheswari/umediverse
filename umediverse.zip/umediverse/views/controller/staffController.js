var StaffData = angular.module('StaffData', []);

StaffData.controller('staffController' , function($scope, $http,$location,$window){

//hospital registration controller
    $scope.STF = {};

       $scope.STFsubmit = function() {
         if (confirm('Do you want to complete registration?')) {

         var fd = new FormData();
       for(var key in $scope.STF){

           fd.append(key, $scope.STF[key]);

       }

       $http.post('/staff/registration', fd,
       {
           transformRequest: angular.identity,
           headers: {'Content-Type': undefined}
       })

          .success(function(data) {
                   $scope.STF = {}; // clear the form so our user is ready to enter another

                   if(data.status === 200)
                   {
                     $location.path("/hospital");
                     $window.alert(data.error);
                   }

               })
          .error(function(data) {

          });
        }
       };

});



StaffData.controller('staffApproveController' , function($scope, $http,$location,$window){


    $http.get('/staff/data')
    .success(function(data) {
      if(data.status === 200)
      {
        $scope.details = data.data;
      }

    })
    .error(function(data) {

    });

     $scope.staffsubmit = function() {
       if (confirm('Do you want to Approve Staff?')) {

          $http.post('/hospital/staff/approve', $scope.STF)
          .success(function(data) {
                   if(data.status === 200)
                   {
                     $location.path("/hospital");
                     $window.alert(data.error);
                   }
                   else {
                     $window.alert(data.error);
                   }

               })
          .error(function(data) {

          });
       };
     }
});

StaffData.controller('STFPwdChngcontroller' , function($scope, $http,$location,$window){

      $scope.change = function() {
        if (confirm('Do you want to Change Password?')) {

      $http.post('/staff/change_password', $scope.Pwd)
                 .success(function(data) {
                $scope.Pwd = {}; // clear the form so our user is ready to enter another
                if(data.status === 200)
                {
                  $location.path("/staff");
                  $window.alert(data.error);
                }
                else {
                  $window.alert(data.error);
                }

            })
       .error(function(data) {

       });
     }
   }


});


StaffData.controller('staffRelieveController' , function($scope, $http,$location,$window){

        $http.get('/hospital/staff/data')
        .success(function(data) {
          if(data.status === 200)
          {
            $scope.sdetails = data.data;
          }

        })
        .error(function(data) {

        });

        $scope.staff = function(i) {
          $scope.details = $scope.sdetails[i];

        }

       $scope.staffRelieve = function() {

         if (confirm('Do you want to Relive Staff?')) {

            $http.post('/hospital/staff/relieve', $scope.STFR)
            .success(function(data) {


                     if(data.status === 200)
                     {
                       $location.path("/hospital");
                       $window.alert(data.error);
                     }
                     else {
                        $window.alert(data.error);
                     }

                 })
            .error(function(data) {

            });
          }
         };

});

StaffData.controller('staffCAccountController' , function($scope, $http,$location,$window){

        $http.get('/hospital/staff/data')
        .success(function(data) {
          if(data.status === 200)
          {
            $scope.sadetails = data.data;
          }

        })
        .error(function(data) {

        });

       $scope.staffAccount = function() {
         if (confirm('Do you want to create Staff Account?')) {

            $http.post('/hospital/staff/account', $scope.STFA)
            .success(function(data) {


                     if(data.status === 200)
                     {
                       $location.path("/hospital/staff/account");
                       $window.alert(data.error);
                     }
                     else {
                        $window.alert(data.error);
                     }

                 })
            .error(function(data) {

            });
          }
         };

});

StaffData.controller('staffAccountController' , function($scope, $http,$location,$location,$window,SharedScope){

        $http.get('/hospital/staff/account/all')
        .success(function(data) {
          if(data.status === 200)
          {
            $scope.salldetails = data.data;
          }

        })
        .error(function(data) {

        });

        $scope.deletedata = function(id) {
          if (confirm('Do you want to Delete Staff Account?')) {

            $http.get('/hospital/staff/account/delete/' + id)
            .success(function(data) {


                     if(data.status === 200)
                     {
                       $location.path("/hospital");
                       $window.alert(data.error);
                     }

                 })
            .error(function(data) {

            });
          }
         };

         $scope.getdata = function(data) {
           SharedScope.sharingData(data);
           $location.path("/hospital/staff/account/update");
        };
});

StaffData.controller('staffUAccountController' , function($scope, $http,$location,$window,SharedScope){

  $scope.STFU  = SharedScope.Data;
         $http.get('/hospital/staff/data')
         .success(function(data) {
           if(data.status === 200)
           {
             $scope.sadetails = data.data;
           }

         })
         .error(function(data) {

         });

         $scope.AccUpdate = function() {
           if (confirm('Do you want to Update Staff Account?')) {

              $http.post('/hospital/staff/account/update', $scope.STFU)
              .success(function(data) {


                       if(data.status === 200)
                       {
                         $location.path("/hospital/staff/account");
                         $window.alert(data.error);
                       }
                       else {
                          $window.alert(data.error);
                       }

                   })
              .error(function(data) {

              });
            }
           };

});

StaffData.controller('StaffAppReportController' , function($scope, $http,$location,$window){
        $http.get('/hospital/doctor/stdata')
        .success(function(data) {
          if(data.status === 200)
          {
            $scope.drdetails = data.data;
          }


        })
        .error(function(data) {

        });

 $scope.getData = function() {

        $http.post('/patient/staff/appointment/list',$scope.DR)
        .success(function(data) {
          if(data.status === 200)
          {
            $scope.sreports = data.data;
          }

        })
        .error(function(data) {

        });
      }
});

StaffData.controller('STFInvcontroller' ,['$scope', '$http','$location','$window', function($scope, $http,$location,$window){
       $http.get('/staff/patient/investigation/data')
       .success(function(data) {

            if(data.status === 200)
            {
              $scope.invdetail = data.data;
            }

        })
        .error(function(data) {

        });

        $scope.setIndex = function(i) {
          for(x in $scope.invdetail)
          {
            if($scope.invdetail[x].case_detail.visit_detail._id === i)
            {

              $scope.PT.id = $scope.invdetail[x]._id;
              $scope.PT.case = $scope.invdetail[x].case_detail._id;
              $scope.PT.visit = $scope.invdetail[x].case_detail.visit_detail._id;
                  $scope.PT.app_date = $scope.invdetail[x].case_detail.visit_detail.app_date;
              $scope.invst = $scope.invdetail[x].case_detail.visit_detail.treatment.report;
              $scope.PT.dir_name = $scope.invdetail[x].dir_name;

              break;

            }
          }
        }
        $scope.uploadInv = function() {
          if (confirm('Do you want to upload investigation?')) {

          var fd = new FormData();
          for(var key in $scope.PT){
            fd.append(key, $scope.PT[key]);
        }

        $http.post('/staff/patient/investigation/upload', fd,
        {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        })
         .success(function(data) {
                    $scope.PT = {}; // clear the form so our user is ready to enter another
                    if(data.status === 200)
                    {
                      $location.path("/staff/investigation/upload");
                      $window.alert(data.error);
                    }

                })
           .error(function(data) {
              
           });
        }
      };
  }]);


StaffData.factory('SharedScope', function() {
    var sharedData = {};

    sharedData.Data = '';

    sharedData.sharingData = function(data) {
        this.Data = data;
    };

    return sharedData;
});
