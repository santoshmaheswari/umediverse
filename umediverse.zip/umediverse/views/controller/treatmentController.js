var Treatmentdata = angular.module('Treatmentdata', []);


Treatmentdata.controller('TRcontroller' , function($scope, $http,$location,$window){
      $http.get('/treatment/category')
      .success(function(data) {
        if(data.status === 200)
        {
          $scope.details = data.data;
        }

      })
      .error(function(data) {

      });

      $scope.getdata = function() {

                  $http.get('/treatment/data/'+$scope.TR.DC)
                  .success(function(data) {
                    if(data.status === 200)
                    {
                           $scope.datas = data.data[0];
                        }

                       })
                  .error(function(data) {

                  });
            };

      $scope.AddCO = function() {

                  $http.post('/treatment/co', $scope.TR)
                        .success(function(data) {
                                 $scope.TR.TCO = [];

                                 if(data.status === 200)
                                 {
                                   $location.path("/admin/treatment_data");
                                   $window.alert(data.error);
                                 }

                             })
                        .error(function(data) {

                        });
        };

        $scope.AddHF = function() {

                    $http.post('/treatment/history/family', $scope.TR)
                          .success(function(data) {
                                   $scope.TR.THF = [];

                                   if(data.status === 200)
                                   {
                                     $location.path("/admin/treatment_data");
                                     $window.alert(data.error);
                                   }

                               })
                          .error(function(data) {

                          });
          };

          $scope.AddHP = function() {

                      $http.post('/treatment/history/personal', $scope.TR)
                            .success(function(data) {
                                     $scope.TR.THP = [];

                                     if(data.status === 200)
                                     {
                                       $location.path("/admin/treatment_data");
                                       $window.alert(data.error);
                                     }

                                 })
                            .error(function(data) {

                            });
            };

        $scope.AddRep = function() {

                    $http.post('/treatment/report', $scope.TR)
                          .success(function(data) {
                               $scope.TR.TRep = [];

                             if(data.status === 200)
                             {
                               $location.path("/admin/treatment_data");
                               $window.alert(data.error);
                             }

                         })
                        .error(function(data) {

                         });
       };

       $scope.AddDig = function() {

                   $http.post('/treatment/dignosis', $scope.TR)
                         .success(function(data) {
                                  $scope.TR.TDig = [];

                                  if(data.status === 200)
                                  {
                                    $location.path("/admin/treatment_data");
                                    $window.alert(data.error);
                                  }

                              })
                         .error(function(data) {

                         });
       };

       $scope.AddADV = function() {

                   $http.post('/treatment/advise', $scope.TR)
                         .success(function(data) {
                                  $scope.TR.TAdv = [];

                                  if(data.status === 200)
                                  {
                                    $location.path("/admin/treatment_data");
                                    $window.alert(data.error);
                                  }

                              })
                         .error(function(data) {

                         });
       };

       $scope.deleteCat = function() {
        $http.delete('/treatment/category/' + $scope.TR.DC)
            .success(function(data) {

                if(data.status === 200)
                {
                  $location.path("/admin/treatment_data");
                  $window.alert(data.error);
                }

            })
            .error(function(data) {

            });
      };


});

Treatmentdata.controller('TMcontroller' , function($scope, $http,$location,$window){

      $http.get('/treatment/category')
      .success(function(data) {
        if(data.status === 200)
        {
          $scope.details = data.data;
        }

      })
      .error(function(data) {

      });

      $http.get('/doctor/treatment')
      .success(function(data) {
        if(data.status === 200)
        {
          $scope.d_details = data.data;
        }

      })
      .error(function(data) {

      });

      $scope.getdata = function() {

                  $http.get('/treatment/data/'+$scope.TR.DC)
                  .success(function(data) {
                    if(data.status === 200)
                    {
                           $scope.datas = data.data[0];
                      }

                       })
                  .error(function(data) {

                  });
        };

    

  });
