var addressApp = angular.module("AddressApp",[]);
addressApp.controller("addressCtrl",function($scope){
$scope.address = [
 {
   "AreaName": "Ahmedabad G.P.O. ",
   "PINCODE": "380001",
   "TALUKA": "Ahmedabad",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambawadi ",
   "PINCODE": "380006",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambawadi Vistar ",
   "PINCODE": "380015",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amraiwadi ",
   "PINCODE": "380026",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Anandnagar ",
   "PINCODE": "380007",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Asarwa Chakla ",
   "PINCODE": "380016",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Asarwa Ext South ",
   "PINCODE": "380024",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ashram Road ",
   "PINCODE": "380009",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Azad Society ",
   "PINCODE": "380015",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bapunagar ",
   "PINCODE": "380024",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Behrampura ",
   "PINCODE": "380022",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhairavnath Road ",
   "PINCODE": "380028",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bilasia ",
   "PINCODE": "382330",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bodakdev ",
   "PINCODE": "380054",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Calico Mills ",
   "PINCODE": "380022",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Cantonment ",
   "PINCODE": "380004",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Civil Hospital ",
   "PINCODE": "380016",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ctm Char Rasta ",
   "PINCODE": "380026",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "D Cabin ",
   "PINCODE": "380019",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dariapur ",
   "PINCODE": "380001",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Daxini Society ",
   "PINCODE": "380008",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Delhi Gate ",
   "PINCODE": "380004",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "District Court ",
   "PINCODE": "380001",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dudheshwar Tavdipura ",
   "PINCODE": "380004",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ellisbridge ",
   "PINCODE": "380006",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gandhi Ashram ",
   "PINCODE": "380027",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gandhi Road ",
   "PINCODE": "380001",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghatlodia ",
   "PINCODE": "380061",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gheekanta Road ",
   "PINCODE": "380001",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghodasar ",
   "PINCODE": "380050",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Girdharnagar ",
   "PINCODE": "380004",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gita Mandir Road ",
   "PINCODE": "380022",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gomtipur ",
   "PINCODE": "380021",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gujarat University ",
   "PINCODE": "380009",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "I E Bapunagar ",
   "PINCODE": "380024",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "I I M ",
   "PINCODE": "380015",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Isanpur ",
   "PINCODE": "382443",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jamalpur ",
   "PINCODE": "380001",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jawahar Chowk ",
   "PINCODE": "380008",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jivraj Park ",
   "PINCODE": "380051",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jodhpur Char Rasta ",
   "PINCODE": "380015",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Juhapura ",
   "PINCODE": "380055",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kabir Chowk ",
   "PINCODE": "380005",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kalupur Chakla ",
   "PINCODE": "380001",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khadia ",
   "PINCODE": "380001",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khanpur ",
   "PINCODE": "380001",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khodiyarnagar ",
   "PINCODE": "382350",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khokhara Mehmadabad ",
   "PINCODE": "380008",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Krishnanagar ",
   "PINCODE": "382345",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kubernagar B A ",
   "PINCODE": "382340",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kubernagar ",
   "PINCODE": "382340",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "L G Hospital ",
   "PINCODE": "380008",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lal Darwaja ",
   "PINCODE": "380001",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Limbadia ",
   "PINCODE": "382330",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "M D Marg ",
   "PINCODE": "380022",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Madhupura Market ",
   "PINCODE": "380004",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Makarba ",
   "PINCODE": "380051",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Manek Chowk ",
   "PINCODE": "380001",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Maninagar ",
   "PINCODE": "380008",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Medra ",
   "PINCODE": "382330",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Meghaningar ",
   "PINCODE": "380016",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Memnagar ",
   "PINCODE": "380052",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Motera ",
   "PINCODE": "380005",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Municipal Corporation ",
   "PINCODE": "380001",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "N C Market ",
   "PINCODE": "380002",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "N C Mills ",
   "PINCODE": "382345",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nana Chiloda ",
   "PINCODE": "382330",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Naranpura Vistar ",
   "PINCODE": "380013",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Narayannagar ",
   "PINCODE": "380007",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Naroda I E ",
   "PINCODE": "382330",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Naroda Road ",
   "PINCODE": "382345",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Naroda S A ",
   "PINCODE": "382330",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Naroda ",
   "PINCODE": "382330",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nava Vadaj ",
   "PINCODE": "380013",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navjivan ",
   "PINCODE": "380014",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navrangpura H.O",
   "PINCODE": "380009",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nikol ",
   "PINCODE": "382350",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Noblenagar ",
   "PINCODE": "382340",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "O N G C ",
   "PINCODE": "380005",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Paldi ",
   "PINCODE": "380007",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pardhol ",
   "PINCODE": "382330",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Polytechnic ",
   "PINCODE": "380015",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Post Bureau Extn Counter ",
   "PINCODE": "380004",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Public Office ",
   "PINCODE": "380016",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Raikhad ",
   "PINCODE": "380001",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Railway Colony ",
   "PINCODE": "380019",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Railwaypura ",
   "PINCODE": "380002",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Raipur ",
   "PINCODE": "380001",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajpur Gomtipur ",
   "PINCODE": "380021",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rakhial ",
   "PINCODE": "380023",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rakhial Udyog Vistar ",
   "PINCODE": "380023",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Revdibazar H.O",
   "PINCODE": "380002",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "S A C ",
   "PINCODE": "380015",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "S A Mills ",
   "PINCODE": "380008",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sabarmati ",
   "PINCODE": "380005",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Saijpur Bogha ",
   "PINCODE": "382345",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Saraspur ",
   "PINCODE": "380018",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sardarnagar ",
   "PINCODE": "382475",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sarkhej Road ",
   "PINCODE": "380007",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shah Alam Roza ",
   "PINCODE": "380028",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shahibag ",
   "PINCODE": "380004",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shahpur ",
   "PINCODE": "380004",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shardanagar ",
   "PINCODE": "380007",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shastrinagar ",
   "PINCODE": "380013",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sola H B C ",
   "PINCODE": "380013",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Stadium Marg ",
   "PINCODE": "380013",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sub Foreign ",
   "PINCODE": "380004",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sukhrampura ",
   "PINCODE": "380023",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "T B Nagar ",
   "PINCODE": "382350",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Thaltej Road ",
   "PINCODE": "380054",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadaj ",
   "PINCODE": "380013",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasisthnagar ",
   "PINCODE": "380008",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vehlal ",
   "PINCODE": "382330",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vejalpur ",
   "PINCODE": "380051",
   "TALUKA": "AHMEDABAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chandlodia ",
   "PINCODE": "382481",
   "TALUKA": "AHMEDABAD CITY",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gujrat High Court ",
   "PINCODE": "380060",
   "TALUKA": "AHMEDABAD CITY",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gyaspur ",
   "PINCODE": "382405",
   "TALUKA": "AHMEDABAD CITY",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kali ",
   "PINCODE": "382470",
   "TALUKA": "AHMEDABAD CITY",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nirnaynagar ",
   "PINCODE": "382481",
   "TALUKA": "AHMEDABAD CITY",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Odhav Industrial Estate ",
   "PINCODE": "382415",
   "TALUKA": "AHMEDABAD CITY",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Odhav ",
   "PINCODE": "382415",
   "TALUKA": "AHMEDABAD CITY",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ranip ",
   "PINCODE": "382480",
   "TALUKA": "AHMEDABAD CITY",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Saijpur ",
   "PINCODE": "382405",
   "TALUKA": "AHMEDABAD CITY",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sarkhej ",
   "PINCODE": "382210",
   "TALUKA": "AHMEDABAD CITY",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shahwadi ",
   "PINCODE": "382405",
   "TALUKA": "AHMEDABAD CITY",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tragad ",
   "PINCODE": "382470",
   "TALUKA": "AHMEDABAD CITY",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Barwala Ghelasha ",
   "PINCODE": "382450",
   "TALUKA": "BARWALA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bela ",
   "PINCODE": "382450",
   "TALUKA": "BARWALA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chokdi ",
   "PINCODE": "382250",
   "TALUKA": "BARWALA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hebatpur ",
   "PINCODE": "382455",
   "TALUKA": "BARWALA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khambhada ",
   "PINCODE": "382450",
   "TALUKA": "BARWALA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khamidana ",
   "PINCODE": "382450",
   "TALUKA": "BARWALA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kundal ",
   "PINCODE": "382450",
   "TALUKA": "BARWALA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navda ",
   "PINCODE": "382450",
   "TALUKA": "BARWALA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Polarpur ",
   "PINCODE": "382250",
   "TALUKA": "BARWALA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rampura ",
   "PINCODE": "382450",
   "TALUKA": "BARWALA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Refda ",
   "PINCODE": "382255",
   "TALUKA": "BARWALA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rojid ",
   "PINCODE": "382450",
   "TALUKA": "BARWALA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Salangpur - Hanuman ",
   "PINCODE": "382451",
   "TALUKA": "BARWALA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sangasar ",
   "PINCODE": "382463",
   "TALUKA": "BARWALA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shahpur ",
   "PINCODE": "382250",
   "TALUKA": "BARWALA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sodhi ",
   "PINCODE": "382463",
   "TALUKA": "BARWALA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadhela ",
   "PINCODE": "382450",
   "TALUKA": "BARWALA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Valhia ",
   "PINCODE": "382450",
   "TALUKA": "BARWALA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Adroda ",
   "PINCODE": "382220",
   "TALUKA": "BAVLA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bagodara ",
   "PINCODE": "382230",
   "TALUKA": "BAVLA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Baldana ",
   "PINCODE": "382240",
   "TALUKA": "BAVLA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bamsara ",
   "PINCODE": "382240",
   "TALUKA": "BAVLA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bavla Market Yard ",
   "PINCODE": "382220",
   "TALUKA": "BAVLA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bavla ",
   "PINCODE": "382220",
   "TALUKA": "BAVLA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhayla ",
   "PINCODE": "382220",
   "TALUKA": "BAVLA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chhabasar ",
   "PINCODE": "382220",
   "TALUKA": "BAVLA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chiada ",
   "PINCODE": "382220",
   "TALUKA": "BAVLA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dehgamda ",
   "PINCODE": "382220",
   "TALUKA": "BAVLA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Deo Dholera ",
   "PINCODE": "382240",
   "TALUKA": "BAVLA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhanwada ",
   "PINCODE": "382220",
   "TALUKA": "BAVLA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhingada ",
   "PINCODE": "382230",
   "TALUKA": "BAVLA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Durgi ",
   "PINCODE": "382230",
   "TALUKA": "BAVLA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gangad ",
   "PINCODE": "382240",
   "TALUKA": "BAVLA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Juval Rupavati ",
   "PINCODE": "382220",
   "TALUKA": "BAVLA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kalyangadh ",
   "PINCODE": "382240",
   "TALUKA": "BAVLA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kavitha ",
   "PINCODE": "382260",
   "TALUKA": "BAVLA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kerala ",
   "PINCODE": "382220",
   "TALUKA": "BAVLA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kesardi ",
   "PINCODE": "382240",
   "TALUKA": "BAVLA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kocharia ",
   "PINCODE": "382220",
   "TALUKA": "BAVLA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mithapur ",
   "PINCODE": "382230",
   "TALUKA": "BAVLA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nanodara ",
   "PINCODE": "382220",
   "TALUKA": "BAVLA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajoda ",
   "PINCODE": "382220",
   "TALUKA": "BAVLA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ranesar ",
   "PINCODE": "382220",
   "TALUKA": "BAVLA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rasam ",
   "PINCODE": "382220",
   "TALUKA": "BAVLA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rohika ",
   "PINCODE": "382230",
   "TALUKA": "BAVLA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rupal ",
   "PINCODE": "382220",
   "TALUKA": "BAVLA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Salajada ",
   "PINCODE": "382220",
   "TALUKA": "BAVLA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sankod ",
   "PINCODE": "382220",
   "TALUKA": "BAVLA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shiyal ",
   "PINCODE": "382230",
   "TALUKA": "BAVLA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambli ",
   "PINCODE": "380058",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Aslali ",
   "PINCODE": "382427",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bakrol ",
   "PINCODE": "382210",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bakrol ",
   "PINCODE": "382430",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhat ",
   "PINCODE": "382210",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhavda ",
   "PINCODE": "382433",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhuvaldi ",
   "PINCODE": "382430",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bopal ",
   "PINCODE": "380058",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chandial ",
   "PINCODE": "382433",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhamatvan ",
   "PINCODE": "382435",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Digvijaynagar ",
   "PINCODE": "382470",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Fatewadi ",
   "PINCODE": "382210",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gamdi ",
   "PINCODE": "382435",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gatrad ",
   "PINCODE": "382449",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Geratpur ",
   "PINCODE": "382435",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghuma ",
   "PINCODE": "380058",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Girmatha ",
   "PINCODE": "382425",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gota ",
   "PINCODE": "382481",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Harniav ",
   "PINCODE": "382435",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jagatpur ",
   "PINCODE": "382470",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jantanagar ",
   "PINCODE": "382449",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jetalpur ",
   "PINCODE": "382426",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kathwada Maize Product ",
   "PINCODE": "382430",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kuha ",
   "PINCODE": "382433",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mahijada ",
   "PINCODE": "382425",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Miroli ",
   "PINCODE": "382425",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Muktipur ",
   "PINCODE": "382425",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nandej ",
   "PINCODE": "382435",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Narol ",
   "PINCODE": "382405",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Paldi Kankaj ",
   "PINCODE": "382425",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pirana ",
   "PINCODE": "382425",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Thaltej ",
   "PINCODE": "380059",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Timba ",
   "PINCODE": "382425",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasai ",
   "PINCODE": "382425",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vastral ",
   "PINCODE": "382418",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vatva Industrial Estate ",
   "PINCODE": "382445",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vatva ",
   "PINCODE": "382440",
   "TALUKA": "DASCROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhadaj ",
   "PINCODE": "380060",
   "TALUKA": "DASKROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chaulaj ",
   "PINCODE": "382433",
   "TALUKA": "DASKROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hathijan ",
   "PINCODE": "382445",
   "TALUKA": "DASKROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hirapur ",
   "PINCODE": "382435",
   "TALUKA": "DASKROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kanbha ",
   "PINCODE": "382430",
   "TALUKA": "DASKROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kaniyel ",
   "PINCODE": "382433",
   "TALUKA": "DASKROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kathwada ",
   "PINCODE": "382430",
   "TALUKA": "DASKROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khodiyar ",
   "PINCODE": "382421",
   "TALUKA": "DASKROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kubadthal ",
   "PINCODE": "382430",
   "TALUKA": "DASKROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kujad ",
   "PINCODE": "382430",
   "TALUKA": "DASKROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lambha ",
   "PINCODE": "382405",
   "TALUKA": "DASKROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lapkaman ",
   "PINCODE": "380060",
   "TALUKA": "DASKROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ode ",
   "PINCODE": "382427",
   "TALUKA": "DASKROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ognaj ",
   "PINCODE": "380060",
   "TALUKA": "DASKROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pasunj ",
   "PINCODE": "382430",
   "TALUKA": "DASKROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ramol ",
   "PINCODE": "382449",
   "TALUKA": "DASKROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ranodra ",
   "PINCODE": "382433",
   "TALUKA": "DASKROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shilaj ",
   "PINCODE": "380058",
   "TALUKA": "DASKROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sola ",
   "PINCODE": "380060",
   "TALUKA": "DASKROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Undrel ",
   "PINCODE": "382433",
   "TALUKA": "DASKROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadod ",
   "PINCODE": "382433",
   "TALUKA": "DASKROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vanch ",
   "PINCODE": "382449",
   "TALUKA": "DASKROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vinzol ",
   "PINCODE": "382445",
   "TALUKA": "DASKROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vishalpur ",
   "PINCODE": "382210",
   "TALUKA": "DASKROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zanu ",
   "PINCODE": "382430",
   "TALUKA": "DASKROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bareja ",
   "PINCODE": "382425",
   "TALUKA": "DASROI",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bamroli ",
   "PINCODE": "382145",
   "TALUKA": "DETRIOJ-RAMPURA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chuval Dangarva ",
   "PINCODE": "382145",
   "TALUKA": "DETROJ RAMPURA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dekawada ",
   "PINCODE": "382120",
   "TALUKA": "DETROJ RAMPURA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gunjala ",
   "PINCODE": "382120",
   "TALUKA": "DETROJ RAMPURA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chhaniar ",
   "PINCODE": "382140",
   "TALUKA": "DETROJ- RAMPURA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gamanpura ",
   "PINCODE": "382120",
   "TALUKA": "DETROJ- RAMPURA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghatisana ",
   "PINCODE": "382140",
   "TALUKA": "DETROJ- RAMPURA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Abasana ",
   "PINCODE": "382120",
   "TALUKA": "DETROJ-RAMPURA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ashoknagar ",
   "PINCODE": "382140",
   "TALUKA": "DETROJ-RAMPURA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Balsasan ",
   "PINCODE": "382145",
   "TALUKA": "DETROJ-RAMPURA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhankoda ",
   "PINCODE": "382140",
   "TALUKA": "DETROJ-RAMPURA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhoyani ",
   "PINCODE": "382145",
   "TALUKA": "DETROJ-RAMPURA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Charol ",
   "PINCODE": "382120",
   "TALUKA": "DETROJ-RAMPURA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dabhsar ",
   "PINCODE": "382120",
   "TALUKA": "DETROJ-RAMPURA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Detroj ",
   "PINCODE": "382120",
   "TALUKA": "DETROJ-RAMPURA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kanz ",
   "PINCODE": "382140",
   "TALUKA": "DETROJ-RAMPURA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Katosan Road ",
   "PINCODE": "382145",
   "TALUKA": "DETROJ-RAMPURA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kointia ",
   "PINCODE": "382140",
   "TALUKA": "DETROJ-RAMPURA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kukvav ",
   "PINCODE": "382120",
   "TALUKA": "DETROJ-RAMPURA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Madrisana ",
   "PINCODE": "382145",
   "TALUKA": "DETROJ-RAMPURA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Marusana ",
   "PINCODE": "382120",
   "TALUKA": "DETROJ-RAMPURA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moti Rantai ",
   "PINCODE": "382145",
   "TALUKA": "DETROJ-RAMPURA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nadishala ",
   "PINCODE": "382120",
   "TALUKA": "DETROJ-RAMPURA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Odhav ",
   "PINCODE": "382120",
   "TALUKA": "DETROJ-RAMPURA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panar ",
   "PINCODE": "382140",
   "TALUKA": "DETROJ-RAMPURA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rampura ",
   "PINCODE": "382140",
   "TALUKA": "DETROJ-RAMPURA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rudatal ",
   "PINCODE": "382120",
   "TALUKA": "DETROJ-RAMPURA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sadatpura ",
   "PINCODE": "382120",
   "TALUKA": "DETROJ-RAMPURA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sangpura ",
   "PINCODE": "382120",
   "TALUKA": "DETROJ-RAMPURA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sihor ",
   "PINCODE": "382140",
   "TALUKA": "DETROJ-RAMPURA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sobhasan ",
   "PINCODE": "382145",
   "TALUKA": "DETROJ-RAMPURA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sunvala ",
   "PINCODE": "382145",
   "TALUKA": "DETROJ-RAMPURA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Telavi ",
   "PINCODE": "382145",
   "TALUKA": "DETROJ-RAMPURA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Adval ",
   "PINCODE": "382460",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Akru ",
   "PINCODE": "382250",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambli ",
   "PINCODE": "382463",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Aniali Bhimji ",
   "PINCODE": "382250",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Badanpur ",
   "PINCODE": "382465",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bajarda ",
   "PINCODE": "382460",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bavaliary ",
   "PINCODE": "382455",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhadiad ",
   "PINCODE": "382463",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhangadh ",
   "PINCODE": "382455",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chandarva ",
   "PINCODE": "382255",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chhasiana ",
   "PINCODE": "382460",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhanala ",
   "PINCODE": "382465",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhandhuka ",
   "PINCODE": "382460",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dholera ",
   "PINCODE": "382455",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Fatepur ",
   "PINCODE": "382465",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Fedra ",
   "PINCODE": "382465",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Galsana ",
   "PINCODE": "363610",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gamph ",
   "PINCODE": "382465",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gogla ",
   "PINCODE": "382463",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gorasu ",
   "PINCODE": "382463",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gunjar ",
   "PINCODE": "382460",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jaliya ",
   "PINCODE": "382460",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jeska ",
   "PINCODE": "382250",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kadipur ",
   "PINCODE": "382463",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kamiala ",
   "PINCODE": "382465",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kasindra ",
   "PINCODE": "382465",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kasindra ",
   "PINCODE": "382210",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khadol ",
   "PINCODE": "382460",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khandachora Dhandhuka ",
   "PINCODE": "382460",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kharad ",
   "PINCODE": "382460",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khasta ",
   "PINCODE": "382460",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khun ",
   "PINCODE": "382455",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kothadia ",
   "PINCODE": "382460",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mingalpur ",
   "PINCODE": "382455",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mota Tradia ",
   "PINCODE": "382460",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Otaria ",
   "PINCODE": "382463",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Otaria Sarvodaya Ashram ",
   "PINCODE": "382463",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Padana ",
   "PINCODE": "382460",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panchham ",
   "PINCODE": "382465",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panchhi ",
   "PINCODE": "382455",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Parabadi ",
   "PINCODE": "382250",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pipli ",
   "PINCODE": "382465",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rayka ",
   "PINCODE": "382460",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rojka ",
   "PINCODE": "382460",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Salasar ",
   "PINCODE": "363610",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sandhida ",
   "PINCODE": "382455",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shela ",
   "PINCODE": "382465",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tagadi ",
   "PINCODE": "382250",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Unchadi ",
   "PINCODE": "382250",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vagad ",
   "PINCODE": "363610",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Valinda ",
   "PINCODE": "382463",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasna ",
   "PINCODE": "382460",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zanzarka ",
   "PINCODE": "382460",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zinzar ",
   "PINCODE": "382250",
   "TALUKA": "DHANDHUKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambaliara ",
   "PINCODE": "387810",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambareli ",
   "PINCODE": "387810",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Arnej ",
   "PINCODE": "382230",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Badarkha ",
   "PINCODE": "382276",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bholad ",
   "PINCODE": "382230",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhurkhi ",
   "PINCODE": "382230",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chaloda ",
   "PINCODE": "382260",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chandisar ",
   "PINCODE": "382260",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dadusar ",
   "PINCODE": "387810",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dholi ",
   "PINCODE": "382240",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dholka H.O",
   "PINCODE": "387810",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ganol ",
   "PINCODE": "382265",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gundi Sarvodaya Ashram ",
   "PINCODE": "382230",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ingoli ",
   "PINCODE": "382265",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jakhada ",
   "PINCODE": "382230",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jalalpur Vajifa ",
   "PINCODE": "387810",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jawaraj ",
   "PINCODE": "382230",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kauka ",
   "PINCODE": "382265",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kelia  Vasna ",
   "PINCODE": "387810",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kharakuva Dholka ",
   "PINCODE": "387810",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Koth ",
   "PINCODE": "382240",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Loliya ",
   "PINCODE": "382465",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lothal Bhurkhi RS ",
   "PINCODE": "382230",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moti Boru ",
   "PINCODE": "382230",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nani Boru ",
   "PINCODE": "382230",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nesda ",
   "PINCODE": "387810",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pisawada ",
   "PINCODE": "382265",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rampur ",
   "PINCODE": "387810",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ranoda ",
   "PINCODE": "387810",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rupgadh ",
   "PINCODE": "382240",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sahij ",
   "PINCODE": "387810",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Saiwada ",
   "PINCODE": "387810",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sarandi ",
   "PINCODE": "387810",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sargwala ",
   "PINCODE": "382230",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Saroda ",
   "PINCODE": "382260",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sathal ",
   "PINCODE": "387810",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sherpura ",
   "PINCODE": "387810",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Simej ",
   "PINCODE": "382265",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sindharej ",
   "PINCODE": "387810",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Transad ",
   "PINCODE": "387810",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Utelia ",
   "PINCODE": "382230",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Valdhera ",
   "PINCODE": "387810",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Varna ",
   "PINCODE": "382265",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vataman ",
   "PINCODE": "382265",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vautha ",
   "PINCODE": "387810",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vejalka ",
   "PINCODE": "382230",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Virdi ",
   "PINCODE": "382265",
   "TALUKA": "DHOLKA",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dadhana ",
   "PINCODE": "382120",
   "TALUKA": "MANDAL",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dalod ",
   "PINCODE": "382130",
   "TALUKA": "MANDAL",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhedasana ",
   "PINCODE": "382130",
   "TALUKA": "MANDAL",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Endla ",
   "PINCODE": "382130",
   "TALUKA": "MANDAL",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jalisana ",
   "PINCODE": "382120",
   "TALUKA": "MANDAL",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kadvasan ",
   "PINCODE": "382130",
   "TALUKA": "MANDAL",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kunpur ",
   "PINCODE": "382130",
   "TALUKA": "MANDAL",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mandal ",
   "PINCODE": "382130",
   "TALUKA": "MANDAL",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nana Ubhada ",
   "PINCODE": "382130",
   "TALUKA": "MANDAL",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navagam ",
   "PINCODE": "382130",
   "TALUKA": "MANDAL",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nayakpur ",
   "PINCODE": "382130",
   "TALUKA": "MANDAL",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rakhiana ",
   "PINCODE": "382130",
   "TALUKA": "MANDAL",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ribadi ",
   "PINCODE": "382130",
   "TALUKA": "MANDAL",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sher ",
   "PINCODE": "382130",
   "TALUKA": "MANDAL",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sinaj ",
   "PINCODE": "382120",
   "TALUKA": "MANDAL",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sitapur ",
   "PINCODE": "382130",
   "TALUKA": "MANDAL",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Solgam ",
   "PINCODE": "382130",
   "TALUKA": "MANDAL",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Trent ",
   "PINCODE": "382150",
   "TALUKA": "MANDAL",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ughroj ",
   "PINCODE": "382120",
   "TALUKA": "MANDAL",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ukardi ",
   "PINCODE": "382140",
   "TALUKA": "MANDAL",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vanpardi ",
   "PINCODE": "382130",
   "TALUKA": "MANDAL",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Varmor ",
   "PINCODE": "382130",
   "TALUKA": "MANDAL",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vinchhan ",
   "PINCODE": "382120",
   "TALUKA": "MANDAL",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vinzuvada ",
   "PINCODE": "382130",
   "TALUKA": "MANDAL",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vithlpura ",
   "PINCODE": "382120",
   "TALUKA": "MANDAL",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zanzarva ",
   "PINCODE": "382120",
   "TALUKA": "MANDAL",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Alampur ",
   "PINCODE": "363610",
   "TALUKA": "RANPUR",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Alau ",
   "PINCODE": "382255",
   "TALUKA": "RANPUR",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Aniali ( K ) ",
   "PINCODE": "363610",
   "TALUKA": "RANPUR",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bagad ",
   "PINCODE": "382255",
   "TALUKA": "RANPUR",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bodia ",
   "PINCODE": "363610",
   "TALUKA": "RANPUR",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Charanki ",
   "PINCODE": "382450",
   "TALUKA": "RANPUR",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Devaliya ",
   "PINCODE": "363610",
   "TALUKA": "RANPUR",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dharpipla ",
   "PINCODE": "363610",
   "TALUKA": "RANPUR",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Godhavata ",
   "PINCODE": "382255",
   "TALUKA": "RANPUR",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gunda ",
   "PINCODE": "382255",
   "TALUKA": "RANPUR",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jalila ",
   "PINCODE": "382255",
   "TALUKA": "RANPUR",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Keria ",
   "PINCODE": "363610",
   "TALUKA": "RANPUR",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khas ",
   "PINCODE": "382255",
   "TALUKA": "RANPUR",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khokarnesh ",
   "PINCODE": "363610",
   "TALUKA": "RANPUR",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kundli ",
   "PINCODE": "363610",
   "TALUKA": "RANPUR",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moti Vavdi ",
   "PINCODE": "382255",
   "TALUKA": "RANPUR",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nani Vavdi ",
   "PINCODE": "363610",
   "TALUKA": "RANPUR",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajpura ",
   "PINCODE": "363610",
   "TALUKA": "RANPUR",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ranpur ",
   "PINCODE": "363610",
   "TALUKA": "RANPUR",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sunderiana ",
   "PINCODE": "382255",
   "TALUKA": "RANPUR",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umrela ",
   "PINCODE": "363610",
   "TALUKA": "RANPUR",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Andej ",
   "PINCODE": "382115",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bakrana ",
   "PINCODE": "382170",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bol ",
   "PINCODE": "382170",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Changodar ",
   "PINCODE": "382213",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Charel ",
   "PINCODE": "382110",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chekhla ",
   "PINCODE": "382115",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chharodi ",
   "PINCODE": "382170",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Daran ",
   "PINCODE": "382220",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Devtimoti ",
   "PINCODE": "382213",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dodar ",
   "PINCODE": "382170",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Fangadi ",
   "PINCODE": "382110",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Garodia ",
   "PINCODE": "382115",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Godhavi ",
   "PINCODE": "382115",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Goraj ",
   "PINCODE": "382110",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Iawa (Vasna) ",
   "PINCODE": "382170",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jamp ",
   "PINCODE": "382110",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jholapur ",
   "PINCODE": "382170",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Juval ",
   "PINCODE": "382220",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kalana ",
   "PINCODE": "382170",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kaneti ",
   "PINCODE": "382110",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khoda ",
   "PINCODE": "382170",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khorajnanoda ",
   "PINCODE": "382170",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kolat ",
   "PINCODE": "382210",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kundal ",
   "PINCODE": "382110",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kunvar ",
   "PINCODE": "382110",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Makhiav ",
   "PINCODE": "382110",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mankol ",
   "PINCODE": "382110",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Matoda ",
   "PINCODE": "382213",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Modasar ",
   "PINCODE": "382220",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moraiya ",
   "PINCODE": "382213",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nani Devti ",
   "PINCODE": "382220",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navapura ",
   "PINCODE": "382210",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nedharad ",
   "PINCODE": "382115",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pimpan ",
   "PINCODE": "382110",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rethal ",
   "PINCODE": "382110",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sanand ",
   "PINCODE": "382110",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sanathal ",
   "PINCODE": "382210",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sari ",
   "PINCODE": "382220",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shela ",
   "PINCODE": "380058",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Siawada ",
   "PINCODE": "382170",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Telav ",
   "PINCODE": "382210",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Upardal ",
   "PINCODE": "382110",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasna  (Iawa) ",
   "PINCODE": "382170",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasna  Chacharvadi ",
   "PINCODE": "382213",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vinchhiya ",
   "PINCODE": "382110",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Virochannagar ",
   "PINCODE": "382170",
   "TALUKA": "SANAND",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Daduka ",
   "PINCODE": "382110",
   "TALUKA": "SANNAD",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Asalgam ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhadana ",
   "PINCODE": "382140",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhojwa ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bordibazar Viramgam ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chandranagar ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Daslana ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Devpura ",
   "PINCODE": "382140",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhakdi ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dumana ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghoda ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Goraiya ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hansalpur ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hirapura ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jakwada ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jalampur ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Joshipura ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Junapadhar ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kamijala ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kankravadi ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karakthal ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khudad ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kokta ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kumarkhan ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Manipur ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Melaj ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moti  Kishol ",
   "PINCODE": "382110",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ogan ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rahemalpur ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rangpur ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sachana ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sarsavadi ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shahpur ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shivpura ",
   "PINCODE": "382140",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Thori Mubarak ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Thori Thumbha ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Thuleta ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ukhlod ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadgas ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vani ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vansva ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vanthal ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vekaria ",
   "PINCODE": "382110",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Viramgam ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zezra ",
   "PINCODE": "382150",
   "TALUKA": "VIRAMGAM",
   "DISTRICT": "AHMEDABAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amarpur ",
   "PINCODE": "365450",
   "TALUKA": ".",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Abhrampara ",
   "PINCODE": "364522",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Adsang ",
   "PINCODE": "364522",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Adtala ",
   "PINCODE": "365430",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Akala ",
   "PINCODE": "365430",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amba ",
   "PINCODE": "365535",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambaradi ",
   "PINCODE": "365630",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambardi ",
   "PINCODE": "365220",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambardi J ",
   "PINCODE": "364522",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amreli H.O",
   "PINCODE": "365601",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amreli J P ",
   "PINCODE": "365601",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amreli M P ",
   "PINCODE": "365601",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amreli S R ",
   "PINCODE": "365601",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amreli ",
   "PINCODE": "365601",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amrelit R ",
   "PINCODE": "365601",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amrpur V ",
   "PINCODE": "365601",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amrutpur ",
   "PINCODE": "365660",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amrutvel ",
   "PINCODE": "364521",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Anida ",
   "PINCODE": "365450",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Anida ",
   "PINCODE": "365635",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ankadia-nana ",
   "PINCODE": "365620",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ansodar ",
   "PINCODE": "365220",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Arjansukh ",
   "PINCODE": "365480",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Babapur ",
   "PINCODE": "365610",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Babarkot ",
   "PINCODE": "365540",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Babra ",
   "PINCODE": "365421",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Babriyadhar ",
   "PINCODE": "365560",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Badhada ",
   "PINCODE": "364522",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bagasra ",
   "PINCODE": "365440",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bagoya ",
   "PINCODE": "364522",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bagrsa Sr ",
   "PINCODE": "365440",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Balapur ",
   "PINCODE": "365456",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Balel-piparia ",
   "PINCODE": "365460",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bambhaniya ",
   "PINCODE": "365460",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bantva-devli ",
   "PINCODE": "365480",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Barbtana ",
   "PINCODE": "365560",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Barman-nana ",
   "PINCODE": "365545",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Barman-nana ",
   "PINCODE": "365545",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Barpatoli ",
   "PINCODE": "365560",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Barvala-baval ",
   "PINCODE": "365480",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhandaria Nana ",
   "PINCODE": "365601",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhandriya Mota ",
   "PINCODE": "365610",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bordi ",
   "PINCODE": "365640",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chadiya ",
   "PINCODE": "365630",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chakkargadh ",
   "PINCODE": "365601",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chakragadh ",
   "PINCODE": "365601",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chandgadh ",
   "PINCODE": "365601",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chhatadiya ",
   "PINCODE": "365630",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chital ",
   "PINCODE": "365620",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chrania ",
   "PINCODE": "365480",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dadva(Randal) ",
   "PINCODE": "365460",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Devaliya ",
   "PINCODE": "365601",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Devalki ",
   "PINCODE": "365480",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Devarajiya ",
   "PINCODE": "365630",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhargni ",
   "PINCODE": "365630",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Fatepur ",
   "PINCODE": "365601",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gakharvalamota ",
   "PINCODE": "365601",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gavdka ",
   "PINCODE": "365610",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ingorala-2 ",
   "PINCODE": "365620",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ishavariya ",
   "PINCODE": "365601",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jaliya ",
   "PINCODE": "365616",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jangar ",
   "PINCODE": "365455",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jasvantgadh ",
   "PINCODE": "365620",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Keriyanagas ",
   "PINCODE": "365601",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kovaya ",
   "PINCODE": "365541",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lakhapadar ",
   "PINCODE": "365460",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lalavadar ",
   "PINCODE": "365601",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Machyalanana ",
   "PINCODE": "365601",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mangvapal ",
   "PINCODE": "365601",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Monpur ",
   "PINCODE": "365620",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mota-ankadiya ",
   "PINCODE": "365455",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pipallag ",
   "PINCODE": "365455",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pithvajal ",
   "PINCODE": "365610",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajsathli ",
   "PINCODE": "365610",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Randhiya ",
   "PINCODE": "365620",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Randhiya ",
   "PINCODE": "365620",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rangpur ",
   "PINCODE": "365601",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sanosara ",
   "PINCODE": "365610",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sonariya ",
   "PINCODE": "365601",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Taraktalv ",
   "PINCODE": "365610",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tarvada ",
   "PINCODE": "365610",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadera ",
   "PINCODE": "365610",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vankiya ",
   "PINCODE": "365610",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vathalpur K ",
   "PINCODE": "365601",
   "TALUKA": "AMRELI",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chamaradi ",
   "PINCODE": "365410",
   "TALUKA": "Babra",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vaghaniya ",
   "PINCODE": "365456",
   "TALUKA": "Bagsra",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhader ",
   "PINCODE": "365645",
   "TALUKA": "Dhari",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chalala ",
   "PINCODE": "365630",
   "TALUKA": "Dhari",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhari ",
   "PINCODE": "365640",
   "TALUKA": "Dhari",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhari SR ",
   "PINCODE": "365640",
   "TALUKA": "Dhari",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gopalgram ",
   "PINCODE": "365632",
   "TALUKA": "Dhari",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sarsiya ",
   "PINCODE": "365660",
   "TALUKA": "Dhari",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nageshri ",
   "PINCODE": "365545",
   "TALUKA": "Jafrabad",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Timbi ",
   "PINCODE": "362730",
   "TALUKA": "Jafrabad",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dedan ",
   "PINCODE": "365550",
   "TALUKA": "Khambha",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khambha ",
   "PINCODE": "365650",
   "TALUKA": "Khambha",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Motasamdhiyala ",
   "PINCODE": "365635",
   "TALUKA": "Khambha",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kunkavav ",
   "PINCODE": "365450",
   "TALUKA": "Kunkvav-Vadia",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lunidhar ",
   "PINCODE": "365460",
   "TALUKA": "Kunkvav-Vadia",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadia ",
   "PINCODE": "365480",
   "TALUKA": "Kunkvav-Vadia",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Damnagar ",
   "PINCODE": "365220",
   "TALUKA": "Lathi",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lathi ",
   "PINCODE": "365430",
   "TALUKA": "Lathi",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Krankach ",
   "PINCODE": "365665",
   "TALUKA": "Liliya",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Liliya ",
   "PINCODE": "365535",
   "TALUKA": "Liliya",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dungar ",
   "PINCODE": "365565",
   "TALUKA": "Rajula",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jafrabad ",
   "PINCODE": "365540",
   "TALUKA": "Rajula",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajula ",
   "PINCODE": "365560",
   "TALUKA": "Rajula",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Utcl Kovaya ",
   "PINCODE": "365541",
   "TALUKA": "Rajula",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jira ",
   "PINCODE": "364521",
   "TALUKA": "Savarkundla",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nani-vadal ",
   "PINCODE": "364522",
   "TALUKA": "Savarkundla",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Savar ",
   "PINCODE": "364515",
   "TALUKA": "Savarkundla",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Savarkundla ",
   "PINCODE": "364515",
   "TALUKA": "Savarkundla",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Thoradi ",
   "PINCODE": "365601",
   "TALUKA": "Savarkundla",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vanda ",
   "PINCODE": "364525",
   "TALUKA": "Savarkundla",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vijpadi ",
   "PINCODE": "364530",
   "TALUKA": "Savarkundla",
   "DISTRICT": "AMRELI",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "District Court ",
   "PINCODE": "388001",
   "TALUKA": ".",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Adas ",
   "PINCODE": "388305",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ajarpura ",
   "PINCODE": "388310",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ajupura ",
   "PINCODE": "388360",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amuldairy  (Anand) ",
   "PINCODE": "388001",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Anand Agri Inst  (Anand) ",
   "PINCODE": "388110",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Anand H.O",
   "PINCODE": "388001",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Anand Town  (Anand) ",
   "PINCODE": "388001",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bakrol ",
   "PINCODE": "388315",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bedva ",
   "PINCODE": "388320",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhalej ",
   "PINCODE": "388205",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chaklashi ",
   "PINCODE": "387315",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chikhodra ",
   "PINCODE": "388320",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gamdi ",
   "PINCODE": "388001",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gana ",
   "PINCODE": "388345",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gopalpura ",
   "PINCODE": "388370",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hadgood ",
   "PINCODE": "388110",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jitodia ",
   "PINCODE": "388001",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jol ",
   "PINCODE": "388315",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kanbhaipura ",
   "PINCODE": "388205",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karamsad ",
   "PINCODE": "388325",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kasor ",
   "PINCODE": "388205",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khambholej ",
   "PINCODE": "388330",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khandhli ",
   "PINCODE": "388560",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khanpur ",
   "PINCODE": "388365",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kherda ",
   "PINCODE": "388365",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kunjrav ",
   "PINCODE": "388335",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lambhvel ",
   "PINCODE": "388310",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Meghva ",
   "PINCODE": "388345",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mogar ",
   "PINCODE": "388340",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mogri ",
   "PINCODE": "388345",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Napad ",
   "PINCODE": "388350",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navli ",
   "PINCODE": "388355",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ode ",
   "PINCODE": "388210",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajupura ",
   "PINCODE": "388306",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ramnagar ",
   "PINCODE": "388340",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rasnol ",
   "PINCODE": "388335",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ravlapura ",
   "PINCODE": "388360",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Samarkha ",
   "PINCODE": "388360",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sandesar ",
   "PINCODE": "388130",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sardarganj   (Anand) ",
   "PINCODE": "388001",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sarsa ",
   "PINCODE": "388365",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tranol ",
   "PINCODE": "388335",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadod ",
   "PINCODE": "388370",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vaghashi ",
   "PINCODE": "388320",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Valasan ",
   "PINCODE": "388325",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vallabh  Vidyanagar ",
   "PINCODE": "388120",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasad ",
   "PINCODE": "388306",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Verakhadi ",
   "PINCODE": "388365",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Veternary College  (Anand) ",
   "PINCODE": "388001",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vithal Udyognagar ",
   "PINCODE": "388121",
   "TALUKA": "ANAND",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambali ",
   "PINCODE": "388307",
   "TALUKA": "ANKLAV",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambav ",
   "PINCODE": "388307",
   "TALUKA": "ANKLAV",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amrol ",
   "PINCODE": "388307",
   "TALUKA": "ANKLAV",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Anklav ",
   "PINCODE": "388510",
   "TALUKA": "ANKLAV",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Asarma ",
   "PINCODE": "388510",
   "TALUKA": "ANKLAV",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Asodar ",
   "PINCODE": "388307",
   "TALUKA": "ANKLAV",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bamangam ",
   "PINCODE": "388520",
   "TALUKA": "ANKLAV",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhetasi ",
   "PINCODE": "388307",
   "TALUKA": "ANKLAV",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Joshikuva ",
   "PINCODE": "388510",
   "TALUKA": "ANKLAV",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kahanvadi ",
   "PINCODE": "388307",
   "TALUKA": "ANKLAV",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kantharia ",
   "PINCODE": "388307",
   "TALUKA": "ANKLAV",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khadol ",
   "PINCODE": "388350",
   "TALUKA": "ANKLAV",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kinkhlod ",
   "PINCODE": "388510",
   "TALUKA": "ANKLAV",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kosindra ",
   "PINCODE": "388510",
   "TALUKA": "ANKLAV",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mujkuva ",
   "PINCODE": "388307",
   "TALUKA": "ANKLAV",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navakhal ",
   "PINCODE": "388510",
   "TALUKA": "ANKLAV",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umeta ",
   "PINCODE": "388510",
   "TALUKA": "ANKLAV",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Alarsa ",
   "PINCODE": "388543",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amiyad ",
   "PINCODE": "388570",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Banejada ",
   "PINCODE": "388580",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhadran ",
   "PINCODE": "388530",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bilpad ",
   "PINCODE": "388520",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bodal ",
   "PINCODE": "388540",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Boriavi ",
   "PINCODE": "388310",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Borsad ",
   "PINCODE": "388540",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chamara ",
   "PINCODE": "388520",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dabhasi ",
   "PINCODE": "388140",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Davol ",
   "PINCODE": "388540",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dedarda ",
   "PINCODE": "388560",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dehmi ",
   "PINCODE": "388560",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dharmaj-ranoli ",
   "PINCODE": "388430",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhundakuva ",
   "PINCODE": "388130",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gajna ",
   "PINCODE": "388530",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gambhira ",
   "PINCODE": "388520",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Golel ",
   "PINCODE": "388480",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jantral ",
   "PINCODE": "388580",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jharola ",
   "PINCODE": "388590",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kasari ",
   "PINCODE": "388590",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kashipura  (Borsad) ",
   "PINCODE": "388540",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kasumbad ",
   "PINCODE": "388540",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kathol ",
   "PINCODE": "388530",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kavitha ",
   "PINCODE": "388545",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khanpur ",
   "PINCODE": "388430",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khedasa ",
   "PINCODE": "388530",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kothiakhad ",
   "PINCODE": "388520",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Napa ",
   "PINCODE": "388560",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navapura ",
   "PINCODE": "388520",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nisraya ",
   "PINCODE": "388540",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pamol ",
   "PINCODE": "388560",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pipli ",
   "PINCODE": "388530",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ras ",
   "PINCODE": "388570",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rudel ",
   "PINCODE": "388140",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Saijpur ",
   "PINCODE": "388570",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sarol ",
   "PINCODE": "388530",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Singlav ",
   "PINCODE": "388560",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sisva ",
   "PINCODE": "388530",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Surkuva ",
   "PINCODE": "388130",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadeli ",
   "PINCODE": "388590",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Valvod ",
   "PINCODE": "388530",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasna ",
   "PINCODE": "388540",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vera ",
   "PINCODE": "388540",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Virsad ",
   "PINCODE": "388580",
   "TALUKA": "BORSAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Badalpur ",
   "PINCODE": "388550",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bamanva ",
   "PINCODE": "388580",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhuvel ",
   "PINCODE": "388640",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chitari Bazar ",
   "PINCODE": "388620",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Daheda ",
   "PINCODE": "388620",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dahevan ",
   "PINCODE": "388550",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dali ",
   "PINCODE": "388550",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhuvaran ",
   "PINCODE": "388160",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhuvaran Power Station ",
   "PINCODE": "388160",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Finav ",
   "PINCODE": "388580",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Golana ",
   "PINCODE": "388625",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gudel ",
   "PINCODE": "388625",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jalsan ",
   "PINCODE": "388580",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jalundh ",
   "PINCODE": "388640",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jinaj ",
   "PINCODE": "388620",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kalamsar ",
   "PINCODE": "388640",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kalitalavadi ",
   "PINCODE": "388170",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kalu ",
   "PINCODE": "388550",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kanbha ",
   "PINCODE": "388550",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kanisa ",
   "PINCODE": "388170",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kankapura ",
   "PINCODE": "388550",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kansari ",
   "PINCODE": "388630",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kanzat ",
   "PINCODE": "388170",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kathana ",
   "PINCODE": "388550",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kathana RS ",
   "PINCODE": "388550",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khadodhi ",
   "PINCODE": "388160",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khambhat ",
   "PINCODE": "388620",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khatnal ",
   "PINCODE": "388640",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lunej ",
   "PINCODE": "388620",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Malu ",
   "PINCODE": "388620",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Metpur ",
   "PINCODE": "388620",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nagra ",
   "PINCODE": "388620",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nana Kalodara ",
   "PINCODE": "388630",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Naviakhol ",
   "PINCODE": "388625",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pandad ",
   "PINCODE": "388625",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Piploi ",
   "PINCODE": "388640",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pith Baza- Khambhat ",
   "PINCODE": "388620",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ralej ",
   "PINCODE": "388640",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rangpur ",
   "PINCODE": "388620",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sayma ",
   "PINCODE": "388170",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shakarpur ",
   "PINCODE": "388620",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Timba ",
   "PINCODE": "388170",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Undel ",
   "PINCODE": "388640",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadgam ",
   "PINCODE": "388625",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadgam ",
   "PINCODE": "388625",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vainaj ",
   "PINCODE": "388625",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vatadara ",
   "PINCODE": "388580",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vatra ",
   "PINCODE": "388640",
   "TALUKA": "KHAMBHAT",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhalada ",
   "PINCODE": "387240",
   "TALUKA": "MATAR",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Morad ",
   "PINCODE": "388130",
   "TALUKA": "PERLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Agas ",
   "PINCODE": "388130",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amod ",
   "PINCODE": "388160",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ardi ",
   "PINCODE": "388450",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ashi ",
   "PINCODE": "388130",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bamroli ",
   "PINCODE": "387345",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhavanipura ",
   "PINCODE": "388450",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhurakui ",
   "PINCODE": "388430",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bochasan RS ",
   "PINCODE": "388140",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Boria ",
   "PINCODE": "388130",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dantali ",
   "PINCODE": "388450",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Davalpura ",
   "PINCODE": "388450",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dharmaj ",
   "PINCODE": "388430",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Fangani ",
   "PINCODE": "388450",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghunteli ",
   "PINCODE": "388440",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khadana ",
   "PINCODE": "388160",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mahelav ",
   "PINCODE": "388440",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Manaj ",
   "PINCODE": "388150",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Manpura ",
   "PINCODE": "388150",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mariumpura ",
   "PINCODE": "388450",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nar ",
   "PINCODE": "388150",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Padgol ",
   "PINCODE": "388440",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Palaj ",
   "PINCODE": "388465",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pandoli ",
   "PINCODE": "388160",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Petlad RS ",
   "PINCODE": "388450",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Petlad ",
   "PINCODE": "388450",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rangaipura ",
   "PINCODE": "388450",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rupiapura ",
   "PINCODE": "388480",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sansej ",
   "PINCODE": "388180",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Simarda ",
   "PINCODE": "388480",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sinhol ",
   "PINCODE": "388130",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sunav ",
   "PINCODE": "388470",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sundarna ",
   "PINCODE": "388480",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sundra ",
   "PINCODE": "388150",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadadla ",
   "PINCODE": "388275",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Virol [simarda] ",
   "PINCODE": "388480",
   "TALUKA": "PETLAD",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Balinta ",
   "PINCODE": "387240",
   "TALUKA": "SOJITRA",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dabhou ",
   "PINCODE": "387210",
   "TALUKA": "SOJITRA",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Devataj ",
   "PINCODE": "387240",
   "TALUKA": "SOJITRA",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gada ",
   "PINCODE": "387240",
   "TALUKA": "SOJITRA",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Isnav ",
   "PINCODE": "388460",
   "TALUKA": "SOJITRA",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kasor ",
   "PINCODE": "388460",
   "TALUKA": "SOJITRA",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Malataj ",
   "PINCODE": "387220",
   "TALUKA": "SOJITRA",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Manghrol ",
   "PINCODE": "387210",
   "TALUKA": "SOJITRA",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Palol ",
   "PINCODE": "387240",
   "TALUKA": "SOJITRA",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Petli ",
   "PINCODE": "387220",
   "TALUKA": "SOJITRA",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Piplav ",
   "PINCODE": "388460",
   "TALUKA": "SOJITRA",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Runaj ",
   "PINCODE": "388150",
   "TALUKA": "SOJITRA",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sojitra ",
   "PINCODE": "387240",
   "TALUKA": "SOJITRA",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Trambovad ",
   "PINCODE": "387240",
   "TALUKA": "SOJITRA",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Virol ",
   "PINCODE": "387240",
   "TALUKA": "SOJITRA",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Budhej ",
   "PINCODE": "388620",
   "TALUKA": "TARAPUR",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chagada ",
   "PINCODE": "388180",
   "TALUKA": "TARAPUR",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dugari ",
   "PINCODE": "388625",
   "TALUKA": "TARAPUR",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Galiana ",
   "PINCODE": "388625",
   "TALUKA": "TARAPUR",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gorad ",
   "PINCODE": "388180",
   "TALUKA": "TARAPUR",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hadeva ",
   "PINCODE": "388180",
   "TALUKA": "TARAPUR",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Indranaj ",
   "PINCODE": "388180",
   "TALUKA": "TARAPUR",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Isarvada ",
   "PINCODE": "388180",
   "TALUKA": "TARAPUR",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jichka ",
   "PINCODE": "388180",
   "TALUKA": "TARAPUR",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kanavada ",
   "PINCODE": "388180",
   "TALUKA": "TARAPUR",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kasbara ",
   "PINCODE": "388180",
   "TALUKA": "TARAPUR",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khaksar ",
   "PINCODE": "388625",
   "TALUKA": "TARAPUR",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khanpur ",
   "PINCODE": "388180",
   "TALUKA": "TARAPUR",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Laxmipura ",
   "PINCODE": "388620",
   "TALUKA": "TARAPUR",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mahiyari ",
   "PINCODE": "388180",
   "TALUKA": "TARAPUR",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Milarampura ",
   "PINCODE": "388180",
   "TALUKA": "TARAPUR",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mobha ",
   "PINCODE": "388170",
   "TALUKA": "TARAPUR",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mobha ",
   "PINCODE": "388170",
   "TALUKA": "TARAPUR",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moraj ",
   "PINCODE": "388180",
   "TALUKA": "TARAPUR",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pachegam ",
   "PINCODE": "388625",
   "TALUKA": "TARAPUR",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Padra ",
   "PINCODE": "388180",
   "TALUKA": "TARAPUR",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pariej ",
   "PINCODE": "388180",
   "TALUKA": "TARAPUR",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tarapur ",
   "PINCODE": "388180",
   "TALUKA": "TARAPUR",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Untvada ",
   "PINCODE": "388170",
   "TALUKA": "TARAPUR",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Varsada ",
   "PINCODE": "388180",
   "TALUKA": "TARAPUR",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mitli ",
   "PINCODE": "388180",
   "TALUKA": "TARAPURA=",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ahima ",
   "PINCODE": "388210",
   "TALUKA": "UMRETH",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ashipura ",
   "PINCODE": "388205",
   "TALUKA": "UMRETH",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Badapura ",
   "PINCODE": "388205",
   "TALUKA": "UMRETH",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bajipura ",
   "PINCODE": "388210",
   "TALUKA": "UMRETH",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bechri ",
   "PINCODE": "388220",
   "TALUKA": "UMRETH",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bharoda ",
   "PINCODE": "388210",
   "TALUKA": "UMRETH",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhatpura ",
   "PINCODE": "388220",
   "TALUKA": "UMRETH",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dagjipura ",
   "PINCODE": "388205",
   "TALUKA": "UMRETH",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dholi ",
   "PINCODE": "388365",
   "TALUKA": "UMRETH",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghora ",
   "PINCODE": "388220",
   "TALUKA": "UMRETH",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hamidpura ",
   "PINCODE": "388220",
   "TALUKA": "UMRETH",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jakhala ",
   "PINCODE": "388205",
   "TALUKA": "UMRETH",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khankhanpur ",
   "PINCODE": "388220",
   "TALUKA": "UMRETH",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khankuva ",
   "PINCODE": "388205",
   "TALUKA": "UMRETH",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lingda ",
   "PINCODE": "388220",
   "TALUKA": "UMRETH",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panchvati   (Umreth) ",
   "PINCODE": "388220",
   "TALUKA": "UMRETH",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pansora ",
   "PINCODE": "388220",
   "TALUKA": "UMRETH",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pratappura ",
   "PINCODE": "388365",
   "TALUKA": "UMRETH",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ratanpura ",
   "PINCODE": "388220",
   "TALUKA": "UMRETH",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shili ",
   "PINCODE": "388210",
   "TALUKA": "UMRETH",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sundalpura ",
   "PINCODE": "388210",
   "TALUKA": "UMRETH",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sureli ",
   "PINCODE": "388210",
   "TALUKA": "UMRETH",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Thamna ",
   "PINCODE": "388215",
   "TALUKA": "UMRETH",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umreth ",
   "PINCODE": "388220",
   "TALUKA": "UMRETH",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khorvad ",
   "PINCODE": "388365",
   "TALUKA": "UNRETH",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Untkhari ",
   "PINCODE": "388205",
   "TALUKA": "UNRETH",
   "DISTRICT": "ANAND",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jaswant Gadh ",
   "PINCODE": "385120",
   "TALUKA": ".",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Virampur ",
   "PINCODE": "385001",
   "TALUKA": ".",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Balodhan ",
   "PINCODE": "385320",
   "TALUKA": "BHABHAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Barwala ",
   "PINCODE": "385320",
   "TALUKA": "BHABHAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhabhar ",
   "PINCODE": "385320",
   "TALUKA": "BHABHAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chatra ",
   "PINCODE": "385320",
   "TALUKA": "BHABHAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chembuva ",
   "PINCODE": "385320",
   "TALUKA": "BHABHAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhrechana ",
   "PINCODE": "385320",
   "TALUKA": "BHABHAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Eta ",
   "PINCODE": "385320",
   "TALUKA": "BHABHAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Garambadi ",
   "PINCODE": "385320",
   "TALUKA": "BHABHAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jasanwada ",
   "PINCODE": "385320",
   "TALUKA": "BHABHAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Katav ",
   "PINCODE": "385320",
   "TALUKA": "BHABHAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kuvala ",
   "PINCODE": "385320",
   "TALUKA": "BHABHAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Madhpura ",
   "PINCODE": "385320",
   "TALUKA": "BHABHAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mitha ",
   "PINCODE": "385320",
   "TALUKA": "BHABHAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Morwada ",
   "PINCODE": "385320",
   "TALUKA": "BHABHAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Radka ",
   "PINCODE": "385320",
   "TALUKA": "BHABHAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Runi ",
   "PINCODE": "385320",
   "TALUKA": "BHABHAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ruvel ",
   "PINCODE": "385320",
   "TALUKA": "BHABHAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Soneth ",
   "PINCODE": "385320",
   "TALUKA": "BHABHAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Suthar Nesdi ",
   "PINCODE": "385320",
   "TALUKA": "BHABHAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tanvad ",
   "PINCODE": "385320",
   "TALUKA": "BHABHAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Terwada ",
   "PINCODE": "385320",
   "TALUKA": "BHABHAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Uchosan ",
   "PINCODE": "385320",
   "TALUKA": "BHABHAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ujjanwada ",
   "PINCODE": "385320",
   "TALUKA": "BHABHAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Undai ",
   "PINCODE": "385320",
   "TALUKA": "BHABHAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vajapur Juna ",
   "PINCODE": "385320",
   "TALUKA": "BHABHAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Varasada ",
   "PINCODE": "385320",
   "TALUKA": "BHABHAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambaji ",
   "PINCODE": "385110",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bamnoj ",
   "PINCODE": "385110",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhadli-kotha ",
   "PINCODE": "385505",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhakhari ",
   "PINCODE": "385120",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dalpura ",
   "PINCODE": "385120",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Danta Bhavangadh ",
   "PINCODE": "385120",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhagadia ",
   "PINCODE": "385110",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhanali ",
   "PINCODE": "385120",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gangva ",
   "PINCODE": "385120",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gorad ",
   "PINCODE": "385120",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hadad ",
   "PINCODE": "385110",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jamru ",
   "PINCODE": "385110",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jitpur ",
   "PINCODE": "385120",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jodhsar ",
   "PINCODE": "385110",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khandhor (U) ",
   "PINCODE": "385110",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Koteshwar ",
   "PINCODE": "385110",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kukadi ",
   "PINCODE": "385120",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kundel ",
   "PINCODE": "385120",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kuvarshi ",
   "PINCODE": "385120",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mankdi ",
   "PINCODE": "385120",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moria (N) ",
   "PINCODE": "385120",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Motasada ",
   "PINCODE": "385120",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mumanvas ",
   "PINCODE": "385120",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navavas ",
   "PINCODE": "385120",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panchha ",
   "PINCODE": "385110",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pethapur ",
   "PINCODE": "385120",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Punjpur ",
   "PINCODE": "385120",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rangpur ",
   "PINCODE": "385120",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ranpur ",
   "PINCODE": "385110",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sanali ",
   "PINCODE": "385110",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sandhosi ",
   "PINCODE": "385120",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sembal Pani ",
   "PINCODE": "385110",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasi ",
   "PINCODE": "385120",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vijlasan ",
   "PINCODE": "385120",
   "TALUKA": "DANTA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhakodar ",
   "PINCODE": "385505",
   "TALUKA": "DANTIWADA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhilachal ",
   "PINCODE": "385505",
   "TALUKA": "DANTIWADA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dantiwada ",
   "PINCODE": "385505",
   "TALUKA": "DANTIWADA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dantiwada Colony ",
   "PINCODE": "385505",
   "TALUKA": "DANTIWADA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jegol ",
   "PINCODE": "385505",
   "TALUKA": "DANTIWADA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Odhava ",
   "PINCODE": "385505",
   "TALUKA": "DANTIWADA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sardar Krishinagar ",
   "PINCODE": "385506",
   "TALUKA": "DANTIWADA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhesana ",
   "PINCODE": "385330",
   "TALUKA": "DEODAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chibhada ",
   "PINCODE": "385330",
   "TALUKA": "DEODAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Deodar ",
   "PINCODE": "385330",
   "TALUKA": "DEODAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhanakwada ",
   "PINCODE": "385330",
   "TALUKA": "DEODAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Duchakwada ",
   "PINCODE": "385330",
   "TALUKA": "DEODAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Forna ",
   "PINCODE": "385330",
   "TALUKA": "DEODAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Golvi ",
   "PINCODE": "385330",
   "TALUKA": "DEODAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jada ",
   "PINCODE": "385330",
   "TALUKA": "DEODAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jalodha ",
   "PINCODE": "385330",
   "TALUKA": "DEODAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jasali ",
   "PINCODE": "385330",
   "TALUKA": "DEODAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kotarwada ",
   "PINCODE": "385330",
   "TALUKA": "DEODAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ludra ",
   "PINCODE": "385330",
   "TALUKA": "DEODAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nokha ",
   "PINCODE": "385330",
   "TALUKA": "DEODAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Paldi ",
   "PINCODE": "385330",
   "TALUKA": "DEODAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Raiya ",
   "PINCODE": "385330",
   "TALUKA": "DEODAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ravel ",
   "PINCODE": "385330",
   "TALUKA": "DEODAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Soni ",
   "PINCODE": "385330",
   "TALUKA": "DEODAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Surana ",
   "PINCODE": "385330",
   "TALUKA": "DEODAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vakha ",
   "PINCODE": "385330",
   "TALUKA": "DEODAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vatam-juna ",
   "PINCODE": "385330",
   "TALUKA": "DEODAR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Alwada ",
   "PINCODE": "385545",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Anapur Chhota ",
   "PINCODE": "385545",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Arkhi ",
   "PINCODE": "385545",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bapla ",
   "PINCODE": "385545",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhadli (Jhat) ",
   "PINCODE": "385545",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhandotra ",
   "PINCODE": "385545",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhanjana ",
   "PINCODE": "385310",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhatib ",
   "PINCODE": "385310",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhatram ",
   "PINCODE": "385545",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhakha ",
   "PINCODE": "385310",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhanera ",
   "PINCODE": "385310",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhaniawada ",
   "PINCODE": "385545",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dharnodhar ",
   "PINCODE": "385310",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dugdol ",
   "PINCODE": "385310",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghana ",
   "PINCODE": "385310",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gundri ",
   "PINCODE": "385545",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jadi ",
   "PINCODE": "385310",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jadia ",
   "PINCODE": "385310",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jadiali ",
   "PINCODE": "385310",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jhat ",
   "PINCODE": "385545",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jiwana ",
   "PINCODE": "385310",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kherola ",
   "PINCODE": "385310",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khimat ",
   "PINCODE": "385545",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kuchawada ",
   "PINCODE": "385545",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kumar ",
   "PINCODE": "385545",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kuvarla ",
   "PINCODE": "385310",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lavara ",
   "PINCODE": "385310",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Malotra ",
   "PINCODE": "385310",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mandal ",
   "PINCODE": "385545",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Motimahudi ",
   "PINCODE": "385545",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nandla ",
   "PINCODE": "385310",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nani ",
   "PINCODE": "385310",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nenava ",
   "PINCODE": "385310",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panthawada ",
   "PINCODE": "385545",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pechhadal ",
   "PINCODE": "385310",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ramsan ",
   "PINCODE": "385310",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Raviya ",
   "PINCODE": "385310",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Runi ",
   "PINCODE": "385545",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Samarvada ",
   "PINCODE": "385310",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Saral ",
   "PINCODE": "385310",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sia ",
   "PINCODE": "385310",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Thavar ",
   "PINCODE": "385310",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vachhadal ",
   "PINCODE": "385545",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vachhol ",
   "PINCODE": "385545",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Valer ",
   "PINCODE": "385310",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vinchhivadi ",
   "PINCODE": "385310",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Viruna ",
   "PINCODE": "385545",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zenal ",
   "PINCODE": "385310",
   "TALUKA": "DHANERA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Agthala ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Asarada ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Baiwada ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Balodhar ",
   "PINCODE": "385530",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhachalva ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhadath ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhadramali ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhildi ",
   "PINCODE": "385530",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhoyan ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chalva ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chekra ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chhatrala ",
   "PINCODE": "385530",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhuva ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Disa Bazar ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Disa M.Y. Pedal ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Disa Mukhya Dak Ghar ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghada ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jetda ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jhabadia ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jherda ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Junadisa ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kansari ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kapra-mota ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Katarva ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khardosan ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khentva ",
   "PINCODE": "385530",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kotda ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kuda ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lakhani ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lavana ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lorwada ",
   "PINCODE": "385530",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lunpur ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mahadevia ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Malgadh ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mudetha ",
   "PINCODE": "385530",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nagfana ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nesada-juna ",
   "PINCODE": "385530",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Odhava (D) ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Peplu ",
   "PINCODE": "385530",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajpur (D) ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rampura (D) ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ranpur V-vas ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rantila ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rasana Mota ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Robas Moti ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Samau ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Saviyana ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Thervada ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tintoda ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Varnoda ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasana Vatam ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasna ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Velavapura ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vithodar ",
   "PINCODE": "385535",
   "TALUKA": "DISA",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kakar ",
   "PINCODE": "385550",
   "TALUKA": "KANKRAJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Manpur ",
   "PINCODE": "385550",
   "TALUKA": "KANKRAJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Padardi ",
   "PINCODE": "385550",
   "TALUKA": "KANKRAJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Aganwada ",
   "PINCODE": "385555",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhadrewadi ",
   "PINCODE": "385560",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhalgam ",
   "PINCODE": "385560",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bukoli ",
   "PINCODE": "385550",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Changa ",
   "PINCODE": "385555",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chekhala ",
   "PINCODE": "385550",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dungrasan ",
   "PINCODE": "385550",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Isarva ",
   "PINCODE": "385555",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jakhel ",
   "PINCODE": "385555",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kamboi ",
   "PINCODE": "385550",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kasara ",
   "PINCODE": "385555",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kharia ",
   "PINCODE": "385555",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khimana ",
   "PINCODE": "385550",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khoda ",
   "PINCODE": "385550",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khodla ",
   "PINCODE": "385550",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kunvarva ",
   "PINCODE": "385550",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Laxmipura ",
   "PINCODE": "385550",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mandla ",
   "PINCODE": "385560",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mota-jampur ",
   "PINCODE": "385555",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nathpura ",
   "PINCODE": "385555",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nekaria ",
   "PINCODE": "385560",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Padar ",
   "PINCODE": "385560",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Raner ",
   "PINCODE": "385550",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Raviyana ",
   "PINCODE": "385550",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sihori ",
   "PINCODE": "385550",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Siya ",
   "PINCODE": "385560",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tatiyana ",
   "PINCODE": "385560",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Thara ",
   "PINCODE": "385555",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Totana ",
   "PINCODE": "385560",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umbari ",
   "PINCODE": "385550",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Un ",
   "PINCODE": "385560",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vada ",
   "PINCODE": "385555",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Valpura ",
   "PINCODE": "385560",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zalmor ",
   "PINCODE": "385550",
   "TALUKA": "KANKREJ",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Antroli ",
   "PINCODE": "385010",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Badargadh ",
   "PINCODE": "385410",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhagal (J) ",
   "PINCODE": "385001",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhagal (P) ",
   "PINCODE": "385001",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhakharmoti ",
   "PINCODE": "385510",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhatamal-moti ",
   "PINCODE": "385010",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhutedi ",
   "PINCODE": "385010",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chadotar ",
   "PINCODE": "385001",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chandisar ",
   "PINCODE": "385510",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chitrasani ",
   "PINCODE": "385010",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dalwada ",
   "PINCODE": "385515",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dangia ",
   "PINCODE": "385510",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhandha ",
   "PINCODE": "385001",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhanpura ",
   "PINCODE": "385001",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gadh ",
   "PINCODE": "385515",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gathaman ",
   "PINCODE": "385001",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hasanpur ",
   "PINCODE": "385001",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hathidra ",
   "PINCODE": "385001",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hoda ",
   "PINCODE": "385001",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jagana ",
   "PINCODE": "385001",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jasleni ",
   "PINCODE": "385410",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kanodar ",
   "PINCODE": "385520",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karjoda ",
   "PINCODE": "385001",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khodla ",
   "PINCODE": "385510",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kumbhalmer ",
   "PINCODE": "385510",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kumbhasan ",
   "PINCODE": "385515",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kushkal ",
   "PINCODE": "385510",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lalawada ",
   "PINCODE": "385001",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lunva ",
   "PINCODE": "385001",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Madana (Dangia ) ",
   "PINCODE": "385510",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Madana ",
   "PINCODE": "385519",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Malan ",
   "PINCODE": "385001",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Malana ",
   "PINCODE": "385001",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moria  (P) ",
   "PINCODE": "385001",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mota ",
   "PINCODE": "385510",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Palanpur Delhigate ",
   "PINCODE": "385001",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Palanpur Ganjbazar ",
   "PINCODE": "385001",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Palanpur H.O",
   "PINCODE": "385001",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Palanpur Kamalpura ",
   "PINCODE": "385001",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Palanpur Kirtistambh ",
   "PINCODE": "385001",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Patosan ",
   "PINCODE": "385515",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ranavas ",
   "PINCODE": "385010",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ratanpur Lokniketan ",
   "PINCODE": "385001",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sadarpur ",
   "PINCODE": "385001",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Saghankshetra ",
   "PINCODE": "385010",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sagrosana ",
   "PINCODE": "385001",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Salla ",
   "PINCODE": "385515",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Samdhi ",
   "PINCODE": "385515",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sangra ",
   "PINCODE": "385001",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sasam ",
   "PINCODE": "385515",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadhana ",
   "PINCODE": "385001",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vagda ",
   "PINCODE": "385001",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vaghrol ",
   "PINCODE": "385510",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasan ",
   "PINCODE": "385001",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vedancha ",
   "PINCODE": "385510",
   "TALUKA": "PALANPUR",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Balundra ",
   "PINCODE": "385135",
   "TALUKA": "SHRI AMIRGADH",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dabhela ",
   "PINCODE": "385130",
   "TALUKA": "SHRI AMIRGADH",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Iqbalgadh ",
   "PINCODE": "385135",
   "TALUKA": "SHRI AMIRGADH",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jethi ",
   "PINCODE": "385135",
   "TALUKA": "SHRI AMIRGADH",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kapasia ",
   "PINCODE": "385135",
   "TALUKA": "SHRI AMIRGADH",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kidotar ",
   "PINCODE": "385130",
   "TALUKA": "SHRI AMIRGADH",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Manpuria ",
   "PINCODE": "385135",
   "TALUKA": "SHRI AMIRGADH",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sarotra ",
   "PINCODE": "385135",
   "TALUKA": "SHRI AMIRGADH",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shri Amirgadh ",
   "PINCODE": "385130",
   "TALUKA": "SHRI AMIRGADH",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dholia ",
   "PINCODE": "385135",
   "TALUKA": "SHRIAMIRGADH",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Asodar ",
   "PINCODE": "385565",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bevta ",
   "PINCODE": "385565",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhordu ",
   "PINCODE": "385565",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhorol ",
   "PINCODE": "385566",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Changda ",
   "PINCODE": "385565",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Charda ",
   "PINCODE": "385565",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chudmer ",
   "PINCODE": "385565",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chuva ",
   "PINCODE": "385566",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Daiyap ",
   "PINCODE": "385566",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhima ",
   "PINCODE": "385566",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dodgam ",
   "PINCODE": "385565",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dudhava ",
   "PINCODE": "385565",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Duva ",
   "PINCODE": "385310",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gadsisar ",
   "PINCODE": "385566",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghodasar ",
   "PINCODE": "385310",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Idhata ",
   "PINCODE": "385566",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jamda ",
   "PINCODE": "385565",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kamali ",
   "PINCODE": "385565",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karbun ",
   "PINCODE": "385566",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khengarpura ",
   "PINCODE": "385565",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khoda ",
   "PINCODE": "385565",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lalpur ",
   "PINCODE": "385565",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Luvana ",
   "PINCODE": "385565",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Madal ",
   "PINCODE": "385565",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Malupur ",
   "PINCODE": "385565",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Morthal ",
   "PINCODE": "385310",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mota Mesra ",
   "PINCODE": "385565",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moti Pavad ",
   "PINCODE": "385565",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Naroli ",
   "PINCODE": "385566",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Piluda ",
   "PINCODE": "385565",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rah ",
   "PINCODE": "385310",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rampura ",
   "PINCODE": "385566",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sanavia ",
   "PINCODE": "385565",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Savapura ",
   "PINCODE": "385566",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sherau ",
   "PINCODE": "385566",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tharad ",
   "PINCODE": "385565",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Undrana ",
   "PINCODE": "385565",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadgamda ",
   "PINCODE": "385565",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vaghasan ",
   "PINCODE": "385566",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Valadar ",
   "PINCODE": "385565",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vami ",
   "PINCODE": "385565",
   "TALUKA": "THARAD",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pasvadal ",
   "PINCODE": "385210",
   "TALUKA": "VADAGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Badarpura ",
   "PINCODE": "385520",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Basu ",
   "PINCODE": "385520",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bavalchudi ",
   "PINCODE": "385210",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhalgam ",
   "PINCODE": "385421",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Changa ",
   "PINCODE": "385520",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Changwada ",
   "PINCODE": "385520",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chhaniyana ",
   "PINCODE": "385410",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chhapi ",
   "PINCODE": "385210",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dalwana ",
   "PINCODE": "385421",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhota ",
   "PINCODE": "385421",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Edrana ",
   "PINCODE": "385210",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghodiyal ",
   "PINCODE": "385421",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gidasan ",
   "PINCODE": "385421",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gola ",
   "PINCODE": "385410",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jalotra ",
   "PINCODE": "385001",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kaleda ",
   "PINCODE": "385421",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kodram ",
   "PINCODE": "385421",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Magarwada ",
   "PINCODE": "385410",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mahi ",
   "PINCODE": "385210",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Majadar ",
   "PINCODE": "385210",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Manpura ",
   "PINCODE": "385210",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Memadpur ",
   "PINCODE": "385421",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Meta ",
   "PINCODE": "385520",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nandotra ",
   "PINCODE": "385421",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navisana ",
   "PINCODE": "385421",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panchada ",
   "PINCODE": "385421",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pepol ",
   "PINCODE": "385421",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pilucha ",
   "PINCODE": "385421",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pirojpura ",
   "PINCODE": "385210",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rupal ",
   "PINCODE": "385421",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Semodra ",
   "PINCODE": "385410",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sendhani ",
   "PINCODE": "385421",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sisrana ",
   "PINCODE": "385421",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Takarwada ",
   "PINCODE": "385520",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Teniwada ",
   "PINCODE": "385210",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Timbachudi ",
   "PINCODE": "385210",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadgam ",
   "PINCODE": "385410",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vesa ",
   "PINCODE": "385421",
   "TALUKA": "VADGAM",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Akoli ",
   "PINCODE": "385566",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Asara ",
   "PINCODE": "385575",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Baiyak ",
   "PINCODE": "385575",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Baluntri ",
   "PINCODE": "385575",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Benap ",
   "PINCODE": "385570",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhachali ",
   "PINCODE": "385575",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhakhari ",
   "PINCODE": "385566",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bharadva ",
   "PINCODE": "385570",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhatvar ",
   "PINCODE": "385575",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bukna ",
   "PINCODE": "385575",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chala ",
   "PINCODE": "385570",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dendava ",
   "PINCODE": "385575",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dethli ",
   "PINCODE": "385575",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dharadhara ",
   "PINCODE": "385575",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Golgam ",
   "PINCODE": "385575",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jelana ",
   "PINCODE": "385575",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kumbharkha ",
   "PINCODE": "385570",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kundaliya. ",
   "PINCODE": "385575",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Limbuni ",
   "PINCODE": "385570",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lodrani ",
   "PINCODE": "385575",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Madka ",
   "PINCODE": "385575",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mamana ",
   "PINCODE": "385570",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mavsari ",
   "PINCODE": "385566",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Morikha ",
   "PINCODE": "385575",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Padan ",
   "PINCODE": "385575",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Radosan ",
   "PINCODE": "385570",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sanval ",
   "PINCODE": "385566",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sapreda ",
   "PINCODE": "385566",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Suigam ",
   "PINCODE": "385570",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tadav ",
   "PINCODE": "385566",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tithgam ",
   "PINCODE": "385575",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasarda ",
   "PINCODE": "385575",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vav ",
   "PINCODE": "385575",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vavdi ",
   "PINCODE": "385575",
   "TALUKA": "VAV",
   "DISTRICT": "BANASKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amod ",
   "PINCODE": "392110",
   "TALUKA": "AMOD",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chaklad ",
   "PINCODE": "392035",
   "TALUKA": "AMOD",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Danda ",
   "PINCODE": "392230",
   "TALUKA": "AMOD",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dora ",
   "PINCODE": "392230",
   "TALUKA": "AMOD",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ikhar ",
   "PINCODE": "392230",
   "TALUKA": "AMOD",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karena ",
   "PINCODE": "392230",
   "TALUKA": "AMOD",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kobla ",
   "PINCODE": "392035",
   "TALUKA": "AMOD",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mangrol ",
   "PINCODE": "392230",
   "TALUKA": "AMOD",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Manjola ",
   "PINCODE": "392035",
   "TALUKA": "AMOD",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Miamatar ",
   "PINCODE": "392035",
   "TALUKA": "AMOD",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ochhan ",
   "PINCODE": "392230",
   "TALUKA": "AMOD",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sarbhan ",
   "PINCODE": "392035",
   "TALUKA": "AMOD",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sakkarpore ",
   "PINCODE": "393020",
   "TALUKA": "ANKLESHAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Alonj ",
   "PINCODE": "394115",
   "TALUKA": "ANKLESHWAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambheta ",
   "PINCODE": "393030",
   "TALUKA": "ANKLESHWAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Andada ",
   "PINCODE": "393010",
   "TALUKA": "ANKLESHWAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ankalva ",
   "PINCODE": "393030",
   "TALUKA": "ANKLESHWAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ankleshwar IE ",
   "PINCODE": "393002",
   "TALUKA": "ANKLESHWAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ankleshwar RS ",
   "PINCODE": "393001",
   "TALUKA": "ANKLESHWAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ankleshwar ",
   "PINCODE": "393001",
   "TALUKA": "ANKLESHWAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhadi ",
   "PINCODE": "394115",
   "TALUKA": "ANKLESHWAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhanturia ",
   "PINCODE": "393020",
   "TALUKA": "ANKLESHWAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghodadra ",
   "PINCODE": "394115",
   "TALUKA": "ANKLESHWAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Goya Bazar ",
   "PINCODE": "393001",
   "TALUKA": "ANKLESHWAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hajat ",
   "PINCODE": "393020",
   "TALUKA": "ANKLESHWAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kharod ",
   "PINCODE": "394115",
   "TALUKA": "ANKLESHWAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Matied ",
   "PINCODE": "393020",
   "TALUKA": "ANKLESHWAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nangal ",
   "PINCODE": "393020",
   "TALUKA": "ANKLESHWAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "O.N.G.C. Colony ",
   "PINCODE": "393010",
   "TALUKA": "ANKLESHWAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panoli I.E. ",
   "PINCODE": "394116",
   "TALUKA": "ANKLESHWAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panoli ",
   "PINCODE": "394115",
   "TALUKA": "ANKLESHWAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pardi Idris ",
   "PINCODE": "394115",
   "TALUKA": "ANKLESHWAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Piludra ",
   "PINCODE": "393020",
   "TALUKA": "ANKLESHWAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pungam ",
   "PINCODE": "393020",
   "TALUKA": "ANKLESHWAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ravidra ",
   "PINCODE": "394115",
   "TALUKA": "ANKLESHWAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sajod ",
   "PINCODE": "393020",
   "TALUKA": "ANKLESHWAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Samor ",
   "PINCODE": "393010",
   "TALUKA": "ANKLESHWAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sanjali ",
   "PINCODE": "394115",
   "TALUKA": "ANKLESHWAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kansia ",
   "PINCODE": "393010",
   "TALUKA": "ANKLWSHWAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bahruch City ",
   "PINCODE": "392001",
   "TALUKA": "BAHRUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Adol ",
   "PINCODE": "392240",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Angareshwar ",
   "PINCODE": "392030",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Argama ",
   "PINCODE": "392012",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bahruch R.S ",
   "PINCODE": "392001",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhadbhut ",
   "PINCODE": "392012",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bharthana ",
   "PINCODE": "392210",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bharuch H.O",
   "PINCODE": "392001",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhersam ",
   "PINCODE": "392012",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dabhali ",
   "PINCODE": "392210",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dashan ",
   "PINCODE": "392012",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dayadra ",
   "PINCODE": "392020",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dehgam ",
   "PINCODE": "392012",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Derol ",
   "PINCODE": "392020",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gayatri Nagar ",
   "PINCODE": "392001",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Haldar ",
   "PINCODE": "392210",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Haldarva ",
   "PINCODE": "392220",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Haldarva ",
   "PINCODE": "392011",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hingalla ",
   "PINCODE": "392210",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hinglot ",
   "PINCODE": "392012",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Janor ",
   "PINCODE": "392210",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jhangar ",
   "PINCODE": "392210",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "K.P.Bazar ",
   "PINCODE": "392001",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kahan ",
   "PINCODE": "392240",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kamboli ",
   "PINCODE": "392220",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kantharia ",
   "PINCODE": "392001",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kantharia ",
   "PINCODE": "392162",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karjan ",
   "PINCODE": "392210",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karmad ",
   "PINCODE": "392160",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kasad ",
   "PINCODE": "392020",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kavitha ",
   "PINCODE": "392210",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kelod ",
   "PINCODE": "392020",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kishnad ",
   "PINCODE": "392220",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Koliad ",
   "PINCODE": "392220",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kothi ",
   "PINCODE": "392020",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kothi Vantarsa ",
   "PINCODE": "392220",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kurla ",
   "PINCODE": "392160",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kuvadar ",
   "PINCODE": "392210",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "L.B.Chakla ",
   "PINCODE": "392001",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Luvara ",
   "PINCODE": "392210",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mahudhala ",
   "PINCODE": "392020",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Maktampur ",
   "PINCODE": "392012",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mangleshwar ",
   "PINCODE": "392030",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Manubar ",
   "PINCODE": "392161",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Matroj ",
   "PINCODE": "392220",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mesrad ",
   "PINCODE": "392220",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nabipur ",
   "PINCODE": "392210",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nandeal ",
   "PINCODE": "392015",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Narmada Nagar ",
   "PINCODE": "392015",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navetha ",
   "PINCODE": "392012",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nikora ",
   "PINCODE": "392001",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nikora ",
   "PINCODE": "392031",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pachhiapura ",
   "PINCODE": "392220",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Paguthan ",
   "PINCODE": "392015",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Palej ",
   "PINCODE": "392220",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panch Fanas ",
   "PINCODE": "392001",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pariej ",
   "PINCODE": "392001",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pariej ",
   "PINCODE": "392021",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Parkhet ",
   "PINCODE": "392020",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pipaliya ",
   "PINCODE": "392020",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rahad ",
   "PINCODE": "392012",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Saladra ",
   "PINCODE": "392012",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Samlod ",
   "PINCODE": "392210",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sansrod ",
   "PINCODE": "392220",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Saring ",
   "PINCODE": "392220",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Segva ",
   "PINCODE": "392210",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shahpur ",
   "PINCODE": "392210",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sherpura ",
   "PINCODE": "392015",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shuklatirth ",
   "PINCODE": "392030",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Simalia ",
   "PINCODE": "392220",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Simartha ",
   "PINCODE": "392220",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sindhot ",
   "PINCODE": "392210",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sindhvai ",
   "PINCODE": "392001",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sitpon ",
   "PINCODE": "392210",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tankaria ",
   "PINCODE": "392240",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tavra ",
   "PINCODE": "392011",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tham ",
   "PINCODE": "392020",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tralsa ",
   "PINCODE": "392020",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umraj ",
   "PINCODE": "392015",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Urja Nagar ",
   "PINCODE": "392215",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadadla ",
   "PINCODE": "392015",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vahalu ",
   "PINCODE": "392020",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vansi ",
   "PINCODE": "392160",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Varedia ",
   "PINCODE": "392210",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vilayat ",
   "PINCODE": "392012",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vora Samni ",
   "PINCODE": "392012",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zadeshwar ",
   "PINCODE": "392011",
   "TALUKA": "BHARUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amleshwar ",
   "PINCODE": "392012",
   "TALUKA": "BHRUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhuva ",
   "PINCODE": "392012",
   "TALUKA": "BHRUCH",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambawadi ",
   "PINCODE": "393041",
   "TALUKA": "DEDIAPADA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dediapada ",
   "PINCODE": "393040",
   "TALUKA": "DEDIAPADA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Asarma ",
   "PINCODE": "394810",
   "TALUKA": "HANSOT",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Asta ",
   "PINCODE": "393030",
   "TALUKA": "HANSOT",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Badodara ",
   "PINCODE": "393030",
   "TALUKA": "HANSOT",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Balota ",
   "PINCODE": "394810",
   "TALUKA": "HANSOT",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhamrad ",
   "PINCODE": "394810",
   "TALUKA": "HANSOT",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Digas ",
   "PINCODE": "393030",
   "TALUKA": "HANSOT",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hansot ",
   "PINCODE": "393030",
   "TALUKA": "HANSOT",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ilav ",
   "PINCODE": "394810",
   "TALUKA": "HANSOT",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kalam ",
   "PINCODE": "393030",
   "TALUKA": "HANSOT",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kantiajal ",
   "PINCODE": "393030",
   "TALUKA": "HANSOT",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Katpor ",
   "PINCODE": "393030",
   "TALUKA": "HANSOT",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kudadra ",
   "PINCODE": "393030",
   "TALUKA": "HANSOT",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Malanpur ",
   "PINCODE": "393030",
   "TALUKA": "HANSOT",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Obha ",
   "PINCODE": "394810",
   "TALUKA": "HANSOT",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Parvat ",
   "PINCODE": "394810",
   "TALUKA": "HANSOT",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Raima ",
   "PINCODE": "393030",
   "TALUKA": "HANSOT",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sayan ",
   "PINCODE": "393030",
   "TALUKA": "HANSOT",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shera ",
   "PINCODE": "393030",
   "TALUKA": "HANSOT",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sisodra ",
   "PINCODE": "394810",
   "TALUKA": "HANSOT",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sunevkalla ",
   "PINCODE": "394810",
   "TALUKA": "HANSOT",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vaghvan ",
   "PINCODE": "393030",
   "TALUKA": "HANSOT",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Valner ",
   "PINCODE": "393030",
   "TALUKA": "HANSOT",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vamleshwar ",
   "PINCODE": "393030",
   "TALUKA": "HANSOT",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Madafar ",
   "PINCODE": "392040",
   "TALUKA": "JAMBSUAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Samoj ",
   "PINCODE": "392180",
   "TALUKA": "JAMBSUAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amanpur ",
   "PINCODE": "392150",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ankhi ",
   "PINCODE": "392150",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhadkodra ",
   "PINCODE": "392155",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhodar ",
   "PINCODE": "392150",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bojadra ",
   "PINCODE": "392150",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chhidra ",
   "PINCODE": "392155",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dabha ",
   "PINCODE": "392150",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dehgam ",
   "PINCODE": "392170",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Devla ",
   "PINCODE": "392040",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dolia ",
   "PINCODE": "392150",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gajera ",
   "PINCODE": "391810",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Islampur ",
   "PINCODE": "392040",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jambusar Bazar ",
   "PINCODE": "392150",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jambusar ",
   "PINCODE": "392150",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jantran ",
   "PINCODE": "392155",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kahanva ",
   "PINCODE": "391810",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kalak ",
   "PINCODE": "392150",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kaliari ",
   "PINCODE": "392155",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kangam ",
   "PINCODE": "392170",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kareli ",
   "PINCODE": "391810",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karmad ",
   "PINCODE": "392150",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kava ",
   "PINCODE": "392150",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kavi ",
   "PINCODE": "392170",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kavli ",
   "PINCODE": "392180",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khanpurdeh ",
   "PINCODE": "392150",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kimoj ",
   "PINCODE": "392170",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kora ",
   "PINCODE": "392155",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Magnad ",
   "PINCODE": "392150",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Malpur ",
   "PINCODE": "392155",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nada ",
   "PINCODE": "392040",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nahar ",
   "PINCODE": "392170",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nobar ",
   "PINCODE": "392150",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nodhna ",
   "PINCODE": "392150",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pipludra ",
   "PINCODE": "391810",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Runad ",
   "PINCODE": "392170",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sambha ",
   "PINCODE": "392155",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sarod ",
   "PINCODE": "392180",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sigam ",
   "PINCODE": "392170",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tankari ",
   "PINCODE": "392040",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tundaj ",
   "PINCODE": "392150",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Uber ",
   "PINCODE": "392150",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Uchhad ",
   "PINCODE": "392150",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umra ",
   "PINCODE": "392150",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadadala ",
   "PINCODE": "392155",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vahelam ",
   "PINCODE": "392150",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Valvi ",
   "PINCODE": "392150",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vedach ",
   "PINCODE": "391810",
   "TALUKA": "JAMBUSAR",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambos ",
   "PINCODE": "393110",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Anadhara ",
   "PINCODE": "393110",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Avidha ",
   "PINCODE": "393017",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bamalla ",
   "PINCODE": "393120",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dadheda ",
   "PINCODE": "393110",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dharoli ",
   "PINCODE": "393110",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Goratia ",
   "PINCODE": "393115",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gundecha ",
   "PINCODE": "393110",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Haripura ",
   "PINCODE": "393120",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jarsad ",
   "PINCODE": "393115",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jespor ",
   "PINCODE": "393115",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jhagadia ",
   "PINCODE": "393110",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kadvali ",
   "PINCODE": "393115",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Limodra ",
   "PINCODE": "393110",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mortalav ",
   "PINCODE": "393110",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mota Sorva ",
   "PINCODE": "393115",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Motamalpur ",
   "PINCODE": "393110",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navagamvborjai ",
   "PINCODE": "393110",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Padal ",
   "PINCODE": "393110",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Padvania ",
   "PINCODE": "393110",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pipadhara ",
   "PINCODE": "393115",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Raisingpura ",
   "PINCODE": "393120",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajpardi ",
   "PINCODE": "393115",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ranipura ",
   "PINCODE": "393110",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Razalwada ",
   "PINCODE": "393115",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sanjali ",
   "PINCODE": "393120",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sarsa ",
   "PINCODE": "393115",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sarsad ",
   "PINCODE": "393120",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Simadhra ",
   "PINCODE": "393115",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Siyali ",
   "PINCODE": "393110",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Talodra ",
   "PINCODE": "393110",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Uchedia ",
   "PINCODE": "393110",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umadhra ",
   "PINCODE": "393115",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umalla ",
   "PINCODE": "393120",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umarva ",
   "PINCODE": "393120",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadkhunta ",
   "PINCODE": "393115",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vanakpore ",
   "PINCODE": "393115",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vankal ",
   "PINCODE": "393115",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasna ",
   "PINCODE": "393110",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Velugam ",
   "PINCODE": "393120",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Wali ",
   "PINCODE": "393120",
   "TALUKA": "JHAGADIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Asha ",
   "PINCODE": "393120",
   "TALUKA": "JHAGAIDA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Fitchwada ",
   "PINCODE": "393120",
   "TALUKA": "JHAGAIDA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Indore ",
   "PINCODE": "393120",
   "TALUKA": "JHAGAIDA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jamboi ",
   "PINCODE": "393120",
   "TALUKA": "JHAGAIDA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kapat ",
   "PINCODE": "393120",
   "TALUKA": "JHAGAIDA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panetha ",
   "PINCODE": "393120",
   "TALUKA": "JHAGAIDA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bharan ",
   "PINCODE": "394125",
   "TALUKA": "M.M.MANGROL",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Boridra ",
   "PINCODE": "394125",
   "TALUKA": "M.M.MANGROL",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gora Colony ",
   "PINCODE": "393155",
   "TALUKA": "NANDOD",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kharach ",
   "PINCODE": "394120",
   "TALUKA": "OLPAD",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panjroli ",
   "PINCODE": "394120",
   "TALUKA": "OLPAD",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambagam ",
   "PINCODE": "393125",
   "TALUKA": "SABGARA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Barkatura ",
   "PINCODE": "393125",
   "TALUKA": "SAGBARA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhavliver ",
   "PINCODE": "393125",
   "TALUKA": "SAGBARA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jaoli ",
   "PINCODE": "393125",
   "TALUKA": "SAGBARA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kherpada ",
   "PINCODE": "393125",
   "TALUKA": "SAGBARA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kolvan ",
   "PINCODE": "393125",
   "TALUKA": "SAGBARA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Langdi ",
   "PINCODE": "393125",
   "TALUKA": "SAGBARA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nevdiamba ",
   "PINCODE": "393125",
   "TALUKA": "SAGBARA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Palaswada ",
   "PINCODE": "393125",
   "TALUKA": "SAGBARA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajnivad ",
   "PINCODE": "393125",
   "TALUKA": "SAGBARA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sagbara ",
   "PINCODE": "393050",
   "TALUKA": "SAGBARA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Selamba ",
   "PINCODE": "393125",
   "TALUKA": "SAGBARA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Akod ",
   "PINCODE": "392110",
   "TALUKA": "VAGARA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghamnad ",
   "PINCODE": "392015",
   "TALUKA": "VAGARA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khojbal ",
   "PINCODE": "392110",
   "TALUKA": "VAGARA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambheta ",
   "PINCODE": "392110",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Anor ",
   "PINCODE": "392015",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Atali ",
   "PINCODE": "392110",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chancvel ",
   "PINCODE": "392140",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dahej ",
   "PINCODE": "392110",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dungari ",
   "PINCODE": "393135",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Eksal ",
   "PINCODE": "392110",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Galenda ",
   "PINCODE": "392110",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gandhar ",
   "PINCODE": "392140",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Goladra ",
   "PINCODE": "392165",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Janiadra ",
   "PINCODE": "392165",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kadodara ",
   "PINCODE": "392165",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kalam ",
   "PINCODE": "392140",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karela ",
   "PINCODE": "392015",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kervada ",
   "PINCODE": "392015",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Keshlu ",
   "PINCODE": "392015",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Keshwan ",
   "PINCODE": "392140",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kolavana ",
   "PINCODE": "392140",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kothia ",
   "PINCODE": "392140",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kurchan ",
   "PINCODE": "392015",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lakhigam ",
   "PINCODE": "392110",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Limdi ",
   "PINCODE": "392165",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Manad ",
   "PINCODE": "392110",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mosam ",
   "PINCODE": "392140",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Muler ",
   "PINCODE": "392140",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nandida ",
   "PINCODE": "392110",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Narnavi ",
   "PINCODE": "392165",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ochhan ",
   "PINCODE": "392140",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ora ",
   "PINCODE": "392140",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Padaria ",
   "PINCODE": "392015",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pahaj ",
   "PINCODE": "392140",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pakhajan ",
   "PINCODE": "392165",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Paniadra ",
   "PINCODE": "392165",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pipalia ",
   "PINCODE": "392165",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rahiad ",
   "PINCODE": "392110",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Roza Tankaria ",
   "PINCODE": "392140",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Samni ",
   "PINCODE": "392015",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Saran ",
   "PINCODE": "392140",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Saykha ",
   "PINCODE": "392140",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sutrel ",
   "PINCODE": "392140",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tanchha ",
   "PINCODE": "392015",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Trankal ",
   "PINCODE": "392140",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadadla ",
   "PINCODE": "392110",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vagra ",
   "PINCODE": "392140",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vahial ",
   "PINCODE": "392140",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasti Khandali ",
   "PINCODE": "392140",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vegni ",
   "PINCODE": "392110",
   "TALUKA": "VAGRA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Almawadi ",
   "PINCODE": "393130",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Anjoli ",
   "PINCODE": "393130",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Arethi ",
   "PINCODE": "393130",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Atkhol ",
   "PINCODE": "393130",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Babda ",
   "PINCODE": "393130",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Baladva ",
   "PINCODE": "393130",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhamadia ",
   "PINCODE": "393125",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bharadia ",
   "PINCODE": "393135",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhenskhetar ",
   "PINCODE": "393135",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhilod ",
   "PINCODE": "393135",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bilothi ",
   "PINCODE": "393130",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chandravan ",
   "PINCODE": "393130",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chasvad ",
   "PINCODE": "393130",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chikhli ",
   "PINCODE": "393135",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dattanagar ",
   "PINCODE": "393130",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dehali ",
   "PINCODE": "393125",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Desad ",
   "PINCODE": "393135",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dholgam ",
   "PINCODE": "393135",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dolatpur ",
   "PINCODE": "393135",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gundia ",
   "PINCODE": "393125",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Itakla ",
   "PINCODE": "393125",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jabugam ",
   "PINCODE": "393125",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kabirgam ",
   "PINCODE": "393135",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kamalia ",
   "PINCODE": "393135",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kambodia ",
   "PINCODE": "393130",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kantipada ",
   "PINCODE": "393130",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kara ",
   "PINCODE": "393135",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kavachia ",
   "PINCODE": "393130",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kelvikuva ",
   "PINCODE": "393130",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khardipada ",
   "PINCODE": "393130",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kharetha ",
   "PINCODE": "393130",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Koyli Mandvi ",
   "PINCODE": "393130",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Limet ",
   "PINCODE": "393135",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Luna ",
   "PINCODE": "393135",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mandala ",
   "PINCODE": "393130",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mauza ",
   "PINCODE": "393130",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mela ",
   "PINCODE": "393135",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mokhdi ",
   "PINCODE": "393125",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moriana ",
   "PINCODE": "393130",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mota Jambuda ",
   "PINCODE": "393130",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Naldhari ",
   "PINCODE": "393135",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Netrang ",
   "PINCODE": "393130",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panuda ",
   "PINCODE": "393130",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pather ",
   "PINCODE": "393135",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajgadh ",
   "PINCODE": "393135",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajpara ",
   "PINCODE": "393125",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sabaria ",
   "PINCODE": "393125",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sevad ",
   "PINCODE": "393135",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Siludi ",
   "PINCODE": "393135",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sodgam ",
   "PINCODE": "393135",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Thava ",
   "PINCODE": "393130",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tuna ",
   "PINCODE": "393125",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umargam ",
   "PINCODE": "393135",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadfalia ",
   "PINCODE": "393125",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Valia ",
   "PINCODE": "393135",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zak ",
   "PINCODE": "393130",
   "TALUKA": "VALIA",
   "DISTRICT": "BHARUCH",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Adhewada ",
   "PINCODE": "364002",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Akwada ",
   "PINCODE": "364002",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Awaniya ",
   "PINCODE": "364002",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhandariya ",
   "PINCODE": "364050",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhavnagar Anandnagar ",
   "PINCODE": "364005",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhavnagar BPTI ",
   "PINCODE": "364002",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhavnagar Chavdigate ",
   "PINCODE": "364001",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhavnagar Chitra ",
   "PINCODE": "364004",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhavnagar Collectorate ",
   "PINCODE": "364001",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhavnagar Gogha Circle ",
   "PINCODE": "364001",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhavnagar H.O",
   "PINCODE": "364001",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhavnagar K K Road ",
   "PINCODE": "364001",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhavnagar K Nagar ",
   "PINCODE": "364001",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhavnagar Khargate ",
   "PINCODE": "364001",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhavnagar Kumbharwada ",
   "PINCODE": "364006",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhavnagar M K Road ",
   "PINCODE": "364001",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhavnagar Nirmalnagar ",
   "PINCODE": "364001",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhavnagar Para ",
   "PINCODE": "364003",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhavnagar Station Road ",
   "PINCODE": "364006",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhavnagar Takhteshwar ",
   "PINCODE": "364002",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhavnagar Vora Bazar ",
   "PINCODE": "364001",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhavnagar Wadva ",
   "PINCODE": "364001",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhikhda ",
   "PINCODE": "364060",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhojpara ",
   "PINCODE": "364060",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Budhel ",
   "PINCODE": "364002",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Concret Jetty ",
   "PINCODE": "364005",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Fariyadka ",
   "PINCODE": "364060",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gadhesar ",
   "PINCODE": "364130",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hathab ",
   "PINCODE": "364070",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hoidad ",
   "PINCODE": "364070",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ingorala ",
   "PINCODE": "364730",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kamlej ",
   "PINCODE": "364060",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kardej ",
   "PINCODE": "364060",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khadsaliya ",
   "PINCODE": "364070",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Koliyak ",
   "PINCODE": "364070",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lakhanka ",
   "PINCODE": "364070",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Malanka ",
   "PINCODE": "364002",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Malpara ",
   "PINCODE": "364002",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nari ",
   "PINCODE": "364004",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nava Ratanpar ",
   "PINCODE": "364070",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sidsar ",
   "PINCODE": "364060",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tajpar ",
   "PINCODE": "364710",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tana ",
   "PINCODE": "364260",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Valukad ",
   "PINCODE": "364060",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vartej ",
   "PINCODE": "364060",
   "TALUKA": "Bhavnagar",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bambhan ",
   "PINCODE": "364710",
   "TALUKA": "Botad",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhadla Nana ",
   "PINCODE": "364720",
   "TALUKA": "Botad",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhadravadi ",
   "PINCODE": "364710",
   "TALUKA": "Botad",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhimdad ",
   "PINCODE": "364710",
   "TALUKA": "Botad",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bodi ",
   "PINCODE": "364720",
   "TALUKA": "Botad",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Botad ",
   "PINCODE": "364710",
   "TALUKA": "Botad",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Botad Statoin Road ",
   "PINCODE": "364710",
   "TALUKA": "Botad",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Botad Town ",
   "PINCODE": "364710",
   "TALUKA": "Botad",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhakania ",
   "PINCODE": "364710",
   "TALUKA": "Botad",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gadhadia ",
   "PINCODE": "364720",
   "TALUKA": "Botad",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Haddad ",
   "PINCODE": "364710",
   "TALUKA": "Botad",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kariyani ",
   "PINCODE": "364710",
   "TALUKA": "Botad",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kumbhara ",
   "PINCODE": "364720",
   "TALUKA": "Botad",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lathidad ",
   "PINCODE": "364710",
   "TALUKA": "Botad",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nagalpar ",
   "PINCODE": "364710",
   "TALUKA": "Botad",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ningala ",
   "PINCODE": "364760",
   "TALUKA": "Botad",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Paliyad ",
   "PINCODE": "364720",
   "TALUKA": "Botad",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rangpur ",
   "PINCODE": "364710",
   "TALUKA": "Botad",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Salaiya ",
   "PINCODE": "364710",
   "TALUKA": "Botad",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Samadhiyala No. 1 ",
   "PINCODE": "364710",
   "TALUKA": "Botad",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Samadhiyala No. 2 ",
   "PINCODE": "364710",
   "TALUKA": "Botad",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sangvadar ",
   "PINCODE": "364710",
   "TALUKA": "Botad",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sarva ",
   "PINCODE": "364720",
   "TALUKA": "Botad",
   "DISTRICT": "BHAVNAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bandhvad ",
   "PINCODE": "385340",
   "TALUKA": "RADHANPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhilot ",
   "PINCODE": "385340",
   "TALUKA": "RADHANPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chalvada ",
   "PINCODE": "385340",
   "TALUKA": "RADHANPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "D R.S. ",
   "PINCODE": "385340",
   "TALUKA": "RADHANPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dharvadi ",
   "PINCODE": "385340",
   "TALUKA": "RADHANPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dholakda ",
   "PINCODE": "385360",
   "TALUKA": "RADHANPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gotarka ",
   "PINCODE": "385360",
   "TALUKA": "RADHANPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Javantri ",
   "PINCODE": "385340",
   "TALUKA": "RADHANPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kamalpur (D) ",
   "PINCODE": "385340",
   "TALUKA": "RADHANPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kamalpur (S) ",
   "PINCODE": "385340",
   "TALUKA": "RADHANPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lotia ",
   "PINCODE": "385340",
   "TALUKA": "RADHANPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Masali ",
   "PINCODE": "385340",
   "TALUKA": "RADHANPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Memdavad ",
   "PINCODE": "385340",
   "TALUKA": "RADHANPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moti Pipli ",
   "PINCODE": "385340",
   "TALUKA": "RADHANPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nani Pipli ",
   "PINCODE": "385340",
   "TALUKA": "RADHANPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nanpura ",
   "PINCODE": "385340",
   "TALUKA": "RADHANPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Radhanpur Rajgadhi ",
   "PINCODE": "385340",
   "TALUKA": "RADHANPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Radhanpur Rly Colony ",
   "PINCODE": "385340",
   "TALUKA": "RADHANPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Radhanpur ",
   "PINCODE": "385340",
   "TALUKA": "RADHANPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Santhli ",
   "PINCODE": "385340",
   "TALUKA": "RADHANPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Satun ",
   "PINCODE": "385340",
   "TALUKA": "RADHANPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sinad ",
   "PINCODE": "385340",
   "TALUKA": "RADHANPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Subapura ",
   "PINCODE": "385340",
   "TALUKA": "RADHANPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Adgam ",
   "PINCODE": "384245",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amrapuara ",
   "PINCODE": "384245",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Anvarpura ",
   "PINCODE": "384245",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Aritha ",
   "PINCODE": "384240",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Baspa ",
   "PINCODE": "384245",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhadrada ",
   "PINCODE": "384245",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bilia ",
   "PINCODE": "384240",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bolera ",
   "PINCODE": "384246",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chandur Moti ",
   "PINCODE": "384241",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chandur Nani ",
   "PINCODE": "384245",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dadar ",
   "PINCODE": "384245",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Daudpur ",
   "PINCODE": "384245",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhadhana ",
   "PINCODE": "384240",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhanora ",
   "PINCODE": "384246",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dudkha ",
   "PINCODE": "384245",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gajdinpura ",
   "PINCODE": "384245",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gochnath ",
   "PINCODE": "385340",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gujarwada ",
   "PINCODE": "384245",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jakhel ",
   "PINCODE": "385360",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jesda ",
   "PINCODE": "384241",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kanij ",
   "PINCODE": "384245",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khijdiyari ",
   "PINCODE": "384241",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kukrana ",
   "PINCODE": "384240",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kunvar ",
   "PINCODE": "384241",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kunvarad ",
   "PINCODE": "384241",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lolada ",
   "PINCODE": "384241",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Loteshwar ",
   "PINCODE": "384241",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mandvi ",
   "PINCODE": "384245",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Matrota ",
   "PINCODE": "384240",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Memna ",
   "PINCODE": "384241",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mota Joravarpura ",
   "PINCODE": "384245",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mujpur ",
   "PINCODE": "384241",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nayka ",
   "PINCODE": "384245",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panchasar ",
   "PINCODE": "384246",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rafu ",
   "PINCODE": "384245",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ranod ",
   "PINCODE": "384241",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ravad ",
   "PINCODE": "384240",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sami ",
   "PINCODE": "384245",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Samsherpura ",
   "PINCODE": "384245",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sankheshwar ",
   "PINCODE": "384246",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sipur ",
   "PINCODE": "384241",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Taranagar ",
   "PINCODE": "384241",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tarora ",
   "PINCODE": "384240",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tuvad ",
   "PINCODE": "384241",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vaghel ",
   "PINCODE": "384240",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vagosan ",
   "PINCODE": "384240",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Varana ",
   "PINCODE": "384245",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ved ",
   "PINCODE": "384245",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zilvana ",
   "PINCODE": "384245",
   "TALUKA": "SAMI",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Abiyana ",
   "PINCODE": "385360",
   "TALUKA": "SANTALPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Babra ",
   "PINCODE": "385360",
   "TALUKA": "SANTALPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bamroli ",
   "PINCODE": "385360",
   "TALUKA": "SANTALPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Charanka ",
   "PINCODE": "385350",
   "TALUKA": "SANTALPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dantisana ",
   "PINCODE": "384246",
   "TALUKA": "SANTALPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Detrana ",
   "PINCODE": "385350",
   "TALUKA": "SANTALPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhokavada ",
   "PINCODE": "385350",
   "TALUKA": "SANTALPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gadha ",
   "PINCODE": "385360",
   "TALUKA": "SANTALPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gadsai ",
   "PINCODE": "385360",
   "TALUKA": "SANTALPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ganjisar ",
   "PINCODE": "385340",
   "TALUKA": "SANTALPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Garambadi ",
   "PINCODE": "385350",
   "TALUKA": "SANTALPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gokhantar ",
   "PINCODE": "385360",
   "TALUKA": "SANTALPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jakhotra ",
   "PINCODE": "385350",
   "TALUKA": "SANTALPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jarusha ",
   "PINCODE": "385360",
   "TALUKA": "SANTALPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Koliwada ",
   "PINCODE": "385340",
   "TALUKA": "SANTALPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Korda ",
   "PINCODE": "385360",
   "TALUKA": "SANTALPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lodra ",
   "PINCODE": "385340",
   "TALUKA": "SANTALPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Madhutra ",
   "PINCODE": "385350",
   "TALUKA": "SANTALPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Padla ",
   "PINCODE": "384246",
   "TALUKA": "SANTALPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Par ",
   "PINCODE": "385350",
   "TALUKA": "SANTALPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Piprana ",
   "PINCODE": "385350",
   "TALUKA": "SANTALPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Santalpur ",
   "PINCODE": "385350",
   "TALUKA": "SANTALPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sidhada ",
   "PINCODE": "385360",
   "TALUKA": "SANTALPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vahuva ",
   "PINCODE": "385350",
   "TALUKA": "SANTALPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Varahi ",
   "PINCODE": "385360",
   "TALUKA": "SANTALPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zandala ",
   "PINCODE": "385360",
   "TALUKA": "SANTALPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zazam ",
   "PINCODE": "385360",
   "TALUKA": "SANTALPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zekhada ",
   "PINCODE": "385360",
   "TALUKA": "SANTALPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kilana ",
   "PINCODE": "385360",
   "TALUKA": "SANTALPURP",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bilia ",
   "PINCODE": "384151",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chandravati ",
   "PINCODE": "384151",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dasawada ",
   "PINCODE": "384265",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dethli ",
   "PINCODE": "384151",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhanawada ",
   "PINCODE": "384265",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dindrol ",
   "PINCODE": "384290",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gangalasan ",
   "PINCODE": "384151",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ganvada ",
   "PINCODE": "384151",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kakoshi ",
   "PINCODE": "384290",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kalyana ",
   "PINCODE": "384265",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khali ",
   "PINCODE": "384151",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kholvada ",
   "PINCODE": "384151",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kunwara ",
   "PINCODE": "384265",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Meloj ",
   "PINCODE": "384151",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Methan ",
   "PINCODE": "384290",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Metrana ",
   "PINCODE": "384290",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mudana ",
   "PINCODE": "384151",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mudvada ",
   "PINCODE": "384290",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nagvasana ",
   "PINCODE": "384151",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nandotri ",
   "PINCODE": "384151",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nedra ",
   "PINCODE": "384151",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pachakvada ",
   "PINCODE": "384265",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sahesa ",
   "PINCODE": "384290",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Samoda ",
   "PINCODE": "384151",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sedrana ",
   "PINCODE": "384151",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sidhpur Jafri Baug ",
   "PINCODE": "384151",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sidhpur Jam Chakla ",
   "PINCODE": "384151",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sidhpur Market Yard ",
   "PINCODE": "384151",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sidhpur ",
   "PINCODE": "384151",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tavadia ",
   "PINCODE": "384151",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umru ",
   "PINCODE": "384151",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadhana ",
   "PINCODE": "384151",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vanasan ",
   "PINCODE": "384151",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Varsila ",
   "PINCODE": "384151",
   "TALUKA": "SIDHPUR",
   "DISTRICT": "PATAN",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhomiyavadar ",
   "PINCODE": "360510",
   "TALUKA": "BHANVAD",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Simar ",
   "PINCODE": "360510",
   "TALUKA": "BHANVAD",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ishwaria ",
   "PINCODE": "360530",
   "TALUKA": "JAMJODHPUR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amar ",
   "PINCODE": "360570",
   "TALUKA": "KUTIYANA",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amipur ",
   "PINCODE": "362620",
   "TALUKA": "KUTIYANA",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhadula ",
   "PINCODE": "362620",
   "TALUKA": "KUTIYANA",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chauta ",
   "PINCODE": "362650",
   "TALUKA": "KUTIYANA",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chhatrava ",
   "PINCODE": "362650",
   "TALUKA": "KUTIYANA",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Devda ",
   "PINCODE": "362650",
   "TALUKA": "KUTIYANA",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Farer ",
   "PINCODE": "362620",
   "TALUKA": "KUTIYANA",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gokran ",
   "PINCODE": "362650",
   "TALUKA": "KUTIYANA",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ishwaria ",
   "PINCODE": "362650",
   "TALUKA": "KUTIYANA",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jamra ",
   "PINCODE": "362620",
   "TALUKA": "KUTIYANA",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kadegi ",
   "PINCODE": "362620",
   "TALUKA": "KUTIYANA",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kansabad ",
   "PINCODE": "362620",
   "TALUKA": "KUTIYANA",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kavalkva ",
   "PINCODE": "362620",
   "TALUKA": "KUTIYANA",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khageshri ",
   "PINCODE": "362650",
   "TALUKA": "KUTIYANA",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kotda ",
   "PINCODE": "362650",
   "TALUKA": "KUTIYANA",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mahiyari ",
   "PINCODE": "362620",
   "TALUKA": "KUTIYANA",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mahobatpara ",
   "PINCODE": "362650",
   "TALUKA": "KUTIYANA",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mal ",
   "PINCODE": "362650",
   "TALUKA": "KUTIYANA",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Malanka ",
   "PINCODE": "360490",
   "TALUKA": "Kutiyana",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mandva ",
   "PINCODE": "362650",
   "TALUKA": "KUTIYANA",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moddar ",
   "PINCODE": "362650",
   "TALUKA": "KUTIYANA",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pasvali ",
   "PINCODE": "362650",
   "TALUKA": "KUTIYANA",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Segras ",
   "PINCODE": "362650",
   "TALUKA": "KUTIYANA",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Piplana ",
   "PINCODE": "362610",
   "TALUKA": "Manavadar BO",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Divrana ",
   "PINCODE": "362220",
   "TALUKA": "Mangrol",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Fulrama ",
   "PINCODE": "362220",
   "TALUKA": "Mangrol",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Juthal ",
   "PINCODE": "362245",
   "TALUKA": "Mangrol",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Osa ",
   "PINCODE": "362220",
   "TALUKA": "Mangrol",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sandha ",
   "PINCODE": "362220",
   "TALUKA": "Mangrol",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Modhvada ",
   "PINCODE": "360590",
   "TALUKA": "PORBAANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Adityana ",
   "PINCODE": "360545",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Advana ",
   "PINCODE": "360590",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bagvadar ",
   "PINCODE": "360590",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bakharla ",
   "PINCODE": "360579",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Balej ",
   "PINCODE": "362230",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhad ",
   "PINCODE": "360576",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bharvada ",
   "PINCODE": "360590",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhavpara ",
   "PINCODE": "360579",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhetakadi ",
   "PINCODE": "360590",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bokhira ",
   "PINCODE": "360579",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Boricha ",
   "PINCODE": "360545",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chhaya ",
   "PINCODE": "360578",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Degam ",
   "PINCODE": "360579",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Erda ",
   "PINCODE": "360576",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Fatana ",
   "PINCODE": "360590",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Garej ",
   "PINCODE": "360576",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghodadar ",
   "PINCODE": "362230",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gosa ",
   "PINCODE": "360576",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kadachh ",
   "PINCODE": "362230",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khambhodara ",
   "PINCODE": "360590",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khapat ",
   "PINCODE": "360579",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khistri ",
   "PINCODE": "360579",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kindarkheda ",
   "PINCODE": "360590",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kuchhdi ",
   "PINCODE": "360579",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kutiyana ",
   "PINCODE": "362650",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Madhavpur ",
   "PINCODE": "362230",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Majivana ",
   "PINCODE": "360590",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mander ",
   "PINCODE": "362230",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mitrala ",
   "PINCODE": "360576",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Miyani ",
   "PINCODE": "360579",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Morana ",
   "PINCODE": "360590",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mul Madhavpur ",
   "PINCODE": "362230",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nagka ",
   "PINCODE": "360579",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navibandar ",
   "PINCODE": "360576",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Odadar ",
   "PINCODE": "360576",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pandavadar ",
   "PINCODE": "360579",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pata ",
   "PINCODE": "362230",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Porbandar Birla Sagar ",
   "PINCODE": "360576",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Porbandar G.I.D.C. ",
   "PINCODE": "360577",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Porbandar H.O",
   "PINCODE": "360575",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ranakandorana ",
   "PINCODE": "360570",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ranavav Railway Station ",
   "PINCODE": "360560",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ranavav ",
   "PINCODE": "360550",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ratdi ",
   "PINCODE": "360579",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ratia ",
   "PINCODE": "360576",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shingda ",
   "PINCODE": "360590",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sisli ",
   "PINCODE": "360590",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sodhana ",
   "PINCODE": "360590",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tukda Gosa ",
   "PINCODE": "360576",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tukda Miyan ",
   "PINCODE": "360579",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadala Rana ",
   "PINCODE": "360590",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Visavada ",
   "PINCODE": "360579",
   "TALUKA": "PORBANDAR",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amardad ",
   "PINCODE": "360560",
   "TALUKA": "RANAVAV",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Aniyari ",
   "PINCODE": "360570",
   "TALUKA": "RANAVAV",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bapodar ",
   "PINCODE": "360570",
   "TALUKA": "RANAVAV",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhod ",
   "PINCODE": "360550",
   "TALUKA": "RANAVAV",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhodadar ",
   "PINCODE": "360570",
   "TALUKA": "RANAVAV",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bileshwar ",
   "PINCODE": "360550",
   "TALUKA": "RANAVAV",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dharampur ",
   "PINCODE": "360560",
   "TALUKA": "RANAVAV",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jamboo ",
   "PINCODE": "360570",
   "TALUKA": "RANAVAV",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mokal ",
   "PINCODE": "360570",
   "TALUKA": "RANAVAV",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ranabordi ",
   "PINCODE": "360570",
   "TALUKA": "RANAVAV",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ranakhirasara ",
   "PINCODE": "360570",
   "TALUKA": "RANAVAV",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Thoyana ",
   "PINCODE": "360570",
   "TALUKA": "RANAVAV",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadvalarana ",
   "PINCODE": "360570",
   "TALUKA": "RANAVAV",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Valotra ",
   "PINCODE": "360570",
   "TALUKA": "RANAVAV",
   "DISTRICT": "PORBANDAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Devgam ",
   "PINCODE": "360021",
   "TALUKA": ".",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jivapar ",
   "PINCODE": "360040",
   "TALUKA": ".",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kanpara ",
   "PINCODE": "360040",
   "TALUKA": ".",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khirsara ",
   "PINCODE": "360021",
   "TALUKA": ".",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nagar Pipaliya ",
   "PINCODE": "360021",
   "TALUKA": ".",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panchavada ",
   "PINCODE": "360040",
   "TALUKA": ".",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajkot Metoda Gidc ",
   "PINCODE": "360021",
   "TALUKA": ".",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhavpar ",
   "PINCODE": "363660",
   "TALUKA": "DAHISARA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bodki ",
   "PINCODE": "363660",
   "TALUKA": "DAHISARA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dahisara ",
   "PINCODE": "363660",
   "TALUKA": "DAHISARA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kuntasi ",
   "PINCODE": "363660",
   "TALUKA": "DAHISARA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lavanpur ",
   "PINCODE": "363660",
   "TALUKA": "DAHISARA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mota  Bhela ",
   "PINCODE": "363660",
   "TALUKA": "DAHISARA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Varsamedi ",
   "PINCODE": "363660",
   "TALUKA": "DAHISARA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vavania ",
   "PINCODE": "363660",
   "TALUKA": "DAHISARA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Virparda ",
   "PINCODE": "363660",
   "TALUKA": "DAHISARA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhadajalia ",
   "PINCODE": "360421",
   "TALUKA": "Dhoraji",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhader ",
   "PINCODE": "360410",
   "TALUKA": "Dhoraji",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhola ",
   "PINCODE": "360410",
   "TALUKA": "Dhoraji",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhukhi ",
   "PINCODE": "360410",
   "TALUKA": "Dhoraji",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chhadvavadar ",
   "PINCODE": "360410",
   "TALUKA": "Dhoraji",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chhatrasa ",
   "PINCODE": "360410",
   "TALUKA": "Dhoraji",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chichod ",
   "PINCODE": "360430",
   "TALUKA": "Dhoraji",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhoraji D.G. ",
   "PINCODE": "360410",
   "TALUKA": "Dhoraji",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhoraji G.P. ",
   "PINCODE": "360410",
   "TALUKA": "Dhoraji",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhoraji ",
   "PINCODE": "360410",
   "TALUKA": "Dhoraji",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhoraji S.R. ",
   "PINCODE": "360410",
   "TALUKA": "Dhoraji",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jamnavad ",
   "PINCODE": "360410",
   "TALUKA": "Dhoraji",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kalana ",
   "PINCODE": "360410",
   "TALUKA": "Dhoraji",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moti Marad ",
   "PINCODE": "360421",
   "TALUKA": "Dhoraji",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moti Vavdi ",
   "PINCODE": "360440",
   "TALUKA": "Dhoraji",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nagalkhada ",
   "PINCODE": "360410",
   "TALUKA": "Dhoraji",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nani Vavdi ",
   "PINCODE": "360440",
   "TALUKA": "Dhoraji",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Patanvav ",
   "PINCODE": "360430",
   "TALUKA": "Dhoraji",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pipaliya ",
   "PINCODE": "360410",
   "TALUKA": "Dhoraji",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Supedi ",
   "PINCODE": "360440",
   "TALUKA": "Dhoraji",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadodar ",
   "PINCODE": "360410",
   "TALUKA": "Dhoraji",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zanzmer ",
   "PINCODE": "360440",
   "TALUKA": "Dhoraji",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hadmatiya ",
   "PINCODE": "360110",
   "TALUKA": "DHROL",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khajurdi ",
   "PINCODE": "360110",
   "TALUKA": "DHROL",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khakhdabela ",
   "PINCODE": "360110",
   "TALUKA": "DHROL",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Suvag ",
   "PINCODE": "360110",
   "TALUKA": "DHROL",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Visaman ",
   "PINCODE": "360110",
   "TALUKA": "DHROL",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambardi ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Anida Bhalodi ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bandhiya ",
   "PINCODE": "360330",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bandra ",
   "PINCODE": "360330",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhunava ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bildi ",
   "PINCODE": "364490",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Biliyala ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Charakhadi ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chordi ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dadva Mota ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Daiya ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dalia ",
   "PINCODE": "360070",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Derdi Kumbaji ",
   "PINCODE": "364465",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Devchadi ",
   "PINCODE": "360330",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhudasiya ",
   "PINCODE": "364470",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Garnara ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghoghavadar ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gomta ",
   "PINCODE": "360320",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gondal Bhagvatpara ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gondal Bhojrajpara ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gondal Bhuvneshwari Pith ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gondal College Chowk ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gondal H.O",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gondal Market Yard ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gundasara ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hadamtala (Kolithad) ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hadamtala (Shemla) ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jamvadi ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kamar Kotda ",
   "PINCODE": "360330",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khadvanthali ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khambha ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khandadhar ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kolithad ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lunivav ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mandan Kundla ",
   "PINCODE": "360330",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Meta Khambhaliya ",
   "PINCODE": "364465",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mota Mandva ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moti Khilori ",
   "PINCODE": "364465",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moviya ",
   "PINCODE": "360330",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nana Mandva ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navagam ",
   "PINCODE": "360320",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Patidad ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pipaliya(Sadak) ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ramod ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ravna ",
   "PINCODE": "364490",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rib ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ribda ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sandhvaya ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Semla ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shivrajgadh ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shrinathgadh ",
   "PINCODE": "360330",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sultanpur ",
   "PINCODE": "364470",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Trakuda ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umrali ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vachhra ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasavad ",
   "PINCODE": "364490",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vekri ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vinzivad ",
   "PINCODE": "364470",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vora Kotda ",
   "PINCODE": "360311",
   "TALUKA": "Gondal",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Baradiya ",
   "PINCODE": "360452",
   "TALUKA": "Jamkandorna",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhadra ",
   "PINCODE": "360405",
   "TALUKA": "Jamkandorna",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Boria ",
   "PINCODE": "360405",
   "TALUKA": "Jamkandorna",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Charel ",
   "PINCODE": "360452",
   "TALUKA": "Jamkandorna",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chavandi ",
   "PINCODE": "360452",
   "TALUKA": "Jamkandorna",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chitravad ",
   "PINCODE": "360452",
   "TALUKA": "Jamkandorna",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dadar ",
   "PINCODE": "360452",
   "TALUKA": "Jamkandorna",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dadvi ",
   "PINCODE": "360405",
   "TALUKA": "Jamkandorna",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dholidhar ",
   "PINCODE": "360405",
   "TALUKA": "Jamkandorna",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dudhivadar ",
   "PINCODE": "360410",
   "TALUKA": "Jamkandorna",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gundasari ",
   "PINCODE": "360452",
   "TALUKA": "Jamkandorna",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jamkandorna ",
   "PINCODE": "360405",
   "TALUKA": "Jamkandorna",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khajurda ",
   "PINCODE": "360440",
   "TALUKA": "Jamkandorna",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khatli ",
   "PINCODE": "360452",
   "TALUKA": "Jamkandorna",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nava Matravad ",
   "PINCODE": "360450",
   "TALUKA": "Jamkandorna",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pipardi ",
   "PINCODE": "360405",
   "TALUKA": "Jamkandorna",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Raidi ",
   "PINCODE": "360410",
   "TALUKA": "Jamkandorna",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Roghel ",
   "PINCODE": "360410",
   "TALUKA": "Jamkandorna",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sajadiyali ",
   "PINCODE": "360405",
   "TALUKA": "Jamkandorna",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Satodad ",
   "PINCODE": "360405",
   "TALUKA": "Jamkandorna",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sodvadar ",
   "PINCODE": "360440",
   "TALUKA": "Jamkandorna",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vavdi ",
   "PINCODE": "360405",
   "TALUKA": "Jamkandorna",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ishavariya ",
   "PINCODE": "360040",
   "TALUKA": "Jasadan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ajmer ",
   "PINCODE": "360055",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amrapar ",
   "PINCODE": "360055",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Atkot ",
   "PINCODE": "360040",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bakhalvad ",
   "PINCODE": "360050",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Baldhoi ",
   "PINCODE": "360060",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhadla ",
   "PINCODE": "360080",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhandaria ",
   "PINCODE": "360020",
   "TALUKA": "JASDAN",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bogharavadar ",
   "PINCODE": "360020",
   "TALUKA": "JASDAN",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chhasiya ",
   "PINCODE": "360055",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dahisara ",
   "PINCODE": "360020",
   "TALUKA": "JASDAN",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Devdhari ",
   "PINCODE": "360055",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dodiyala ",
   "PINCODE": "364490",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gadhadia ",
   "PINCODE": "360050",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gadhdiya ",
   "PINCODE": "360020",
   "TALUKA": "JASDAN",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghela Somnath ",
   "PINCODE": "360050",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gokhlana ",
   "PINCODE": "360050",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gundala (Jas) ",
   "PINCODE": "360055",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hathasani ",
   "PINCODE": "360055",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jangvad ",
   "PINCODE": "360040",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jasapar ",
   "PINCODE": "360311",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jasdan ",
   "PINCODE": "360050",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jivapar ",
   "PINCODE": "360311",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Juna Pipaliya ",
   "PINCODE": "364490",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kaduka ",
   "PINCODE": "360050",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kalasar ",
   "PINCODE": "360050",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kamalapur ",
   "PINCODE": "360020",
   "TALUKA": "JASDAN",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kanesara ",
   "PINCODE": "360020",
   "TALUKA": "JASDAN",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kanpar ",
   "PINCODE": "360311",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khandhevadia ",
   "PINCODE": "360055",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kharachiya Jam ",
   "PINCODE": "360060",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kothi ",
   "PINCODE": "360020",
   "TALUKA": "JASDAN",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kundani ",
   "PINCODE": "360020",
   "TALUKA": "JASDAN",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lakhavad Moti ",
   "PINCODE": "360055",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lakhavad Nani ",
   "PINCODE": "360060",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lilapur ",
   "PINCODE": "360050",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Meghpar ",
   "PINCODE": "364490",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Modhuka ",
   "PINCODE": "360055",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panchavda ",
   "PINCODE": "360311",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pipardi ",
   "PINCODE": "360055",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sanali ",
   "PINCODE": "360055",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sanathali ",
   "PINCODE": "364490",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shivrajpur ",
   "PINCODE": "360050",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadod ",
   "PINCODE": "360050",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vangadhra ",
   "PINCODE": "360055",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vinchhiya ",
   "PINCODE": "360055",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Virnagar ",
   "PINCODE": "360060",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zundala ",
   "PINCODE": "364490",
   "TALUKA": "Jasdan",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Akala ",
   "PINCODE": "360360",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amarnagar ",
   "PINCODE": "364485",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bava Pipaliya ",
   "PINCODE": "360360",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Champrajpur ",
   "PINCODE": "360370",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Charania ",
   "PINCODE": "365480",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dedarva ",
   "PINCODE": "360360",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Derdi ",
   "PINCODE": "360370",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Devki Galol ",
   "PINCODE": "360370",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Devla ",
   "PINCODE": "364485",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Fareni ",
   "PINCODE": "360370",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jambudi ",
   "PINCODE": "360370",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jetalsar Gam ",
   "PINCODE": "360360",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jetalsar Jn. ",
   "PINCODE": "360360",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jetpur F.W. ",
   "PINCODE": "360370",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jetpur K.B. ",
   "PINCODE": "360370",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jetpur ",
   "PINCODE": "360370",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Juni Sankli ",
   "PINCODE": "360360",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kagvad ",
   "PINCODE": "360380",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kerali ",
   "PINCODE": "360370",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kharachiya ",
   "PINCODE": "360370",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khirasara ",
   "PINCODE": "364485",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mandlikpur ",
   "PINCODE": "360370",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mevasa ",
   "PINCODE": "360370",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mota Gundala ",
   "PINCODE": "360370",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moti Parabadi ",
   "PINCODE": "360360",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nani Parabadi ",
   "PINCODE": "360360",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navagadh ",
   "PINCODE": "360375",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panch Pipla ",
   "PINCODE": "360370",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pedhla ",
   "PINCODE": "360370",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pipalva ",
   "PINCODE": "360360",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pithadia ",
   "PINCODE": "360370",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Premgadh ",
   "PINCODE": "360370",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rabarika ",
   "PINCODE": "360370",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Reshamdi Galol ",
   "PINCODE": "360370",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rupavati ",
   "PINCODE": "360360",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Samadhiyala ",
   "PINCODE": "360370",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sardharpur ",
   "PINCODE": "360375",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Thana Galol ",
   "PINCODE": "360370",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Timbdi Arab ",
   "PINCODE": "360360",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Torania ",
   "PINCODE": "360360",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadasada ",
   "PINCODE": "364485",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vavdi Station ",
   "PINCODE": "364485",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Virpur ",
   "PINCODE": "360380",
   "TALUKA": "Jetpur",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Makajimeghpar ",
   "PINCODE": "360110",
   "TALUKA": "KALKAVAD",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Anida Vachhra ",
   "PINCODE": "360070",
   "TALUKA": "Kotda",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ardoi ",
   "PINCODE": "360030",
   "TALUKA": "Kotda",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhadva ",
   "PINCODE": "360030",
   "TALUKA": "Kotda",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Champabeda ",
   "PINCODE": "360070",
   "TALUKA": "Kotda",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khareda ",
   "PINCODE": "360030",
   "TALUKA": "Kotda",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kotda Sangani ",
   "PINCODE": "360030",
   "TALUKA": "Kotda",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Manekwada ",
   "PINCODE": "360030",
   "TALUKA": "Kotda",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nonghanchora ",
   "PINCODE": "360070",
   "TALUKA": "Kotda",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajapara ",
   "PINCODE": "360030",
   "TALUKA": "Kotda",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Satapar ",
   "PINCODE": "360330",
   "TALUKA": "Kotda",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shishak ",
   "PINCODE": "360330",
   "TALUKA": "Kotda",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Juna Rajpipala ",
   "PINCODE": "360020",
   "TALUKA": "KOTDA SAANGANI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mengni ",
   "PINCODE": "360070",
   "TALUKA": "Kotda Sangani",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shapar( Halar) ",
   "PINCODE": "360024",
   "TALUKA": "KOTDA SANGANI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Veraval (Shapar) ",
   "PINCODE": "360024",
   "TALUKA": "KOTDA SANGHANI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chandli ",
   "PINCODE": "360035",
   "TALUKA": "Lodhika",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chibhda ",
   "PINCODE": "360035",
   "TALUKA": "Lodhika",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhudiadomda ",
   "PINCODE": "360110",
   "TALUKA": "LODHIKA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kotha Pipalia ",
   "PINCODE": "360035",
   "TALUKA": "Lodhika",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lodhika ",
   "PINCODE": "360035",
   "TALUKA": "Lodhika",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Motavada ",
   "PINCODE": "360110",
   "TALUKA": "LODHIKA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pardi ",
   "PINCODE": "360024",
   "TALUKA": "LODHIKA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sal Pipalia ",
   "PINCODE": "360110",
   "TALUKA": "LODHIKA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sanganva ",
   "PINCODE": "360035",
   "TALUKA": "Lodhika",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Derala ",
   "PINCODE": "363641",
   "TALUKA": "MALIA (M)",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vaghpar ",
   "PINCODE": "363630",
   "TALUKA": "MALIYA  MIYANA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jajasar ",
   "PINCODE": "363670",
   "TALUKA": "MALIYA MIYANA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Juna Ghantila ",
   "PINCODE": "363630",
   "TALUKA": "MALIYA MIYANA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Juna Nagdavas ",
   "PINCODE": "363670",
   "TALUKA": "MALIYA MIYANA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khakhrechi ",
   "PINCODE": "363630",
   "TALUKA": "MALIYA MIYANA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khirai ",
   "PINCODE": "363670",
   "TALUKA": "MALIYA MIYANA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kumbhariya ",
   "PINCODE": "363630",
   "TALUKA": "MALIYA MIYANA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Maliya Miyana ",
   "PINCODE": "363670",
   "TALUKA": "MALIYA MIYANA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Motibarar ",
   "PINCODE": "363670",
   "TALUKA": "MALIYA MIYANA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nani Barar ",
   "PINCODE": "363670",
   "TALUKA": "MALIYA MIYANA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navagam ",
   "PINCODE": "363670",
   "TALUKA": "MALIYA MIYANA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Saravad ",
   "PINCODE": "363641",
   "TALUKA": "MALIYA MIYANA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sultanpur ",
   "PINCODE": "363630",
   "TALUKA": "MALIYA MIYANA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Targhadi ",
   "PINCODE": "363636",
   "TALUKA": "MALIYA MIYANA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadharva ",
   "PINCODE": "363670",
   "TALUKA": "MALIYA MIYANA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vejalpar ",
   "PINCODE": "363630",
   "TALUKA": "MALIYA MIYANA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Venasar ",
   "PINCODE": "363630",
   "TALUKA": "MALIYA MIYANA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Virvadrka ",
   "PINCODE": "363670",
   "TALUKA": "MALIYA MIYANA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bagathala ",
   "PINCODE": "363641",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Barvala ",
   "PINCODE": "363641",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bela Rangpar ",
   "PINCODE": "363641",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhadiyad ",
   "PINCODE": "363642",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Biliya ",
   "PINCODE": "363641",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chachapar ",
   "PINCODE": "363641",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gala ",
   "PINCODE": "363630",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghunda (S) ",
   "PINCODE": "363641",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghuntu ",
   "PINCODE": "363641",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gungan ",
   "PINCODE": "363642",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Haripar ",
   "PINCODE": "363630",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jambudiya ",
   "PINCODE": "363642",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jetpar (M) ",
   "PINCODE": "363630",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jivapar ",
   "PINCODE": "363630",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jodjpar Nadi ",
   "PINCODE": "363642",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khakhrala ",
   "PINCODE": "363641",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khanpar ",
   "PINCODE": "363641",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kherda ",
   "PINCODE": "363641",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khevaliya ",
   "PINCODE": "363641",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lilapar ",
   "PINCODE": "363641",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mahendranagar ",
   "PINCODE": "363642",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Makansar ",
   "PINCODE": "363642",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Manekwada ",
   "PINCODE": "363641",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Morbi Eng.College ",
   "PINCODE": "363642",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Morbi GIDC ",
   "PINCODE": "363641",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Morbi Nani Bazar ",
   "PINCODE": "363641",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Morbi Ppw ",
   "PINCODE": "363642",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Morbi ",
   "PINCODE": "363641",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Morbi Shakti Plot ",
   "PINCODE": "363641",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nani Vavdi ",
   "PINCODE": "363641",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nichimandal ",
   "PINCODE": "363641",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panchasar ",
   "PINCODE": "363641",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Paneli ",
   "PINCODE": "363642",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pipaliya ",
   "PINCODE": "363660",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pipli ",
   "PINCODE": "363642",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rafaleshwar ",
   "PINCODE": "363642",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajpar ",
   "PINCODE": "363641",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rangpar (Bela) ",
   "PINCODE": "363641",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ravapar ",
   "PINCODE": "363642",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sadulkanava ",
   "PINCODE": "363642",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sapar ",
   "PINCODE": "363630",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shakat Sanala ",
   "PINCODE": "363641",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sokhda ",
   "PINCODE": "363670",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Thorala ",
   "PINCODE": "363641",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Unchi Mandal ",
   "PINCODE": "363641",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vankada ",
   "PINCODE": "363641",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Virpar ",
   "PINCODE": "363641",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zinkiyali ",
   "PINCODE": "363641",
   "TALUKA": "MORBI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Adbalka ",
   "PINCODE": "360110",
   "TALUKA": "PADDHARI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dungarka ",
   "PINCODE": "360110",
   "TALUKA": "PADDHARI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ishwariya ",
   "PINCODE": "360110",
   "TALUKA": "PADDHARI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khambhala ",
   "PINCODE": "360110",
   "TALUKA": "PADDHARI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khamta ",
   "PINCODE": "360110",
   "TALUKA": "PADDHARI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khandheri ",
   "PINCODE": "360110",
   "TALUKA": "PADDHARI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khodapipar ",
   "PINCODE": "360110",
   "TALUKA": "PADDHARI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Motakhijadia ",
   "PINCODE": "360110",
   "TALUKA": "PADDHARI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Motichanol ",
   "PINCODE": "360110",
   "TALUKA": "PADDHARI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nana Khijadia ",
   "PINCODE": "360110",
   "TALUKA": "PADDHARI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Paddhari ",
   "PINCODE": "360110",
   "TALUKA": "PADDHARI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rampar Mota ",
   "PINCODE": "360110",
   "TALUKA": "PADDHARI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rampar Pati ",
   "PINCODE": "360110",
   "TALUKA": "PADDHARI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rupavati ",
   "PINCODE": "360110",
   "TALUKA": "PADDHARI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sarapdad ",
   "PINCODE": "360110",
   "TALUKA": "PADDHARI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Targhari ",
   "PINCODE": "360110",
   "TALUKA": "PADDHARI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Thoriyali ",
   "PINCODE": "360110",
   "TALUKA": "PADDHARI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ukarda ",
   "PINCODE": "360110",
   "TALUKA": "PADDHARI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zilariya ",
   "PINCODE": "360110",
   "TALUKA": "PADDHARI",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Anandpar Navagam ",
   "PINCODE": "360003",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Anandpar(Morbi) ",
   "PINCODE": "360003",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bedi(Rajkot) ",
   "PINCODE": "360003",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bedla ",
   "PINCODE": "360020",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhupgadh ",
   "PINCODE": "360020",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Devgam ",
   "PINCODE": "360003",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dholara ",
   "PINCODE": "360002",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gadhaka ",
   "PINCODE": "360020",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gauridad ",
   "PINCODE": "360003",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hadmatia ",
   "PINCODE": "360020",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Halenda ",
   "PINCODE": "360020",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Haripar ",
   "PINCODE": "360020",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jaliya(Dhrol) ",
   "PINCODE": "360003",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kagadadi ",
   "PINCODE": "360003",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kankot ",
   "PINCODE": "360005",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kasturbadham ",
   "PINCODE": "360020",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kharechiya ",
   "PINCODE": "360020",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kherdi ",
   "PINCODE": "360002",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khirasara ",
   "PINCODE": "360003",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khokhaddad ",
   "PINCODE": "360002",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khorana ",
   "PINCODE": "360003",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kotda Nayani ",
   "PINCODE": "360003",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kotharia ",
   "PINCODE": "360002",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kothariatbhospital ",
   "PINCODE": "360002",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kuchiyadad ",
   "PINCODE": "360002",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kuvadava ",
   "PINCODE": "360002",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Madhapar ",
   "PINCODE": "360006",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mafatiyapara ",
   "PINCODE": "360002",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Magharvada ",
   "PINCODE": "360003",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mahika ",
   "PINCODE": "360002",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Maliyasan ",
   "PINCODE": "360003",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mavdi ",
   "PINCODE": "360004",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mesavada ",
   "PINCODE": "360003",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mota Mava ",
   "PINCODE": "360005",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Padasan ",
   "PINCODE": "360020",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pal ",
   "PINCODE": "360004",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Para  Pipaliya ",
   "PINCODE": "360006",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pipaliya ",
   "PINCODE": "360003",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rafala ",
   "PINCODE": "360003",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Raiya ",
   "PINCODE": "360005",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajkot  Raiya Road ",
   "PINCODE": "360007",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajkot Aji Ind Estate ",
   "PINCODE": "360003",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajkot Bedipara ",
   "PINCODE": "360003",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajkot Bhaktinagar ",
   "PINCODE": "360002",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajkot Bhomeshwar Plot ",
   "PINCODE": "360006",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajkot City ",
   "PINCODE": "360001",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajkot Collectorate ",
   "PINCODE": "360001",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajkot D H College ",
   "PINCODE": "360001",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajkot H.O",
   "PINCODE": "360001",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajkot Jairaj Plot ",
   "PINCODE": "360001",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajkot Jn. Plot ",
   "PINCODE": "360001",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajkot Kalavad Road ",
   "PINCODE": "360001",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajkot Malviyanagar ",
   "PINCODE": "360004",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajkot Manahar Plot ",
   "PINCODE": "360002",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajkot Mandvi Chowk ",
   "PINCODE": "360001",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajkot Marketing Yard ",
   "PINCODE": "360003",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajkot Millpara ",
   "PINCODE": "360002",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajkot Mochi Bazar ",
   "PINCODE": "360001",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajkot Municipal Corporation ",
   "PINCODE": "360001",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajkot New Jagnath Plot ",
   "PINCODE": "360001",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajkot Parsi Agiyari Chowk ",
   "PINCODE": "360001",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajkot Popatpara ",
   "PINCODE": "360001",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajkot Postal Colony ",
   "PINCODE": "360004",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajkot Race Course Road ",
   "PINCODE": "360001",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajkot Sau Uni Area ",
   "PINCODE": "360005",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajkot Sorathiawadi ",
   "PINCODE": "360002",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajkot Udyognagar ",
   "PINCODE": "360002",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajkot Vivekanandnagar ",
   "PINCODE": "360002",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ravki ",
   "PINCODE": "360004",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Samadhiyala ",
   "PINCODE": "360020",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sanosara ",
   "PINCODE": "360003",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shri Shardanagar ",
   "PINCODE": "363636",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Targhadia ",
   "PINCODE": "360003",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umrali ",
   "PINCODE": "360020",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadali ",
   "PINCODE": "360020",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vavdi ",
   "PINCODE": "360004",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vavdi ",
   "PINCODE": "360004",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ziyana ",
   "PINCODE": "360003",
   "TALUKA": "RAJKOT",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sardhar ",
   "PINCODE": "360020",
   "TALUKA": "SARDHAR",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lajai ",
   "PINCODE": "363641",
   "TALUKA": "TAANKARAA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bangavadi ",
   "PINCODE": "363650",
   "TALUKA": "TANKARA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bedi( Tankara) ",
   "PINCODE": "363650",
   "TALUKA": "TANKARA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghunda Khanpar ",
   "PINCODE": "363641",
   "TALUKA": "TANKARA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hadmatiya ",
   "PINCODE": "363641",
   "TALUKA": "TANKARA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Harbatiyali ",
   "PINCODE": "363650",
   "TALUKA": "TANKARA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hirapar ",
   "PINCODE": "363650",
   "TALUKA": "TANKARA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jabalpur ",
   "PINCODE": "363650",
   "TALUKA": "TANKARA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jivapar ",
   "PINCODE": "363650",
   "TALUKA": "TANKARA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kotharia(Tankara) ",
   "PINCODE": "363650",
   "TALUKA": "TANKARA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Meghpar Zala ",
   "PINCODE": "363650",
   "TALUKA": "TANKARA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mitana ",
   "PINCODE": "363650",
   "TALUKA": "TANKARA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mota Khijadia ",
   "PINCODE": "363650",
   "TALUKA": "TANKARA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nasitpar ",
   "PINCODE": "363641",
   "TALUKA": "TANKARA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Neknam ",
   "PINCODE": "363650",
   "TALUKA": "TANKARA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nesda (K) ",
   "PINCODE": "363641",
   "TALUKA": "TANKARA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Otala ",
   "PINCODE": "363650",
   "TALUKA": "TANKARA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rohishala ",
   "PINCODE": "363650",
   "TALUKA": "TANKARA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sajanpar ",
   "PINCODE": "363641",
   "TALUKA": "TANKARA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Savadi ",
   "PINCODE": "363650",
   "TALUKA": "TANKARA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tankara ",
   "PINCODE": "363650",
   "TALUKA": "TANKARA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vachhakapar ",
   "PINCODE": "363650",
   "TALUKA": "TANKARA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Virvav ",
   "PINCODE": "363650",
   "TALUKA": "TANKARA",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Arni ",
   "PINCODE": "360450",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhankh ",
   "PINCODE": "360490",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhayavadar ",
   "PINCODE": "360450",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhimora ",
   "PINCODE": "360490",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chikhaliya ",
   "PINCODE": "360410",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhank ",
   "PINCODE": "360460",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dumiyani ",
   "PINCODE": "360440",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ganod ",
   "PINCODE": "360490",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hariyasan ",
   "PINCODE": "360480",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ishra ",
   "PINCODE": "360490",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kalariya ",
   "PINCODE": "360490",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khakhijaliya ",
   "PINCODE": "360490",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kharachiya ",
   "PINCODE": "360470",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khirsara (Ghed) ",
   "PINCODE": "360450",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kolki ",
   "PINCODE": "360470",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lath ",
   "PINCODE": "360490",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mekha Timbi ",
   "PINCODE": "360470",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mervadar ",
   "PINCODE": "360490",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mojira ",
   "PINCODE": "360490",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nagvadar ",
   "PINCODE": "360490",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nilakha ",
   "PINCODE": "360490",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Padavla ",
   "PINCODE": "360480",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Paneli ",
   "PINCODE": "360480",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pransla ",
   "PINCODE": "360490",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rabarika ",
   "PINCODE": "360470",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sajadiyali ",
   "PINCODE": "360450",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Samadhiyala ",
   "PINCODE": "360490",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Talagana ",
   "PINCODE": "360490",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tanasva ",
   "PINCODE": "360490",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Timbdi Jam ",
   "PINCODE": "360450",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Upleta Lati Plot ",
   "PINCODE": "360490",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Upleta ",
   "PINCODE": "360490",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadala ",
   "PINCODE": "360490",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadali ",
   "PINCODE": "360450",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Varjang Jalia ",
   "PINCODE": "360490",
   "TALUKA": "Upleta",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amarpara Wankaner ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Arnitimba ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhalgam ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bherda ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhimguda ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chandrapur ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Daldi ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhuva ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gariya ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghiyavad ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jadeshvar ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jalida ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kankot ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kerala ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kherva ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khijadia ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kotharia ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kothi ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lunsar ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lunsariya ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mahika ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Matel ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mesariya ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Paddhara ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panchasia ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panchdwarka ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pipaliya Raj ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajavadala ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ranekpar ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ratidevdi ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Samadhiyala ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sardharka ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sindhavadar ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tarakiya ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tithva ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vaghasiya ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Valasan ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vardusar ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Wankaner ",
   "PINCODE": "363621",
   "TALUKA": "WANKANER",
   "DISTRICT": "RAJKOT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Alwa ",
   "PINCODE": "383325",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambagam ",
   "PINCODE": "383325",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambaliara ",
   "PINCODE": "383325",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amiapura ",
   "PINCODE": "383325",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amodara ",
   "PINCODE": "383330",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Badarpura ",
   "PINCODE": "383335",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bayad ",
   "PINCODE": "383325",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bayad Town ",
   "PINCODE": "383325",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhukhel ",
   "PINCODE": "383325",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhundasan ",
   "PINCODE": "383325",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bibinivav ",
   "PINCODE": "383325",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Boral ",
   "PINCODE": "383330",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bordi ",
   "PINCODE": "383340",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chandrej ",
   "PINCODE": "383260",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chhabhou ",
   "PINCODE": "383330",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Choila ",
   "PINCODE": "383327",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dabha ",
   "PINCODE": "383325",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dakhneshwar ",
   "PINCODE": "383325",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Demai ",
   "PINCODE": "383330",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Deroli ",
   "PINCODE": "383330",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Desaipura ",
   "PINCODE": "383330",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gabat ",
   "PINCODE": "383335",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ganeshpura ",
   "PINCODE": "383325",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gotapur ",
   "PINCODE": "383335",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hathipura ",
   "PINCODE": "383340",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Indran ",
   "PINCODE": "383340",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jalampur ",
   "PINCODE": "383340",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jitpur ",
   "PINCODE": "383325",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lank ",
   "PINCODE": "383330",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Limb ",
   "PINCODE": "383325",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Madhavgadh ",
   "PINCODE": "383330",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Odha ",
   "PINCODE": "383340",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pipodara ",
   "PINCODE": "383325",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Radodara ",
   "PINCODE": "383325",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ramos ",
   "PINCODE": "383325",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ranechi ",
   "PINCODE": "383325",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sarsoli ",
   "PINCODE": "383335",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sathamba ",
   "PINCODE": "383340",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Savela ",
   "PINCODE": "383340",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Talod ",
   "PINCODE": "383340",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tenpur ",
   "PINCODE": "383325",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Untarda ",
   "PINCODE": "383325",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vantda Bayad ",
   "PINCODE": "383325",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasnirel ",
   "PINCODE": "383325",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vatrakgadh ",
   "PINCODE": "383260",
   "TALUKA": "Bayad",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ada Hathrol ",
   "PINCODE": "383240",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambabar ",
   "PINCODE": "383246",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ansol ",
   "PINCODE": "383251",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bamna ",
   "PINCODE": "383240",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhanmer ",
   "PINCODE": "383246",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhatera ",
   "PINCODE": "383245",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhetali ",
   "PINCODE": "383245",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhiloda Bazar ",
   "PINCODE": "383245",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhiloda ",
   "PINCODE": "383245",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhutavad ",
   "PINCODE": "383245",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Budheli ",
   "PINCODE": "383246",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Budhrasan ",
   "PINCODE": "383246",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chiboda ",
   "PINCODE": "383245",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chorimala ",
   "PINCODE": "383246",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chunakhan ",
   "PINCODE": "383245",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dahegamda ",
   "PINCODE": "383251",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Devnimori ",
   "PINCODE": "383355",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhambolia ",
   "PINCODE": "383355",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhandhasan ",
   "PINCODE": "383355",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhansor ",
   "PINCODE": "383246",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dholvani ",
   "PINCODE": "383245",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dodisara ",
   "PINCODE": "383355",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gali Semro ",
   "PINCODE": "383251",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Himmatpur ",
   "PINCODE": "383240",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jab Chitaria ",
   "PINCODE": "383355",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jayla ",
   "PINCODE": "383246",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jeshingpur ",
   "PINCODE": "383245",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jinjudi ",
   "PINCODE": "383246",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jumsar ",
   "PINCODE": "383450",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kagda Mahuda ",
   "PINCODE": "383251",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karchha ",
   "PINCODE": "383355",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khalvad ",
   "PINCODE": "383245",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kheradi ",
   "PINCODE": "383250",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kherancha ",
   "PINCODE": "383355",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khiloda ",
   "PINCODE": "383250",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kishangadh ",
   "PINCODE": "383450",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kundol Pal ",
   "PINCODE": "383246",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kushki ",
   "PINCODE": "383250",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lilchha ",
   "PINCODE": "383245",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lusadia ",
   "PINCODE": "383251",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Malasa ",
   "PINCODE": "383450",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mankdi ",
   "PINCODE": "383240",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mau Bhavnath ",
   "PINCODE": "383245",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Meditimba ",
   "PINCODE": "383240",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mehru ",
   "PINCODE": "383245",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mota Kantharia ",
   "PINCODE": "383251",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moti Bebar ",
   "PINCODE": "383250",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Munai ",
   "PINCODE": "383450",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nandoj ",
   "PINCODE": "383245",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nankhi ",
   "PINCODE": "383450",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Napda ",
   "PINCODE": "383355",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Narsoli ",
   "PINCODE": "383245",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nava Bhavnath ",
   "PINCODE": "383245",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ode ",
   "PINCODE": "383355",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Palla ",
   "PINCODE": "383355",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panch Mahudi ",
   "PINCODE": "383355",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Punasan ",
   "PINCODE": "383240",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Raipur ",
   "PINCODE": "383245",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Raisingpur ",
   "PINCODE": "383246",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajendranagar ",
   "PINCODE": "383276",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rampuri ",
   "PINCODE": "383246",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sarvoday Kendra ",
   "PINCODE": "383355",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shamlaji ",
   "PINCODE": "383355",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sunokh ",
   "PINCODE": "383250",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sunsar ",
   "PINCODE": "383450",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Takatuka ",
   "PINCODE": "383246",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Torda ",
   "PINCODE": "383246",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ubsal ",
   "PINCODE": "383246",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vagheswari ",
   "PINCODE": "383450",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vandhiyol ",
   "PINCODE": "383250",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vankaner ",
   "PINCODE": "383245",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vanzar ",
   "PINCODE": "383250",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vejpur ",
   "PINCODE": "383245",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Virpur ",
   "PINCODE": "383246",
   "TALUKA": "Bhiloda",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Akrund ",
   "PINCODE": "383260",
   "TALUKA": "Dhansura",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambasar ",
   "PINCODE": "383307",
   "TALUKA": "Dhansura",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amodara ",
   "PINCODE": "383310",
   "TALUKA": "Dhansura",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Barnoli ",
   "PINCODE": "383335",
   "TALUKA": "Dhansura",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhensawada ",
   "PINCODE": "383310",
   "TALUKA": "Dhansura",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bilwania ",
   "PINCODE": "383310",
   "TALUKA": "Dhansura",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Borditimba ",
   "PINCODE": "383260",
   "TALUKA": "Dhansura",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Butal ",
   "PINCODE": "383310",
   "TALUKA": "Dhansura",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhamania ",
   "PINCODE": "383310",
   "TALUKA": "Dhansura",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhansura ",
   "PINCODE": "383310",
   "TALUKA": "Dhansura",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dolpur ",
   "PINCODE": "383310",
   "TALUKA": "Dhansura",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hirapur ",
   "PINCODE": "383310",
   "TALUKA": "Dhansura",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jasvantpura Kampa ",
   "PINCODE": "383310",
   "TALUKA": "Dhansura",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khadoda ",
   "PINCODE": "383310",
   "TALUKA": "Dhansura",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khadol ",
   "PINCODE": "383310",
   "TALUKA": "Dhansura",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khilodia ",
   "PINCODE": "383307",
   "TALUKA": "Dhansura",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kidi ",
   "PINCODE": "383310",
   "TALUKA": "Dhansura",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kolvada ",
   "PINCODE": "383310",
   "TALUKA": "Dhansura",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lalinomath ",
   "PINCODE": "383307",
   "TALUKA": "Dhansura",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Naranpura Kampa ",
   "PINCODE": "383310",
   "TALUKA": "Dhansura",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navi Shinol ",
   "PINCODE": "383310",
   "TALUKA": "Dhansura",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajpur ",
   "PINCODE": "383307",
   "TALUKA": "Dhansura",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ramos ",
   "PINCODE": "383316",
   "TALUKA": "Dhansura",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rampura Kampa ",
   "PINCODE": "383330",
   "TALUKA": "Dhansura",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rampura Kampa ",
   "PINCODE": "383260",
   "TALUKA": "Dhansura",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shantipura ",
   "PINCODE": "383310",
   "TALUKA": "Dhansura",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shinol ",
   "PINCODE": "383310",
   "TALUKA": "Dhansura",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sika ",
   "PINCODE": "383310",
   "TALUKA": "Dhansura",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ujleshvar ",
   "PINCODE": "383310",
   "TALUKA": "Dhansura",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadagam ",
   "PINCODE": "383307",
   "TALUKA": "Dhansura",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shravana ",
   "PINCODE": "383030",
   "TALUKA": "Himatanagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Adpodra ",
   "PINCODE": "383276",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Agiol ",
   "PINCODE": "383001",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bankhor ",
   "PINCODE": "383240",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bavsar ",
   "PINCODE": "383001",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Berna ",
   "PINCODE": "383001",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Boria ",
   "PINCODE": "383006",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chandarni ",
   "PINCODE": "383001",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dedhrota ",
   "PINCODE": "383220",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Derol ",
   "PINCODE": "383220",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhundhar ",
   "PINCODE": "383030",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gadha ",
   "PINCODE": "383010",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gadhoda ",
   "PINCODE": "383001",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gambhoi ",
   "PINCODE": "383030",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hadiol ",
   "PINCODE": "383001",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hajipur ",
   "PINCODE": "383120",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hajipura ",
   "PINCODE": "383001",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hapa ",
   "PINCODE": "383001",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hathrol ",
   "PINCODE": "383030",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Himatnagar H.O",
   "PINCODE": "383001",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Himatnagar Station Road ",
   "PINCODE": "383001",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hunj ",
   "PINCODE": "383240",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ilol ",
   "PINCODE": "383220",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jambudi ",
   "PINCODE": "383001",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jamla ",
   "PINCODE": "383010",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kadoli ",
   "PINCODE": "383220",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kanai ",
   "PINCODE": "383220",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kanda ",
   "PINCODE": "383220",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kankrol ",
   "PINCODE": "383001",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karanpur ",
   "PINCODE": "383030",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Katwad ",
   "PINCODE": "383001",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khed ",
   "PINCODE": "383001",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khedavada ",
   "PINCODE": "383220",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Likhi ",
   "PINCODE": "383010",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lolasan ",
   "PINCODE": "383010",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Manorpur ",
   "PINCODE": "383030",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mathasulia ",
   "PINCODE": "383276",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mehtapura ",
   "PINCODE": "383001",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nava ",
   "PINCODE": "383001",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navalpur ",
   "PINCODE": "383001",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navanagar ",
   "PINCODE": "383220",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nikoda ",
   "PINCODE": "383210",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pedhmala ",
   "PINCODE": "383030",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pethapur ",
   "PINCODE": "383225",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Prempur ",
   "PINCODE": "383225",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pural ",
   "PINCODE": "383001",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Raigadh ",
   "PINCODE": "383276",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajpur ",
   "PINCODE": "383010",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rampur (A) ",
   "PINCODE": "383210",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rupal ",
   "PINCODE": "383030",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sachodar ",
   "PINCODE": "383110",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sadha ",
   "PINCODE": "383030",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sahebapura ",
   "PINCODE": "383001",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Savgadh ",
   "PINCODE": "383220",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tajpuri ",
   "PINCODE": "383001",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vagdi ",
   "PINCODE": "383276",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vaktapur ",
   "PINCODE": "383010",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vavdi ",
   "PINCODE": "383030",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Viravada ",
   "PINCODE": "383001",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Virpur ",
   "PINCODE": "383010",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vishwamangalam ",
   "PINCODE": "383001",
   "TALUKA": "Himatnagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kaniol ",
   "PINCODE": "383010",
   "TALUKA": "Himatnagar.",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ankala ",
   "PINCODE": "383410",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Aroda ",
   "PINCODE": "383110",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Arsodia ",
   "PINCODE": "383225",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Badol ",
   "PINCODE": "383434",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Badoli ",
   "PINCODE": "383410",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Barvav ",
   "PINCODE": "383430",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhadresar ",
   "PINCODE": "383110",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhanpur ",
   "PINCODE": "383410",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhutiya ",
   "PINCODE": "383440",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bolundra (S) ",
   "PINCODE": "383230",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bolundra(R) ",
   "PINCODE": "383421",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Budheli ",
   "PINCODE": "383230",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chadasana ",
   "PINCODE": "383110",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chandap ",
   "PINCODE": "383434",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chhapi ",
   "PINCODE": "383230",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chitroda ",
   "PINCODE": "383421",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Daramali ",
   "PINCODE": "383110",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Davad ",
   "PINCODE": "383225",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Deshotar ",
   "PINCODE": "383230",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dharapur ",
   "PINCODE": "383421",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Diyoli ",
   "PINCODE": "383410",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dungri ",
   "PINCODE": "383110",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Eklara ",
   "PINCODE": "383225",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Falasan ",
   "PINCODE": "383230",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Finchod ",
   "PINCODE": "383230",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gambhirpura ",
   "PINCODE": "383430",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ganthiol ",
   "PINCODE": "383410",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Golwada ",
   "PINCODE": "383434",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Goral ",
   "PINCODE": "383410",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gulabpura ",
   "PINCODE": "383434",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Himatpur ",
   "PINCODE": "383010",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Idar ",
   "PINCODE": "383430",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Idar Town ",
   "PINCODE": "383430",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jadar ",
   "PINCODE": "383110",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kabso ",
   "PINCODE": "383225",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kadiadra ",
   "PINCODE": "383440",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kamalpur ",
   "PINCODE": "383434",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kanpur ",
   "PINCODE": "383450",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kapoda ",
   "PINCODE": "383010",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kava ",
   "PINCODE": "383434",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kesharpura ",
   "PINCODE": "383230",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kotda Nana ",
   "PINCODE": "383110",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kukadia ",
   "PINCODE": "383410",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Laloda ",
   "PINCODE": "383430",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lalpur ",
   "PINCODE": "383410",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lei ",
   "PINCODE": "383430",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Limbhoi ",
   "PINCODE": "383430",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mangadh ",
   "PINCODE": "383110",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Maniyor ",
   "PINCODE": "383230",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Masal ",
   "PINCODE": "383230",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mathasur ",
   "PINCODE": "383430",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mesan ",
   "PINCODE": "383450",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mota Kotda ",
   "PINCODE": "383421",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mudeti ",
   "PINCODE": "383450",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nava Revas ",
   "PINCODE": "383450",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Netramali ",
   "PINCODE": "383430",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Oda ",
   "PINCODE": "383230",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panol ",
   "PINCODE": "383430",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Poshina ",
   "PINCODE": "383421",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pratappura ",
   "PINCODE": "383430",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ratanpur ",
   "PINCODE": "383430",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ravol ",
   "PINCODE": "383434",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rudardi ",
   "PINCODE": "383110",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sabalwad ",
   "PINCODE": "383430",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sabli ",
   "PINCODE": "383421",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sapawada ",
   "PINCODE": "383430",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sherpur ",
   "PINCODE": "383410",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Singa ",
   "PINCODE": "383225",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Siyasan ",
   "PINCODE": "383450",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Surpur ",
   "PINCODE": "383430",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umedgadh ",
   "PINCODE": "383230",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umedpura ",
   "PINCODE": "383430",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasai ",
   "PINCODE": "383450",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Verabar ",
   "PINCODE": "383434",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Virpur ",
   "PINCODE": "383230",
   "TALUKA": "Idar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Agiya ",
   "PINCODE": "383270",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ajavas ",
   "PINCODE": "383422",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambaigadha ",
   "PINCODE": "383270",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambamahuda ",
   "PINCODE": "383422",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bahediya ",
   "PINCODE": "383255",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bandiyana Talav ",
   "PINCODE": "383270",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bordi ",
   "PINCODE": "383255",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chandrana ",
   "PINCODE": "383422",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chikhala ",
   "PINCODE": "383270",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Damavas ",
   "PINCODE": "383275",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dan Mahudi ",
   "PINCODE": "383270",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dantral ",
   "PINCODE": "383422",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Delwada ",
   "PINCODE": "383422",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Delwada ",
   "PINCODE": "383255",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Demti ",
   "PINCODE": "383270",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dharoi ",
   "PINCODE": "383255",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Didhiya ",
   "PINCODE": "383255",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dotad ",
   "PINCODE": "383270",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gadhada Shamlaji ",
   "PINCODE": "383270",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gadu ",
   "PINCODE": "383235",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Galodiya ",
   "PINCODE": "383275",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ganer ",
   "PINCODE": "383422",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ganva ",
   "PINCODE": "383422",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gundel ",
   "PINCODE": "383270",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kalikankar ",
   "PINCODE": "383422",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kalol Kampa ",
   "PINCODE": "383275",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khedbrahma ",
   "PINCODE": "383255",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khedva ",
   "PINCODE": "383255",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khergadh ",
   "PINCODE": "383275",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kheroj ",
   "PINCODE": "383270",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kotda ",
   "PINCODE": "383422",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lambadiya ",
   "PINCODE": "383270",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Laxmipura ",
   "PINCODE": "383275",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Matoda ",
   "PINCODE": "383270",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mota Baval ",
   "PINCODE": "383270",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nada ",
   "PINCODE": "383270",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nana Sembalia ",
   "PINCODE": "383270",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nava Mota ",
   "PINCODE": "383270",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navi Metral ",
   "PINCODE": "383270",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nichi Dhanal ",
   "PINCODE": "383255",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Padardi ",
   "PINCODE": "383255",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Padhara ",
   "PINCODE": "383255",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panch Mahuda ",
   "PINCODE": "383270",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Paroya ",
   "PINCODE": "383255",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Patadiya ",
   "PINCODE": "383270",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Petachhapra ",
   "PINCODE": "383422",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pipliya ",
   "PINCODE": "383422",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Poshina ",
   "PINCODE": "383422",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Radhiwad ",
   "PINCODE": "383270",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ratanpur ",
   "PINCODE": "383270",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Salera ",
   "PINCODE": "383422",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sembalia (Poshina) ",
   "PINCODE": "383422",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sitol ",
   "PINCODE": "383255",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tadhivedi ",
   "PINCODE": "383422",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tandaliya ",
   "PINCODE": "383275",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tembada ",
   "PINCODE": "383270",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Unchi Dhanal ",
   "PINCODE": "383270",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vaghela Derol ",
   "PINCODE": "383275",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Valaran ",
   "PINCODE": "383255",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vartol ",
   "PINCODE": "383255",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasana ",
   "PINCODE": "383255",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vinchhi ",
   "PINCODE": "383422",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zanzva Panai ",
   "PINCODE": "383270",
   "TALUKA": "Khedbrahma",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambalia ",
   "PINCODE": "383345",
   "TALUKA": "Malpur",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Aniyor ",
   "PINCODE": "383345",
   "TALUKA": "Malpur",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Aniyor Kampa ",
   "PINCODE": "383345",
   "TALUKA": "Malpur",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhempoda ",
   "PINCODE": "383335",
   "TALUKA": "Malpur",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Helodar ",
   "PINCODE": "383345",
   "TALUKA": "Malpur",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kaswada ",
   "PINCODE": "383345",
   "TALUKA": "Malpur",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khalikpur ",
   "PINCODE": "383335",
   "TALUKA": "Malpur",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Magodi ",
   "PINCODE": "383335",
   "TALUKA": "Malpur",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mahiyapur ",
   "PINCODE": "383345",
   "TALUKA": "Malpur",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Malpur ",
   "PINCODE": "383345",
   "TALUKA": "Malpur",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mangalpur ",
   "PINCODE": "383345",
   "TALUKA": "Malpur",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mevda ",
   "PINCODE": "383315",
   "TALUKA": "Malpur",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nanawada ",
   "PINCODE": "383345",
   "TALUKA": "Malpur",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nathavas ",
   "PINCODE": "383315",
   "TALUKA": "Malpur",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Piprana ",
   "PINCODE": "383345",
   "TALUKA": "Malpur",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Satarda ",
   "PINCODE": "383345",
   "TALUKA": "Malpur",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tunadar ",
   "PINCODE": "383335",
   "TALUKA": "Malpur",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ubharan ",
   "PINCODE": "383335",
   "TALUKA": "Malpur",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vankaneda ",
   "PINCODE": "383335",
   "TALUKA": "Malpur",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vavdi ",
   "PINCODE": "383345",
   "TALUKA": "Malpur",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Banthiwada ",
   "PINCODE": "383350",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Behdaj ",
   "PINCODE": "383350",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Belyo ",
   "PINCODE": "383350",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhemapur ",
   "PINCODE": "383350",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Intva ",
   "PINCODE": "383251",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Iploda ",
   "PINCODE": "383350",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Isari ",
   "PINCODE": "383251",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kadvadi ",
   "PINCODE": "383350",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kaliya Kuva ",
   "PINCODE": "383350",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kasana ",
   "PINCODE": "383350",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kolundra ",
   "PINCODE": "383350",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kunol ",
   "PINCODE": "383350",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lalpur ",
   "PINCODE": "383350",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Limbodara ",
   "PINCODE": "383350",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Meghraj ",
   "PINCODE": "383350",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moti Mori ",
   "PINCODE": "383350",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moti Moydi ",
   "PINCODE": "383350",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moti Panduri ",
   "PINCODE": "383350",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navagam(Isri) ",
   "PINCODE": "383251",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panchal ",
   "PINCODE": "383350",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panibar ",
   "PINCODE": "383251",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Patelna Dhundha ",
   "PINCODE": "383350",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ramgadhi ",
   "PINCODE": "383350",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rayawada ",
   "PINCODE": "383350",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rellawada ",
   "PINCODE": "383251",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Relyo ",
   "PINCODE": "383350",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shangal ",
   "PINCODE": "383350",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sisodara (A) ",
   "PINCODE": "383350",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Undava ",
   "PINCODE": "383350",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vaghpur ",
   "PINCODE": "383350",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vaghpur ",
   "PINCODE": "383251",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Valuna ",
   "PINCODE": "383350",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vaniawada ",
   "PINCODE": "383350",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasna ",
   "PINCODE": "383350",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zarda ",
   "PINCODE": "383350",
   "TALUKA": "Meghraj",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Adhera ",
   "PINCODE": "383250",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amlai ",
   "PINCODE": "383315",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Badodara ",
   "PINCODE": "383315",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bamanvad ",
   "PINCODE": "383250",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bayal Dhankhrol ",
   "PINCODE": "383316",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhachediya ",
   "PINCODE": "383316",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhavanpura Kampa ",
   "PINCODE": "383316",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bherunda ",
   "PINCODE": "383315",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bolundra ",
   "PINCODE": "383250",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dadhalia ",
   "PINCODE": "383317",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Davli ",
   "PINCODE": "383320",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dugarvada ",
   "PINCODE": "383315",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Faredi ",
   "PINCODE": "383345",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gadha ",
   "PINCODE": "383316",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gadhada ",
   "PINCODE": "383320",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gajan ",
   "PINCODE": "383315",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ganeshpur ",
   "PINCODE": "383315",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Itadi ",
   "PINCODE": "383316",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jhalodar ",
   "PINCODE": "383315",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kau ",
   "PINCODE": "383315",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khambhisar ",
   "PINCODE": "383276",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kolikhad ",
   "PINCODE": "383315",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kudol ",
   "PINCODE": "383250",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Limbhoi ",
   "PINCODE": "383316",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Madapur Kampa ",
   "PINCODE": "383315",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mahadevgram ",
   "PINCODE": "383317",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mahadevpura Kampa ",
   "PINCODE": "383315",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Medhasan ",
   "PINCODE": "383276",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Modas ",
   "PINCODE": "383315",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Modasa Bazar ",
   "PINCODE": "383315",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moti Chinchano ",
   "PINCODE": "383316",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moti Isrol ",
   "PINCODE": "383317",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Muloj ",
   "PINCODE": "383315",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nandisan ",
   "PINCODE": "383250",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pahadpur ",
   "PINCODE": "383315",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rakhiyal ",
   "PINCODE": "383276",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ramana ",
   "PINCODE": "383315",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sakariya ",
   "PINCODE": "383315",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sardoi ",
   "PINCODE": "383320",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sayra ",
   "PINCODE": "383315",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shampur ",
   "PINCODE": "383320",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shinavad ",
   "PINCODE": "383315",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tintoi ",
   "PINCODE": "383250",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vaniad Kokapur ",
   "PINCODE": "383315",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Varthu ",
   "PINCODE": "383317",
   "TALUKA": "Modasa",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambawada ",
   "PINCODE": "383210",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amrapur ",
   "PINCODE": "383215",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Balisana ",
   "PINCODE": "383205",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bobha ",
   "PINCODE": "383205",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dalani Muvadi ",
   "PINCODE": "383205",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dalpur ",
   "PINCODE": "383120",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Fatepur Mota ",
   "PINCODE": "383210",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghadi ",
   "PINCODE": "383215",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghadkan ",
   "PINCODE": "383205",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jenpur ",
   "PINCODE": "383205",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kamalpur ",
   "PINCODE": "383205",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karol ",
   "PINCODE": "383205",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mahadevpura ",
   "PINCODE": "383210",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Majra ",
   "PINCODE": "383205",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mauchha ",
   "PINCODE": "383210",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moyad ",
   "PINCODE": "383120",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nananpur ",
   "PINCODE": "383210",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Oran ",
   "PINCODE": "383205",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pallachar ",
   "PINCODE": "383205",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Piludra ",
   "PINCODE": "383120",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Poglu ",
   "PINCODE": "383205",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Poyda ",
   "PINCODE": "383215",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Prantij ",
   "PINCODE": "383205",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Salal ",
   "PINCODE": "383120",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sampad ",
   "PINCODE": "383120",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sitwada ",
   "PINCODE": "383205",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sonasan ",
   "PINCODE": "383210",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tajpur ",
   "PINCODE": "383205",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Takhatgadh ",
   "PINCODE": "383210",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Unchha ",
   "PINCODE": "383205",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadrad ",
   "PINCODE": "383205",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadvasa ",
   "PINCODE": "383205",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vaghpur ",
   "PINCODE": "383205",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vaghrota ",
   "PINCODE": "383210",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zinzva ",
   "PINCODE": "383210",
   "TALUKA": "Prantij",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Aniod ",
   "PINCODE": "383305",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Antroli ",
   "PINCODE": "383305",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Badodara ",
   "PINCODE": "383305",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Boria Bechraji ",
   "PINCODE": "383215",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dadarda ",
   "PINCODE": "383305",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Doltabad ",
   "PINCODE": "383215",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gora Anjana ",
   "PINCODE": "383215",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Harsol ",
   "PINCODE": "383305",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jorajini Muvadi ",
   "PINCODE": "383215",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kabodara ",
   "PINCODE": "383305",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kherol ",
   "PINCODE": "383215",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lavari ",
   "PINCODE": "383305",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Madhavgadh ",
   "PINCODE": "383305",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mahiyal ",
   "PINCODE": "383215",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Modhuka ",
   "PINCODE": "383305",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mohanpur ",
   "PINCODE": "383305",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mota Chekhla ",
   "PINCODE": "383305",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Motesari ",
   "PINCODE": "383305",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mudhasana ",
   "PINCODE": "383215",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nana Chekhla ",
   "PINCODE": "383305",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nava ",
   "PINCODE": "383305",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Padusan ",
   "PINCODE": "383305",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Punsari ",
   "PINCODE": "383307",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ranasan ",
   "PINCODE": "383305",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ranipura ",
   "PINCODE": "383307",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sagpur ",
   "PINCODE": "383307",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Salatpur ",
   "PINCODE": "383215",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Semalia ",
   "PINCODE": "383215",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tajpur (Camp) ",
   "PINCODE": "383305",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Talod M Y ",
   "PINCODE": "383215",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Talod ",
   "PINCODE": "383215",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ujedia ",
   "PINCODE": "383215",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Valiampura ",
   "PINCODE": "383215",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Varvada ",
   "PINCODE": "383305",
   "TALUKA": "Talod",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Asai ",
   "PINCODE": "383235",
   "TALUKA": "Vadali",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Babsar ",
   "PINCODE": "383235",
   "TALUKA": "Vadali",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhandval ",
   "PINCODE": "383235",
   "TALUKA": "Vadali",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhavangadh ",
   "PINCODE": "383430",
   "TALUKA": "Vadali",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Choriwad ",
   "PINCODE": "383440",
   "TALUKA": "Vadali",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chulla ",
   "PINCODE": "383440",
   "TALUKA": "Vadali",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dantroli ",
   "PINCODE": "383235",
   "TALUKA": "Vadali",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhamadi (Gadu) ",
   "PINCODE": "383235",
   "TALUKA": "Vadali",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dobhada ",
   "PINCODE": "383235",
   "TALUKA": "Vadali",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gajipur ",
   "PINCODE": "383434",
   "TALUKA": "Vadali",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gota ",
   "PINCODE": "383255",
   "TALUKA": "Vadali",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hatharva ",
   "PINCODE": "383235",
   "TALUKA": "Vadali",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hathoj ",
   "PINCODE": "383235",
   "TALUKA": "Vadali",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Juna Chamu ",
   "PINCODE": "383440",
   "TALUKA": "Vadali",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kesharganj ",
   "PINCODE": "383235",
   "TALUKA": "Vadali",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kuba Dharol ",
   "PINCODE": "383235",
   "TALUKA": "Vadali",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mahor ",
   "PINCODE": "383235",
   "TALUKA": "Vadali",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Medh ",
   "PINCODE": "383235",
   "TALUKA": "Vadali",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nadri ",
   "PINCODE": "383235",
   "TALUKA": "Vadali",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Raheda ",
   "PINCODE": "383235",
   "TALUKA": "Vadali",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rampur (Fudeda) ",
   "PINCODE": "383434",
   "TALUKA": "Vadali",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Therasana ",
   "PINCODE": "383235",
   "TALUKA": "Vadali",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadali ",
   "PINCODE": "383235",
   "TALUKA": "Vadali",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadoth ",
   "PINCODE": "383235",
   "TALUKA": "Vadali",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasan ",
   "PINCODE": "383235",
   "TALUKA": "Vadali",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Abhapur ",
   "PINCODE": "383460",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Androkha ",
   "PINCODE": "383460",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Atarsumba ",
   "PINCODE": "383460",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Baleta ",
   "PINCODE": "383462",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhankhara ",
   "PINCODE": "383460",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Biladia ",
   "PINCODE": "383462",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chamthan ",
   "PINCODE": "383246",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chandvasa ",
   "PINCODE": "383460",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chitariya ",
   "PINCODE": "383462",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chithoda ",
   "PINCODE": "383462",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chitrodi ",
   "PINCODE": "383246",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dadhvav ",
   "PINCODE": "383462",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dantod ",
   "PINCODE": "383462",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gadi ",
   "PINCODE": "383462",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Itavadi ",
   "PINCODE": "383246",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jaleti ",
   "PINCODE": "383462",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kalvan ",
   "PINCODE": "383440",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kanadar ",
   "PINCODE": "383246",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kathvavdi ",
   "PINCODE": "383440",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kelava ",
   "PINCODE": "383460",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kodiawada ",
   "PINCODE": "383462",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Limda ",
   "PINCODE": "383462",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Masota ",
   "PINCODE": "383246",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nalseri ",
   "PINCODE": "383460",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navagam (Dhanela) ",
   "PINCODE": "383460",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Padela ",
   "PINCODE": "383460",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pal ",
   "PINCODE": "383462",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pratapgadh Kampa ",
   "PINCODE": "383440",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajpur ",
   "PINCODE": "383460",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Saroli ",
   "PINCODE": "383460",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sarsav ",
   "PINCODE": "383460",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ukhala Dungri ",
   "PINCODE": "383460",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vandhol ",
   "PINCODE": "383460",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vankda ",
   "PINCODE": "383462",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasai ",
   "PINCODE": "383460",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vijaynagar ",
   "PINCODE": "383460",
   "TALUKA": "Vijaynagar",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Parosada ",
   "PINCODE": "383460",
   "TALUKA": "Vijaynagar.",
   "DISTRICT": "SABARKANTHA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Athwalines ",
   "PINCODE": "395001",
   "TALUKA": ".",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bedchit ",
   "PINCODE": "394630",
   "TALUKA": ".",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhimpore ",
   "PINCODE": "394120",
   "TALUKA": ".",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhutwada ",
   "PINCODE": "394690",
   "TALUKA": ".",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dabholi ",
   "PINCODE": "395004",
   "TALUKA": ".",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhamkhadi ",
   "PINCODE": "394248",
   "TALUKA": ".",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dumasgam ",
   "PINCODE": "394120",
   "TALUKA": ".",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "G.I.P.C.L. ",
   "PINCODE": "394110",
   "TALUKA": ".",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gherivan ",
   "PINCODE": "394630",
   "TALUKA": ".",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gotalawadi ",
   "PINCODE": "395004",
   "TALUKA": ".",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kakadva ",
   "PINCODE": "394635",
   "TALUKA": ".",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kosam ",
   "PINCODE": "394520",
   "TALUKA": ".",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kosimda ",
   "PINCODE": "394715",
   "TALUKA": ".",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Motived ",
   "PINCODE": "395004",
   "TALUKA": ".",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nagod ",
   "PINCODE": "394320",
   "TALUKA": ".",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sachin G.I.D.C. ",
   "PINCODE": "394520",
   "TALUKA": ".",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sherdi ",
   "PINCODE": "394520",
   "TALUKA": ".",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Siganpore ",
   "PINCODE": "395004",
   "TALUKA": ".",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadi ",
   "PINCODE": "394440",
   "TALUKA": ".",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bardipada ",
   "PINCODE": "394715",
   "TALUKA": "AHWA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhalkhet ",
   "PINCODE": "394715",
   "TALUKA": "AHWA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chinchinagaontha ",
   "PINCODE": "394715",
   "TALUKA": "AHWA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kalibel ",
   "PINCODE": "394715",
   "TALUKA": "AHWA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khatal ",
   "PINCODE": "394715",
   "TALUKA": "AHWA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mahwshkatri ",
   "PINCODE": "394715",
   "TALUKA": "AHWA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sarovar ",
   "PINCODE": "394715",
   "TALUKA": "AHWA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Afva Isroli ",
   "PINCODE": "395620",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Akoti ",
   "PINCODE": "394355",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Allu ",
   "PINCODE": "395620",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bamni ",
   "PINCODE": "394335",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bardoli H.O",
   "PINCODE": "394601",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhamaiya ",
   "PINCODE": "394335",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chhitra ",
   "PINCODE": "394350",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhamdod Lumbha ",
   "PINCODE": "394355",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Goji ",
   "PINCODE": "394350",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Haripura ",
   "PINCODE": "394335",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kadod ",
   "PINCODE": "394335",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kantifalia ",
   "PINCODE": "394340",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kantifalia ",
   "PINCODE": "394340",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kharvasa ",
   "PINCODE": "394355",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khojpardi ",
   "PINCODE": "394355",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kikwad ",
   "PINCODE": "395620",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Madhi ",
   "PINCODE": "394340",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Manekpor ",
   "PINCODE": "394340",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Masad ",
   "PINCODE": "394335",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mota ",
   "PINCODE": "395345",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Motifalod ",
   "PINCODE": "394355",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Naugama ",
   "PINCODE": "394350",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ninat ",
   "PINCODE": "394350",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nizar ",
   "PINCODE": "394350",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Orgam ",
   "PINCODE": "394340",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Palsod ",
   "PINCODE": "394355",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rayam ",
   "PINCODE": "394355",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Samthan ",
   "PINCODE": "394335",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sarbhon ",
   "PINCODE": "394350",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sardarbaug (Bardoli) ",
   "PINCODE": "394601",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sejvad ",
   "PINCODE": "395620",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Singod ",
   "PINCODE": "394335",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sugar Factory Bardoli ",
   "PINCODE": "394601",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Surali ",
   "PINCODE": "394340",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tarbhon ",
   "PINCODE": "394350",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Timbarva Sankri ",
   "PINCODE": "394355",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umarakh ",
   "PINCODE": "395345",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Uva ",
   "PINCODE": "394340",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadhvania ",
   "PINCODE": "394335",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadoli ",
   "PINCODE": "394350",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vaghecha ",
   "PINCODE": "394355",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vankaner (SR) ",
   "PINCODE": "395620",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vanskui ",
   "PINCODE": "394340",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Varad ",
   "PINCODE": "394355",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vatsalyadham ",
   "PINCODE": "394340",
   "TALUKA": "BARDOLI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chapra Bhatha ",
   "PINCODE": "394107",
   "TALUKA": "chorayasi",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Fulpada ",
   "PINCODE": "395008",
   "TALUKA": "chorayasi",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kosad ",
   "PINCODE": "394107",
   "TALUKA": "chorayasi",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Adityanagar ",
   "PINCODE": "394516",
   "TALUKA": "CHORYASI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amroli ",
   "PINCODE": "394107",
   "TALUKA": "CHORYASI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhatha ",
   "PINCODE": "394510",
   "TALUKA": "CHORYASI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhatpore ",
   "PINCODE": "394510",
   "TALUKA": "CHORYASI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhedvad ",
   "PINCODE": "394220",
   "TALUKA": "Choryasi",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Damka ",
   "PINCODE": "394510",
   "TALUKA": "CHORYASI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dumas ",
   "PINCODE": "394120",
   "TALUKA": "CHORYASI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Godadara ",
   "PINCODE": "395010",
   "TALUKA": "Choryasi",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ichhapore ",
   "PINCODE": "394510",
   "TALUKA": "CHORYASI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kawas ",
   "PINCODE": "394510",
   "TALUKA": "CHORYASI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kribhconagar ",
   "PINCODE": "394515",
   "TALUKA": "CHORYASI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kumabharia ",
   "PINCODE": "395010",
   "TALUKA": "Choryasi",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Limbayat ",
   "PINCODE": "394210",
   "TALUKA": "CHORYASI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mohni ",
   "PINCODE": "394305",
   "TALUKA": "CHORYASI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mora ",
   "PINCODE": "394510",
   "TALUKA": "CHORYASI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mota Varachha ",
   "PINCODE": "394101",
   "TALUKA": "CHORYASI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ongc Nagar ",
   "PINCODE": "394518",
   "TALUKA": "CHORYASI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pal Bhatha ",
   "PINCODE": "394510",
   "TALUKA": "CHORYASI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Parvat ",
   "PINCODE": "395010",
   "TALUKA": "Choryasi",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Samrod ",
   "PINCODE": "394315",
   "TALUKA": "CHORYASI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Saroli ",
   "PINCODE": "395010",
   "TALUKA": "Choryasi",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Suvali ",
   "PINCODE": "394510",
   "TALUKA": "CHORYASI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Timbarva ",
   "PINCODE": "394305",
   "TALUKA": "CHORYASI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasava ",
   "PINCODE": "394510",
   "TALUKA": "CHORYASI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pipaldahad ",
   "PINCODE": "394716",
   "TALUKA": "DANG",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Centrap Pulp Mill ",
   "PINCODE": "394660",
   "TALUKA": "FORT SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Fort Songadh ",
   "PINCODE": "394670",
   "TALUKA": "FORT SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Raniamba ",
   "PINCODE": "394365",
   "TALUKA": "FORT SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Abrama ",
   "PINCODE": "394150",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Antroli ",
   "PINCODE": "394150",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Asta ",
   "PINCODE": "394320",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chikhali Dungar ",
   "PINCODE": "394320",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Delad ",
   "PINCODE": "394330",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhatva ",
   "PINCODE": "394180",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhoranpardi ",
   "PINCODE": "394150",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Digas ",
   "PINCODE": "394330",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dungra ",
   "PINCODE": "394180",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghala ",
   "PINCODE": "394155",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Haldharu ",
   "PINCODE": "394310",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jokha ",
   "PINCODE": "394326",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kamrej Char Rasta ",
   "PINCODE": "394185",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kamrej ",
   "PINCODE": "394180",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karjan ",
   "PINCODE": "394155",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kathodara ",
   "PINCODE": "394326",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kathor ",
   "PINCODE": "394150",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khanpur ",
   "PINCODE": "394320",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kholeshwar ",
   "PINCODE": "394180",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kholvad ",
   "PINCODE": "394190",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kosmadi ",
   "PINCODE": "394326",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ladvi ",
   "PINCODE": "394325",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mankna ",
   "PINCODE": "394325",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Morthana ",
   "PINCODE": "394325",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nansad ",
   "PINCODE": "394180",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navagam ",
   "PINCODE": "394185",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navipardi ",
   "PINCODE": "394150",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Netrang ",
   "PINCODE": "394180",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Orna ",
   "PINCODE": "394330",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Parab ",
   "PINCODE": "394325",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Segva ",
   "PINCODE": "394320",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sevni ",
   "PINCODE": "394320",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shampura ",
   "PINCODE": "394330",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Timba ",
   "PINCODE": "394330",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umbhel ",
   "PINCODE": "394325",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vav Kathodara ",
   "PINCODE": "394326",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Velanja ",
   "PINCODE": "394150",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vihan ",
   "PINCODE": "394320",
   "TALUKA": "KAMREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kachholi ",
   "PINCODE": "394235",
   "TALUKA": "LAJPORE",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kafleta ",
   "PINCODE": "394235",
   "TALUKA": "LAJPORE",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Popda ",
   "PINCODE": "394235",
   "TALUKA": "LAJPORE",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhamdod ",
   "PINCODE": "394125",
   "TALUKA": "M.M.MANGROL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dinod ",
   "PINCODE": "394125",
   "TALUKA": "M.M.MANGROL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hathuran ",
   "PINCODE": "394125",
   "TALUKA": "M.M.MANGROL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mahuvej ",
   "PINCODE": "394125",
   "TALUKA": "M.M.MANGROL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nandav ",
   "PINCODE": "394125",
   "TALUKA": "M.M.MANGROL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amchak ",
   "PINCODE": "394250",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Anaval ",
   "PINCODE": "396510",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bartad ",
   "PINCODE": "394240",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhagvanpura ",
   "PINCODE": "394246",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhoria ",
   "PINCODE": "394248",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bilkhadi ",
   "PINCODE": "394250",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Butwada ",
   "PINCODE": "394248",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dedvasan ",
   "PINCODE": "394250",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dholikui ",
   "PINCODE": "394250",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dungri ",
   "PINCODE": "394240",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gangadia ",
   "PINCODE": "396510",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghadoi ",
   "PINCODE": "394245",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gunesvel ",
   "PINCODE": "394240",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Haladva ",
   "PINCODE": "394248",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kadhaiya ",
   "PINCODE": "394246",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kani ",
   "PINCODE": "394350",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kankaria ",
   "PINCODE": "394248",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karachka ",
   "PINCODE": "394340",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karchelia ",
   "PINCODE": "394240",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kharvan ",
   "PINCODE": "394245",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kodada ",
   "PINCODE": "394250",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kos ",
   "PINCODE": "396510",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kumkotar ",
   "PINCODE": "396510",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lasanpor ",
   "PINCODE": "396510",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mahuva ",
   "PINCODE": "394250",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mahuvaria ",
   "PINCODE": "394248",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Miyapur ",
   "PINCODE": "394250",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mordevi ",
   "PINCODE": "394250",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Naldhara ",
   "PINCODE": "394240",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pathran ",
   "PINCODE": "395620",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Puna ",
   "PINCODE": "394248",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ranat ",
   "PINCODE": "394350",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Samba ",
   "PINCODE": "394248",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shekhpur ",
   "PINCODE": "394250",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sugar Factory Bamania ",
   "PINCODE": "394246",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tarsadi ",
   "PINCODE": "394350",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umra ",
   "PINCODE": "394248",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadia ",
   "PINCODE": "394246",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vaheval ",
   "PINCODE": "394248",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Valvada ",
   "PINCODE": "394248",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vanskui ",
   "PINCODE": "394240",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Velanpur ",
   "PINCODE": "394245",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zervavra ",
   "PINCODE": "394245",
   "TALUKA": "MAHUVA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kolibharthana ",
   "PINCODE": "394180",
   "TALUKA": "MAKREJ",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amba ",
   "PINCODE": "394163",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Balda ",
   "PINCODE": "394340",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bodhan ",
   "PINCODE": "394140",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dadhwada ",
   "PINCODE": "394160",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Fulwadi ",
   "PINCODE": "394160",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gamtalv Bujrang ",
   "PINCODE": "394163",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gavachhi ",
   "PINCODE": "394140",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghantoli ",
   "PINCODE": "394160",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Godawadi ",
   "PINCODE": "394163",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Goddha ",
   "PINCODE": "394160",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Godsamba ",
   "PINCODE": "394163",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jakhala ",
   "PINCODE": "394160",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jamankuva ",
   "PINCODE": "394160",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kakarapargam ",
   "PINCODE": "394160",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kakrapar ",
   "PINCODE": "394360",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kamlapore ",
   "PINCODE": "394335",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karvali ",
   "PINCODE": "394163",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kasal ",
   "PINCODE": "394163",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khanjroli ",
   "PINCODE": "394335",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kharoli ",
   "PINCODE": "394163",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khodamba ",
   "PINCODE": "394163",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kim Dungara ",
   "PINCODE": "394160",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kosadi ",
   "PINCODE": "394335",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lakhgam ",
   "PINCODE": "394160",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mandvi SR ",
   "PINCODE": "394160",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moritha ",
   "PINCODE": "394160",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moticheir ",
   "PINCODE": "394651",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Munjlav ",
   "PINCODE": "394140",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nandpore ",
   "PINCODE": "394163",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Naren ",
   "PINCODE": "394163",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Patal ",
   "PINCODE": "394163",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Puna ",
   "PINCODE": "394163",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ratania ",
   "PINCODE": "394360",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Regama ",
   "PINCODE": "394160",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Roswad ",
   "PINCODE": "394170",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rupan ",
   "PINCODE": "394160",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Salaiya ",
   "PINCODE": "394160",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sarkui ",
   "PINCODE": "394160",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sathvav ",
   "PINCODE": "394160",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tadkeshwar ",
   "PINCODE": "394170",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tarsada ",
   "PINCODE": "394160",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tuked ",
   "PINCODE": "394163",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Unteva ",
   "PINCODE": "394163",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vareli ",
   "PINCODE": "394140",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vareth ",
   "PINCODE": "394160",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Virpur ",
   "PINCODE": "394155",
   "TALUKA": "MANDVI",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ankodod ",
   "PINCODE": "394410",
   "TALUKA": "MANGROL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gijram ",
   "PINCODE": "394410",
   "TALUKA": "MANGROL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mota Miya Mangrol ",
   "PINCODE": "394410",
   "TALUKA": "MANGROL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amoda ",
   "PINCODE": "394380",
   "TALUKA": "NIJHAR",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Balde ",
   "PINCODE": "394380",
   "TALUKA": "NIJHAR",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhljamboli ",
   "PINCODE": "394370",
   "TALUKA": "NIJHAR",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bortha ",
   "PINCODE": "394370",
   "TALUKA": "NIJHAR",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chirmati ",
   "PINCODE": "394380",
   "TALUKA": "NIJHAR",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chokhiamli ",
   "PINCODE": "394380",
   "TALUKA": "NIJHAR",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gangtha ",
   "PINCODE": "394380",
   "TALUKA": "NIJHAR",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gujarpur ",
   "PINCODE": "394370",
   "TALUKA": "NIJHAR",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hathoda ",
   "PINCODE": "394380",
   "TALUKA": "NIJHAR",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Itwai ",
   "PINCODE": "394380",
   "TALUKA": "NIJHAR",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khorda ",
   "PINCODE": "394370",
   "TALUKA": "NIJHAR",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kukurmunda ",
   "PINCODE": "394380",
   "TALUKA": "NIJHAR",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Laxmikheda ",
   "PINCODE": "394370",
   "TALUKA": "NIJHAR",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mataval ",
   "PINCODE": "394380",
   "TALUKA": "NIJHAR",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moramba ",
   "PINCODE": "394380",
   "TALUKA": "NIJHAR",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mubarakpur ",
   "PINCODE": "394370",
   "TALUKA": "NIJHAR",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nijhar ",
   "PINCODE": "394370",
   "TALUKA": "NIJHAR",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nimbhora ",
   "PINCODE": "394380",
   "TALUKA": "NIJHAR",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Phulwadi ",
   "PINCODE": "394380",
   "TALUKA": "NIJHAR",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Piplod ",
   "PINCODE": "394370",
   "TALUKA": "NIJHAR",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pisavar ",
   "PINCODE": "394380",
   "TALUKA": "NIJHAR",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Raigadh ",
   "PINCODE": "394370",
   "TALUKA": "NIJHAR",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rumkitalav ",
   "PINCODE": "394370",
   "TALUKA": "NIJHAR",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sadgavan ",
   "PINCODE": "394380",
   "TALUKA": "NIJHAR",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sarvala ",
   "PINCODE": "394370",
   "TALUKA": "NIJHAR",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sayla ",
   "PINCODE": "394370",
   "TALUKA": "NIJHAR",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vanka ",
   "PINCODE": "394370",
   "TALUKA": "NIJHAR",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Veldha ",
   "PINCODE": "394370",
   "TALUKA": "NIJHAR",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vyaval ",
   "PINCODE": "394370",
   "TALUKA": "NIJHAR",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amalsadi ",
   "PINCODE": "394110",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Anita ",
   "PINCODE": "394110",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Antroli ",
   "PINCODE": "394110",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Areth ",
   "PINCODE": "394110",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Asnad ",
   "PINCODE": "394540",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhadol ",
   "PINCODE": "394540",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhagwa ",
   "PINCODE": "394530",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhatgam ",
   "PINCODE": "394540",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhilvada ",
   "PINCODE": "394421",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Borsad ",
   "PINCODE": "394110",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dandi ",
   "PINCODE": "394540",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Delasa ",
   "PINCODE": "394530",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhrampur ",
   "PINCODE": "394110",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dungri ",
   "PINCODE": "394110",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Erthan ",
   "PINCODE": "394540",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Fali ",
   "PINCODE": "394110",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Harsani ",
   "PINCODE": "394421",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ishanpore ",
   "PINCODE": "394540",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kadrama ",
   "PINCODE": "394540",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kamroli ",
   "PINCODE": "394540",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karanj ",
   "PINCODE": "394530",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karanj ",
   "PINCODE": "394110",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kim Char Rasta ",
   "PINCODE": "394111",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kim ",
   "PINCODE": "394110",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Koba ",
   "PINCODE": "394540",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kosamba Bazar ",
   "PINCODE": "394120",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kosamba ",
   "PINCODE": "394120",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kothwa ",
   "PINCODE": "394110",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kudiana ",
   "PINCODE": "394540",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kudsad ",
   "PINCODE": "394110",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kunvarda ",
   "PINCODE": "394120",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lavachha ",
   "PINCODE": "394540",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Limodra ",
   "PINCODE": "394110",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Madroi ",
   "PINCODE": "394540",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Masma ",
   "PINCODE": "394540",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mohamedpur ",
   "PINCODE": "394540",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mor ",
   "PINCODE": "394530",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mosali ",
   "PINCODE": "394421",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mota Borsara ",
   "PINCODE": "394110",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mulad ",
   "PINCODE": "394110",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nani Naroli ",
   "PINCODE": "394110",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nogama ",
   "PINCODE": "394110",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Olpad ",
   "PINCODE": "394540",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Orma ",
   "PINCODE": "394540",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pardi Bhadol ",
   "PINCODE": "394540",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pipodara ",
   "PINCODE": "394110",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Saras ",
   "PINCODE": "394540",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sava ",
   "PINCODE": "394120",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shah ",
   "PINCODE": "394421",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Siyalaj ",
   "PINCODE": "394110",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sondla Khara ",
   "PINCODE": "394540",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sonsak ",
   "PINCODE": "394540",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Takarma ",
   "PINCODE": "394540",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadod ",
   "PINCODE": "394540",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadoli ",
   "PINCODE": "394110",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Varethi ",
   "PINCODE": "394110",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasravi ",
   "PINCODE": "394421",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vegi ",
   "PINCODE": "394110",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vihara ",
   "PINCODE": "394540",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zab ",
   "PINCODE": "394110",
   "TALUKA": "OLPAD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amalsadi ",
   "PINCODE": "394350",
   "TALUKA": "PALSANA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambheti ",
   "PINCODE": "394352",
   "TALUKA": "PALSANA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Antroli ",
   "PINCODE": "394325",
   "TALUKA": "PALSANA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bagumara ",
   "PINCODE": "394305",
   "TALUKA": "PALSANA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Baleshwar ",
   "PINCODE": "394317",
   "TALUKA": "PALSANA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Barasado ",
   "PINCODE": "394310",
   "TALUKA": "PALSANA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chalthan ",
   "PINCODE": "394305",
   "TALUKA": "PALSANA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dastan ",
   "PINCODE": "394310",
   "TALUKA": "PALSANA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ena ",
   "PINCODE": "394310",
   "TALUKA": "PALSANA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gangadhara RS ",
   "PINCODE": "394310",
   "TALUKA": "PALSANA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Italva ",
   "PINCODE": "394315",
   "TALUKA": "PALSANA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jolwa ",
   "PINCODE": "394305",
   "TALUKA": "PALSANA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kadodara ",
   "PINCODE": "394327",
   "TALUKA": "PALSANA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kanav ",
   "PINCODE": "394315",
   "TALUKA": "PALSANA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karan ",
   "PINCODE": "394305",
   "TALUKA": "PALSANA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lakhanpur ",
   "PINCODE": "394352",
   "TALUKA": "PALSANA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Malekpor ",
   "PINCODE": "394315",
   "TALUKA": "PALSANA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Niol ",
   "PINCODE": "394325",
   "TALUKA": "PALSANA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Palsana ",
   "PINCODE": "394315",
   "TALUKA": "PALSANA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Puni ",
   "PINCODE": "394352",
   "TALUKA": "PALSANA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Soyani ",
   "PINCODE": "394310",
   "TALUKA": "PALSANA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Taraj ",
   "PINCODE": "394315",
   "TALUKA": "PALSANA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tatithaiya ",
   "PINCODE": "394305",
   "TALUKA": "PALSANA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tundi ",
   "PINCODE": "394310",
   "TALUKA": "PALSANA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadadla Tanti ",
   "PINCODE": "394317",
   "TALUKA": "PALSANA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vanisa Pisadi ",
   "PINCODE": "394310",
   "TALUKA": "PALSANA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bonandh ",
   "PINCODE": "394230",
   "TALUKA": "SACHIN",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Eklera ",
   "PINCODE": "394230",
   "TALUKA": "SACHIN",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gabheni ",
   "PINCODE": "394230",
   "TALUKA": "SACHIN",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kanakpur ",
   "PINCODE": "394230",
   "TALUKA": "SACHIN",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kansad ",
   "PINCODE": "394230",
   "TALUKA": "SACHIN",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lingad ",
   "PINCODE": "394230",
   "TALUKA": "SACHIN",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sachin R.S. ",
   "PINCODE": "394230",
   "TALUKA": "SACHIN",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Talangpur ",
   "PINCODE": "394230",
   "TALUKA": "SACHIN",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umber ",
   "PINCODE": "394230",
   "TALUKA": "SACHIN",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vanz ",
   "PINCODE": "394230",
   "TALUKA": "SACHIN",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vektana ",
   "PINCODE": "394230",
   "TALUKA": "SACHIN",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Atodara ",
   "PINCODE": "394130",
   "TALUKA": "SAYAN",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bharundi ",
   "PINCODE": "394130",
   "TALUKA": "SAYAN",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gothan ",
   "PINCODE": "394130",
   "TALUKA": "SAYAN",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karmala ",
   "PINCODE": "394130",
   "TALUKA": "SAYAN",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Madhar ",
   "PINCODE": "394130",
   "TALUKA": "SAYAN",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Morthana ",
   "PINCODE": "394130",
   "TALUKA": "SAYAN",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Paria ",
   "PINCODE": "394130",
   "TALUKA": "SAYAN",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sadhier ",
   "PINCODE": "394130",
   "TALUKA": "SAYAN",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sayan ",
   "PINCODE": "394130",
   "TALUKA": "SAYAN",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Segva ",
   "PINCODE": "394130",
   "TALUKA": "SAYAN",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sithan ",
   "PINCODE": "394130",
   "TALUKA": "SAYAN",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Syadla ",
   "PINCODE": "394130",
   "TALUKA": "SAYAN",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umra ",
   "PINCODE": "394130",
   "TALUKA": "SAYAN",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Agasvan ",
   "PINCODE": "394651",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amalgundi ",
   "PINCODE": "394365",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhatwada ",
   "PINCODE": "394680",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Borsavar ",
   "PINCODE": "394670",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chikhali Khadka ",
   "PINCODE": "394650",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chorvad ",
   "PINCODE": "394650",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhajamba ",
   "PINCODE": "394670",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhamodi ",
   "PINCODE": "394650",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Doswada ",
   "PINCODE": "394365",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Galkuva ",
   "PINCODE": "394650",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghasiamedha ",
   "PINCODE": "394360",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghoda ",
   "PINCODE": "394670",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gopalpura ",
   "PINCODE": "394365",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gunkhadi ",
   "PINCODE": "394365",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hindla ",
   "PINCODE": "394365",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hiravadi ",
   "PINCODE": "394365",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jamkhadi ",
   "PINCODE": "394365",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khanjar ",
   "PINCODE": "394365",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kikakui ",
   "PINCODE": "394650",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kumkuva ",
   "PINCODE": "394670",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Limbi ",
   "PINCODE": "394680",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Malangdev ",
   "PINCODE": "394716",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moghvan ",
   "PINCODE": "394650",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mota Tarpada ",
   "PINCODE": "394365",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moti Khervan ",
   "PINCODE": "394670",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nishana ",
   "PINCODE": "394650",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panchpipla ",
   "PINCODE": "394360",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pipalkuva ",
   "PINCODE": "394670",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sadadvel ",
   "PINCODE": "394365",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Segupada ",
   "PINCODE": "394365",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Singpur ",
   "PINCODE": "394670",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sisor ",
   "PINCODE": "394651",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Taparwada ",
   "PINCODE": "394365",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ukahlda ",
   "PINCODE": "394670",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ukai Dam ",
   "PINCODE": "394680",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadibehsrot ",
   "PINCODE": "394670",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vanzarda ",
   "PINCODE": "394651",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Wcc Ukai ",
   "PINCODE": "394680",
   "TALUKA": "SONGADH",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "A. K. Road ",
   "PINCODE": "395008",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Abhva ",
   "PINCODE": "395007",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Adajan Dn ",
   "PINCODE": "395009",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Aganovad ",
   "PINCODE": "395003",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Althan ",
   "PINCODE": "395017",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambheta ",
   "PINCODE": "395005",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ariana ",
   "PINCODE": "395005",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Athwa ",
   "PINCODE": "395007",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Barbodhan ",
   "PINCODE": "395005",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Begampura ",
   "PINCODE": "395003",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhagal ",
   "PINCODE": "395003",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhandut ",
   "PINCODE": "395005",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bharthana ",
   "PINCODE": "395007",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhavanivad ",
   "PINCODE": "395003",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhesan ",
   "PINCODE": "395005",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhestan ",
   "PINCODE": "395023",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bombay Market ",
   "PINCODE": "395010",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dihen ",
   "PINCODE": "395005",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Fatehnagar ",
   "PINCODE": "394220",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gavir ",
   "PINCODE": "395007",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gopipura ",
   "PINCODE": "395001",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Govt. Medical College ",
   "PINCODE": "395001",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hajira ",
   "PINCODE": "394270",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Indrapura ",
   "PINCODE": "395003",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jhampa ",
   "PINCODE": "395003",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Katargam ",
   "PINCODE": "395004",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khajod ",
   "PINCODE": "395007",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khatodara ",
   "PINCODE": "395002",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kosmada ",
   "PINCODE": "395008",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lajpore ",
   "PINCODE": "394235",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Laskana ",
   "PINCODE": "395008",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Magdalla ",
   "PINCODE": "395007",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mahidharmpura ",
   "PINCODE": "395003",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Muglisara ",
   "PINCODE": "395003",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nanpura H.O",
   "PINCODE": "395001",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Narthan ",
   "PINCODE": "395005",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navyug College ",
   "PINCODE": "395009",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nawabwadi ",
   "PINCODE": "395003",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Palanpur Nd ",
   "PINCODE": "395009",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pandesara ",
   "PINCODE": "394221",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pasodara ",
   "PINCODE": "395008",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pinjrat ",
   "PINCODE": "395005",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ramnagar ",
   "PINCODE": "395005",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rander ",
   "PINCODE": "395005",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rustampura ",
   "PINCODE": "395002",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sachin ",
   "PINCODE": "394230",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sagrampura Putli ",
   "PINCODE": "395002",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sania Hemad ",
   "PINCODE": "395008",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sayedpura ",
   "PINCODE": "395003",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Segva Chhama ",
   "PINCODE": "395005",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Selut ",
   "PINCODE": "395005",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Surat City ",
   "PINCODE": "395003",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Surat H.O",
   "PINCODE": "395003",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Surat RS ",
   "PINCODE": "395003",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Surta Textile Market ",
   "PINCODE": "395002",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Svr College ",
   "PINCODE": "395007",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umra ",
   "PINCODE": "395007",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Valak ",
   "PINCODE": "395008",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Varachha Road ",
   "PINCODE": "395006",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Varachhali ",
   "PINCODE": "395008",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Variavi Bhagal ",
   "PINCODE": "395003",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasta Devdi Road ",
   "PINCODE": "395004",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vesu ",
   "PINCODE": "395007",
   "TALUKA": "SURAT",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Babarghat ",
   "PINCODE": "394375",
   "TALUKA": "UCHCHHAL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhadbhunja ",
   "PINCODE": "394375",
   "TALUKA": "UCHCHHAL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhitkhurd ",
   "PINCODE": "394375",
   "TALUKA": "UCHCHHAL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chhapti ",
   "PINCODE": "394375",
   "TALUKA": "UCHCHHAL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chhitpur ",
   "PINCODE": "394375",
   "TALUKA": "UCHCHHAL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gavan ",
   "PINCODE": "394375",
   "TALUKA": "UCHCHHAL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Haripur ",
   "PINCODE": "394375",
   "TALUKA": "UCHCHHAL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karod ",
   "PINCODE": "394375",
   "TALUKA": "UCHCHHAL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khabda ",
   "PINCODE": "394375",
   "TALUKA": "UCHCHHAL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kulda ",
   "PINCODE": "394375",
   "TALUKA": "UCHCHHAL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Magarbara ",
   "PINCODE": "394375",
   "TALUKA": "UCHCHHAL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mirkot ",
   "PINCODE": "394670",
   "TALUKA": "UCHCHHAL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Narayanpur ",
   "PINCODE": "394375",
   "TALUKA": "UCHCHHAL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sankarda ",
   "PINCODE": "394375",
   "TALUKA": "UCHCHHAL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Selud ",
   "PINCODE": "394375",
   "TALUKA": "UCHCHHAL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sunderpur ",
   "PINCODE": "394375",
   "TALUKA": "UCHCHHAL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Thuti ",
   "PINCODE": "394670",
   "TALUKA": "UCHCHHAL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tokarva ",
   "PINCODE": "394375",
   "TALUKA": "UCHCHHAL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Uchchhal ",
   "PINCODE": "394375",
   "TALUKA": "UCHCHHAL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bamroli ",
   "PINCODE": "394210",
   "TALUKA": "UDHNA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Budia ",
   "PINCODE": "394210",
   "TALUKA": "UDHNA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Deladva ",
   "PINCODE": "394210",
   "TALUKA": "UDHNA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Devadh ",
   "PINCODE": "394210",
   "TALUKA": "UDHNA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dindoli ",
   "PINCODE": "394210",
   "TALUKA": "UDHNA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kharvasa ",
   "PINCODE": "394210",
   "TALUKA": "UDHNA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sania Kande ",
   "PINCODE": "394210",
   "TALUKA": "UDHNA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Udhna ",
   "PINCODE": "394210",
   "TALUKA": "UDHNA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Udhnagam ",
   "PINCODE": "394210",
   "TALUKA": "UDHNA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Un ",
   "PINCODE": "394210",
   "TALUKA": "UDHNA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bilvan ",
   "PINCODE": "394445",
   "TALUKA": "UMARPADA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chavda ",
   "PINCODE": "394445",
   "TALUKA": "UMARPADA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chimipatal ",
   "PINCODE": "394445",
   "TALUKA": "UMARPADA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chokhvada ",
   "PINCODE": "394445",
   "TALUKA": "UMARPADA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghanavad ",
   "PINCODE": "394445",
   "TALUKA": "UMARPADA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khota Rampura ",
   "PINCODE": "394445",
   "TALUKA": "UMARPADA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umarda ",
   "PINCODE": "394445",
   "TALUKA": "UMARPADA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umargot ",
   "PINCODE": "394445",
   "TALUKA": "UMARPADA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umarpada ",
   "PINCODE": "394445",
   "TALUKA": "UMARPADA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadpada ",
   "PINCODE": "394445",
   "TALUKA": "UMARPADA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chapra Bhatha ",
   "PINCODE": "394105",
   "TALUKA": "UTRAN",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Utran ",
   "PINCODE": "394105",
   "TALUKA": "UTRAN",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Utran Power House ",
   "PINCODE": "394105",
   "TALUKA": "UTRAN",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Algat ",
   "PINCODE": "394246",
   "TALUKA": "VALOD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambach ",
   "PINCODE": "394641",
   "TALUKA": "VALOD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Andhatri ",
   "PINCODE": "394630",
   "TALUKA": "VALOD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Antapur ",
   "PINCODE": "394635",
   "TALUKA": "VALOD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bajipura ",
   "PINCODE": "394690",
   "TALUKA": "VALOD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bedkuva ",
   "PINCODE": "394340",
   "TALUKA": "VALOD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhimpor ",
   "PINCODE": "394640",
   "TALUKA": "VALOD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Buhari ",
   "PINCODE": "394630",
   "TALUKA": "VALOD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dadaria ",
   "PINCODE": "394630",
   "TALUKA": "VALOD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Delvada ",
   "PINCODE": "395620",
   "TALUKA": "VALOD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhamodla ",
   "PINCODE": "394340",
   "TALUKA": "VALOD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gandhi Vidyapith ",
   "PINCODE": "394641",
   "TALUKA": "VALOD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Goddha ",
   "PINCODE": "394630",
   "TALUKA": "VALOD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hatuka ",
   "PINCODE": "394640",
   "TALUKA": "VALOD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jamania ",
   "PINCODE": "394246",
   "TALUKA": "VALOD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kaher ",
   "PINCODE": "394690",
   "TALUKA": "VALOD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kalamkui ",
   "PINCODE": "394340",
   "TALUKA": "VALOD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kanjod ",
   "PINCODE": "394640",
   "TALUKA": "VALOD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navafalia ",
   "PINCODE": "394640",
   "TALUKA": "VALOD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ranveri ",
   "PINCODE": "394640",
   "TALUKA": "VALOD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Siker ",
   "PINCODE": "395620",
   "TALUKA": "VALOD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Syadla ",
   "PINCODE": "394340",
   "TALUKA": "VALOD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Valod ",
   "PINCODE": "394640",
   "TALUKA": "VALOD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vedchhi ",
   "PINCODE": "394641",
   "TALUKA": "VALOD",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambawadi ",
   "PINCODE": "394430",
   "TALUKA": "VANKAL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amkhuta ",
   "PINCODE": "394430",
   "TALUKA": "VANKAL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Boria ",
   "PINCODE": "394430",
   "TALUKA": "VANKAL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dholikui ",
   "PINCODE": "394430",
   "TALUKA": "VANKAL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Isanpur ",
   "PINCODE": "394430",
   "TALUKA": "VANKAL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lavet ",
   "PINCODE": "394430",
   "TALUKA": "VANKAL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nandola ",
   "PINCODE": "394430",
   "TALUKA": "VANKAL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vankal ",
   "PINCODE": "394430",
   "TALUKA": "VANKAL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Verakui ",
   "PINCODE": "394430",
   "TALUKA": "VANKAL",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Variav ",
   "PINCODE": "394520",
   "TALUKA": "VARIAV",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Asaram ",
   "PINCODE": "394405",
   "TALUKA": "VELACHHA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hathoda ",
   "PINCODE": "394405",
   "TALUKA": "VELACHHA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kantva ",
   "PINCODE": "394405",
   "TALUKA": "VELACHHA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kosadi ",
   "PINCODE": "394405",
   "TALUKA": "VELACHHA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Limbada ",
   "PINCODE": "394405",
   "TALUKA": "VELACHHA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Luvara ",
   "PINCODE": "394405",
   "TALUKA": "VELACHHA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nogama ",
   "PINCODE": "394405",
   "TALUKA": "VELACHHA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Simodra ",
   "PINCODE": "394405",
   "TALUKA": "VELACHHA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Velachha ",
   "PINCODE": "394405",
   "TALUKA": "VELACHHA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambia ",
   "PINCODE": "394633",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Anumala ",
   "PINCODE": "394651",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bahedaraipura ",
   "PINCODE": "394630",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Balpur ",
   "PINCODE": "394655",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bardipada ",
   "PINCODE": "394635",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bedkuvadoor ",
   "PINCODE": "394360",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bedkuvanajik ",
   "PINCODE": "394650",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhojpur Najik ",
   "PINCODE": "394690",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Borkhadi ",
   "PINCODE": "394690",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Champavadi ",
   "PINCODE": "394650",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chhindia ",
   "PINCODE": "394655",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chikalda ",
   "PINCODE": "394650",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chikhalvav ",
   "PINCODE": "394650",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chikhlinani ",
   "PINCODE": "394650",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chunavadi ",
   "PINCODE": "394635",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Degama ",
   "PINCODE": "394690",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhanturi ",
   "PINCODE": "394633",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhat ",
   "PINCODE": "394655",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dolara ",
   "PINCODE": "394655",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dolvan ",
   "PINCODE": "394635",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gadat ",
   "PINCODE": "394633",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghani ",
   "PINCODE": "394630",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghata ",
   "PINCODE": "394651",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jesingpur ",
   "PINCODE": "394633",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kalakva ",
   "PINCODE": "394630",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kalamkui ",
   "PINCODE": "394635",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kanjan ",
   "PINCODE": "394655",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kanpura ",
   "PINCODE": "394650",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kapura ",
   "PINCODE": "394655",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karanjkhed ",
   "PINCODE": "394635",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karanjvel ",
   "PINCODE": "394655",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kasvav ",
   "PINCODE": "394633",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Katasvan ",
   "PINCODE": "394650",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kelkui ",
   "PINCODE": "394630",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khanpur ",
   "PINCODE": "394641",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khodtalav ",
   "PINCODE": "394651",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khurdi ",
   "PINCODE": "394655",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khushalpura ",
   "PINCODE": "394650",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khutadia ",
   "PINCODE": "394655",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lakhali ",
   "PINCODE": "394655",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Limberda ",
   "PINCODE": "394651",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lotarva ",
   "PINCODE": "394690",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Magalia ",
   "PINCODE": "394633",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Magarkui ",
   "PINCODE": "394655",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mirpur ",
   "PINCODE": "394655",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Padamdungri ",
   "PINCODE": "394635",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Palawadi ",
   "PINCODE": "394633",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panchol ",
   "PINCODE": "394635",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Paniyari ",
   "PINCODE": "394650",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pathakvadi ",
   "PINCODE": "394635",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pati ",
   "PINCODE": "394635",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pelad ",
   "PINCODE": "394630",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pithadara ",
   "PINCODE": "394635",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Raniamba ",
   "PINCODE": "394655",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rupvada ",
   "PINCODE": "394690",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sankli ",
   "PINCODE": "394655",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umarkui ",
   "PINCODE": "394630",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umarkutch ",
   "PINCODE": "394630",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umarvavdoor ",
   "PINCODE": "394635",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Unchamala ",
   "PINCODE": "394651",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadkui ",
   "PINCODE": "394651",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vankla ",
   "PINCODE": "394630",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vanskui ",
   "PINCODE": "394651",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Virpur ",
   "PINCODE": "394650",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vyara RS ",
   "PINCODE": "394650",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vyara ",
   "PINCODE": "394650",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zankhari ",
   "PINCODE": "394655",
   "TALUKA": "VYARA",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Balethi ",
   "PINCODE": "394440",
   "TALUKA": "ZANKHVAV",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bundha ",
   "PINCODE": "394440",
   "TALUKA": "ZANKHVAV",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chitalda ",
   "PINCODE": "394440",
   "TALUKA": "ZANKHVAV",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chormba ",
   "PINCODE": "394440",
   "TALUKA": "ZANKHVAV",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Devadh ",
   "PINCODE": "394440",
   "TALUKA": "ZANKHVAV",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Godbar ",
   "PINCODE": "394440",
   "TALUKA": "ZANKHVAV",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Keori ",
   "PINCODE": "394440",
   "TALUKA": "ZANKHVAV",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Luharvad ",
   "PINCODE": "394440",
   "TALUKA": "ZANKHVAV",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Madan Boria ",
   "PINCODE": "394440",
   "TALUKA": "ZANKHVAV",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Maldha ",
   "PINCODE": "394440",
   "TALUKA": "ZANKHVAV",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nasarpur ",
   "PINCODE": "394440",
   "TALUKA": "ZANKHVAV",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sarda ",
   "PINCODE": "394440",
   "TALUKA": "ZANKHVAV",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sarvan Fokdi ",
   "PINCODE": "394440",
   "TALUKA": "ZANKHVAV",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tarapur ",
   "PINCODE": "394440",
   "TALUKA": "ZANKHVAV",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Udharia ",
   "PINCODE": "394440",
   "TALUKA": "ZANKHVAV",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umarzar ",
   "PINCODE": "394440",
   "TALUKA": "ZANKHVAV",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vad ",
   "PINCODE": "394440",
   "TALUKA": "ZANKHVAV",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vahar ",
   "PINCODE": "394440",
   "TALUKA": "ZANKHVAV",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zankhvav ",
   "PINCODE": "394440",
   "TALUKA": "ZANKHVAV",
   "DISTRICT": "SURAT",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nagnesh ",
   "PINCODE": "363415",
   "TALUKA": ".",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shirvaniya ",
   "PINCODE": "363410",
   "TALUKA": ".",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Anandpur Bhadla ",
   "PINCODE": "363520",
   "TALUKA": "CHOTILA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bamanbor ",
   "PINCODE": "363520",
   "TALUKA": "CHOTILA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chiroda ",
   "PINCODE": "363520",
   "TALUKA": "CHOTILA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chobari ",
   "PINCODE": "363520",
   "TALUKA": "CHOTILA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chorvira ",
   "PINCODE": "363530",
   "TALUKA": "CHOTILA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chotila ",
   "PINCODE": "363520",
   "TALUKA": "Chotila",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Devsar ",
   "PINCODE": "363520",
   "TALUKA": "CHOTILA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dharai ",
   "PINCODE": "363520",
   "TALUKA": "CHOTILA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhokalva ",
   "PINCODE": "363520",
   "TALUKA": "CHOTILA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gunda ",
   "PINCODE": "363520",
   "TALUKA": "CHOTILA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Janivadla ",
   "PINCODE": "363520",
   "TALUKA": "CHOTILA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khatdi ",
   "PINCODE": "363520",
   "TALUKA": "CHOTILA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kherana ",
   "PINCODE": "363520",
   "TALUKA": "CHOTILA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kherdi ",
   "PINCODE": "363520",
   "TALUKA": "CHOTILA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mandlasar ",
   "PINCODE": "363530",
   "TALUKA": "CHOTILA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Morthala ",
   "PINCODE": "363530",
   "TALUKA": "CHOTILA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moti Moldi ",
   "PINCODE": "363520",
   "TALUKA": "CHOTILA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nava ",
   "PINCODE": "363520",
   "TALUKA": "CHOTILA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panchvada ",
   "PINCODE": "363520",
   "TALUKA": "CHOTILA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pipaliya (Dhora) ",
   "PINCODE": "363520",
   "TALUKA": "CHOTILA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pipaliya Dhandhal ",
   "PINCODE": "363520",
   "TALUKA": "CHOTILA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Piyava ",
   "PINCODE": "363520",
   "TALUKA": "CHOTILA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajpara ",
   "PINCODE": "363520",
   "TALUKA": "CHOTILA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ranipat ",
   "PINCODE": "363530",
   "TALUKA": "CHOTILA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Reshamiya ",
   "PINCODE": "363520",
   "TALUKA": "Chotila",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sanosara ",
   "PINCODE": "363520",
   "TALUKA": "CHOTILA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sapar ",
   "PINCODE": "363520",
   "TALUKA": "CHOTILA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Songadh ",
   "PINCODE": "363530",
   "TALUKA": "CHOTILA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tarnetar ",
   "PINCODE": "363530",
   "TALUKA": "CHOTILA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Thangadh ",
   "PINCODE": "363530",
   "TALUKA": "CHOTILA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadali ",
   "PINCODE": "363520",
   "TALUKA": "CHOTILA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vagadiya ",
   "PINCODE": "363530",
   "TALUKA": "CHOTILA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vijaliya ",
   "PINCODE": "363530",
   "TALUKA": "CHOTILA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zinzuda ",
   "PINCODE": "363520",
   "TALUKA": "CHOTILA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Adariyana ",
   "PINCODE": "382780",
   "TALUKA": "Dasada",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bajana ",
   "PINCODE": "382745",
   "TALUKA": "Dasada",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bubvana ",
   "PINCODE": "382750",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chikasar ",
   "PINCODE": "382765",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dasada ",
   "PINCODE": "382750",
   "TALUKA": "Dasada",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Degam ",
   "PINCODE": "382745",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhama ",
   "PINCODE": "382755",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Echhvada ",
   "PINCODE": "382750",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ervada ",
   "PINCODE": "382750",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Fatepur ",
   "PINCODE": "382755",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gavana ",
   "PINCODE": "382750",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gediya ",
   "PINCODE": "382745",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Goriyavad ",
   "PINCODE": "382765",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jainabad ",
   "PINCODE": "382765",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jarvala ",
   "PINCODE": "382765",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kacholiya ",
   "PINCODE": "382745",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kathada ",
   "PINCODE": "382750",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kharaghoda ",
   "PINCODE": "382760",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kherva(Jat) ",
   "PINCODE": "382745",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Malvan(Jat) ",
   "PINCODE": "382745",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Motimajethi ",
   "PINCODE": "382765",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nagadka(Jat) ",
   "PINCODE": "382745",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nagvada ",
   "PINCODE": "382755",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nana Goraiya ",
   "PINCODE": "382745",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nava Savlas ",
   "PINCODE": "382745",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Naviyani ",
   "PINCODE": "382750",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Odu ",
   "PINCODE": "382760",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panva ",
   "PINCODE": "382750",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Patdi ",
   "PINCODE": "382765",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pipali ",
   "PINCODE": "382745",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Porda ",
   "PINCODE": "382765",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Savda ",
   "PINCODE": "382765",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sedla ",
   "PINCODE": "382745",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sokhda ",
   "PINCODE": "382745",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Surel ",
   "PINCODE": "382780",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sushiya ",
   "PINCODE": "382750",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Upariyala ",
   "PINCODE": "382765",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadgam ",
   "PINCODE": "382750",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vanod ",
   "PINCODE": "382750",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Visavadi ",
   "PINCODE": "382750",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zadiyana ",
   "PINCODE": "382780",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zinzuwada ",
   "PINCODE": "382755",
   "TALUKA": "DASADA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Akhiyana ",
   "PINCODE": "382745",
   "TALUKA": "DASDA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bamanva ",
   "PINCODE": "382765",
   "TALUKA": "DASDAA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bavli ",
   "PINCODE": "363310",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bharad ",
   "PINCODE": "363320",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bharada ",
   "PINCODE": "363310",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhechda ",
   "PINCODE": "363310",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chuli ",
   "PINCODE": "363310",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Devcharadi ",
   "PINCODE": "363320",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dholi ",
   "PINCODE": "363320",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhrumath ",
   "PINCODE": "363310",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dumana ",
   "PINCODE": "363320",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gajanvav ",
   "PINCODE": "363310",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gala ",
   "PINCODE": "363310",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ganjela ",
   "PINCODE": "363320",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hampar ",
   "PINCODE": "363320",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Haripar ",
   "PINCODE": "363310",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jasmatpur ",
   "PINCODE": "363310",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jegadva ",
   "PINCODE": "363310",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jesda ",
   "PINCODE": "363310",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jiva ",
   "PINCODE": "363310",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kankavati ",
   "PINCODE": "363310",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khambhada ",
   "PINCODE": "363320",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kondh ",
   "PINCODE": "363310",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kuda ",
   "PINCODE": "363310",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Malvan ",
   "PINCODE": "363310",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Manpar ",
   "PINCODE": "363310",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Methan ",
   "PINCODE": "363310",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Narali ",
   "PINCODE": "363310",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Narichana ",
   "PINCODE": "363310",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navalgadh ",
   "PINCODE": "363320",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pratappur ",
   "PINCODE": "363320",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajcharadi ",
   "PINCODE": "363320",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajsitapur ",
   "PINCODE": "363320",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sara ",
   "PINCODE": "363310",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sarval ",
   "PINCODE": "363310",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Soldi ",
   "PINCODE": "363310",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Thala ",
   "PINCODE": "363310",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vavdi ",
   "PINCODE": "363310",
   "TALUKA": "DHRANGADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhrangadhra ",
   "PINCODE": "363310",
   "TALUKA": "DHRANGSADHRA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ramgadh ",
   "PINCODE": "363310",
   "TALUKA": "dshrangadhra",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ajitgadh ",
   "PINCODE": "363330",
   "TALUKA": "HALVAD",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Charadva ",
   "PINCODE": "363330",
   "TALUKA": "HALVAD",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Devaliya ",
   "PINCODE": "363330",
   "TALUKA": "HALVAD",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhanala ",
   "PINCODE": "363351",
   "TALUKA": "HALVAD",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhavana ",
   "PINCODE": "363330",
   "TALUKA": "HALVAD",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Enjar ",
   "PINCODE": "363330",
   "TALUKA": "HALVAD",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghanshyampur ",
   "PINCODE": "363330",
   "TALUKA": "HALVAD",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Halvad ",
   "PINCODE": "363330",
   "TALUKA": "HALVAD",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ingorala ",
   "PINCODE": "363351",
   "TALUKA": "HALVAD",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Isanpur ",
   "PINCODE": "363351",
   "TALUKA": "HALVAD",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kadiyana ",
   "PINCODE": "363330",
   "TALUKA": "HALVAD",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kavadiya ",
   "PINCODE": "363330",
   "TALUKA": "HALVAD",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kidi ",
   "PINCODE": "363351",
   "TALUKA": "HALVAD",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Koparani ",
   "PINCODE": "363330",
   "TALUKA": "HALVAD",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Koyba ",
   "PINCODE": "363330",
   "TALUKA": "HALVAD",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Malaniyad ",
   "PINCODE": "363330",
   "TALUKA": "HALVAD",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mathak ",
   "PINCODE": "363330",
   "TALUKA": "HALVAD",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mayurnagar ",
   "PINCODE": "363351",
   "TALUKA": "HALVAD",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Merupar ",
   "PINCODE": "363330",
   "TALUKA": "HALVAD",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navaghanshyamgadh ",
   "PINCODE": "363330",
   "TALUKA": "HALVAD",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ranakpur ",
   "PINCODE": "363330",
   "TALUKA": "HALVAD",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ranjitgadh ",
   "PINCODE": "363351",
   "TALUKA": "HALVAD",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ranmalpur ",
   "PINCODE": "363330",
   "TALUKA": "HALVAD",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ratabhe ",
   "PINCODE": "363330",
   "TALUKA": "HALVAD",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sapakda ",
   "PINCODE": "363330",
   "TALUKA": "HALVAD",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sundari ",
   "PINCODE": "363330",
   "TALUKA": "HALVAD",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Survadar ",
   "PINCODE": "363351",
   "TALUKA": "HALVAD",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Susvav ",
   "PINCODE": "363351",
   "TALUKA": "HALVAD",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tikar (Ran) ",
   "PINCODE": "363330",
   "TALUKA": "HALVAD",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vegadvav ",
   "PINCODE": "363330",
   "TALUKA": "HALVAD",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Adalsar ",
   "PINCODE": "382775",
   "TALUKA": "LAKHTAR",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Anindra ",
   "PINCODE": "363110",
   "TALUKA": "LAKHTAR",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bajarangpura ",
   "PINCODE": "363110",
   "TALUKA": "LAKHTAR",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhadena ",
   "PINCODE": "382775",
   "TALUKA": "LAKHTAR",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhadvana ",
   "PINCODE": "382775",
   "TALUKA": "LAKHTAR",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chharad ",
   "PINCODE": "363115",
   "TALUKA": "LAKHTAR",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dervala ",
   "PINCODE": "382775",
   "TALUKA": "LAKHTAR",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Devaliya ",
   "PINCODE": "382775",
   "TALUKA": "LAKHTAR",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhanki ",
   "PINCODE": "363115",
   "TALUKA": "LAKHTAR",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gangad ",
   "PINCODE": "363115",
   "TALUKA": "LAKHTAR",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghanad ",
   "PINCODE": "363110",
   "TALUKA": "LAKHTAR",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hebatpur ",
   "PINCODE": "363115",
   "TALUKA": "LAKHTAR",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kadu ",
   "PINCODE": "382775",
   "TALUKA": "LAKHTAR",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kalam ",
   "PINCODE": "382775",
   "TALUKA": "LAKHTAR",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karala ",
   "PINCODE": "363115",
   "TALUKA": "LAKHTAR",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lakhtar ",
   "PINCODE": "382775",
   "TALUKA": "LAKHTAR",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lilapur ",
   "PINCODE": "382775",
   "TALUKA": "LAKHTAR",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Malika ",
   "PINCODE": "363115",
   "TALUKA": "LAKHTAR",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Modhvana ",
   "PINCODE": "363110",
   "TALUKA": "LAKHTAR",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nana Ankevaliya ",
   "PINCODE": "363110",
   "TALUKA": "LAKHTAR",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nanikathechi ",
   "PINCODE": "382775",
   "TALUKA": "LAKHTAR",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Olak ",
   "PINCODE": "363115",
   "TALUKA": "LAKHTAR",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pedhda ",
   "PINCODE": "363110",
   "TALUKA": "LAKHTAR",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sadad ",
   "PINCODE": "382775",
   "TALUKA": "LAKHTAR",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sakar ",
   "PINCODE": "382775",
   "TALUKA": "LAKHTAR",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Savlana ",
   "PINCODE": "382775",
   "TALUKA": "LAKHTAR",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tarmaniya ",
   "PINCODE": "382775",
   "TALUKA": "LAKHTAR",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vana ",
   "PINCODE": "363110",
   "TALUKA": "LAKHTAR",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vithalgadh ",
   "PINCODE": "363115",
   "TALUKA": "LAKHTAR",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zamar ",
   "PINCODE": "382775",
   "TALUKA": "LAKHTAR",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Anandpur Bhal ",
   "PINCODE": "363425",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ankevaliya ",
   "PINCODE": "363421",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Baldana ",
   "PINCODE": "363421",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Balol ",
   "PINCODE": "363425",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhalgamda ",
   "PINCODE": "363421",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhathan ",
   "PINCODE": "363421",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhensjal ",
   "PINCODE": "363410",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhoika ",
   "PINCODE": "363421",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhojpara ",
   "PINCODE": "363423",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhragupur ",
   "PINCODE": "363415",
   "TALUKA": "Limbdi",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Borana ",
   "PINCODE": "363410",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Borna ",
   "PINCODE": "363421",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chachana ",
   "PINCODE": "363421",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chachka ",
   "PINCODE": "363410",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chhalala ",
   "PINCODE": "363415",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chhatriyala ",
   "PINCODE": "363415",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chokdi ",
   "PINCODE": "363410",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Choki ",
   "PINCODE": "363421",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chuda ",
   "PINCODE": "363410",
   "TALUKA": "Limbdi",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dholi Bhal ",
   "PINCODE": "363425",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gedi ",
   "PINCODE": "363421",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghaghretiya ",
   "PINCODE": "363427",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hadalabhal ",
   "PINCODE": "363425",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jambu ",
   "PINCODE": "363421",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Janshali ",
   "PINCODE": "363425",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jobala ",
   "PINCODE": "363415",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kamalpar ",
   "PINCODE": "363425",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kanthariya ",
   "PINCODE": "363410",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karol ",
   "PINCODE": "363410",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Katariya ",
   "PINCODE": "363421",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khajeli ",
   "PINCODE": "363427",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khambhalav ",
   "PINCODE": "363423",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khandiya ",
   "PINCODE": "363410",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Korda ",
   "PINCODE": "363410",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Laliyad ",
   "PINCODE": "363410",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Limbdi ",
   "PINCODE": "363421",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Loya ",
   "PINCODE": "363410",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Minapur ",
   "PINCODE": "363415",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mojidad ",
   "PINCODE": "363410",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Morvad(Juni) ",
   "PINCODE": "363410",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Motatimbla ",
   "PINCODE": "363421",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mulbavla ",
   "PINCODE": "363427",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nagadka ",
   "PINCODE": "363410",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Natvargadh ",
   "PINCODE": "363427",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panshina ",
   "PINCODE": "363423",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Parali ",
   "PINCODE": "363427",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Parnala ",
   "PINCODE": "363427",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ralol ",
   "PINCODE": "363423",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ranagadh ",
   "PINCODE": "363427",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Raska ",
   "PINCODE": "363421",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rojasar ",
   "PINCODE": "363427",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Samla ",
   "PINCODE": "363421",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sauka ",
   "PINCODE": "363421",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shiyani ",
   "PINCODE": "363427",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Talsana ",
   "PINCODE": "363427",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tavi ",
   "PINCODE": "363427",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tokrala ",
   "PINCODE": "363421",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tuva ",
   "PINCODE": "363421",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Untadi ",
   "PINCODE": "363421",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadod ",
   "PINCODE": "363421",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vanala ",
   "PINCODE": "363421",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Varsani ",
   "PINCODE": "363427",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vastadi ",
   "PINCODE": "363410",
   "TALUKA": "LIMBDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Devpara ",
   "PINCODE": "363425",
   "TALUKA": "LIMBDIQ",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rangpur ",
   "PINCODE": "382460",
   "TALUKA": "LIMDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kudla ",
   "PINCODE": "363410",
   "TALUKA": "LIMNDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ingrodi ",
   "PINCODE": "363115",
   "TALUKA": "LKHTAR",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhaduka ",
   "PINCODE": "363510",
   "TALUKA": "MULI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Danavada ",
   "PINCODE": "363510",
   "TALUKA": "MULI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Digsar ",
   "PINCODE": "363510",
   "TALUKA": "MULI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dudhai ",
   "PINCODE": "363510",
   "TALUKA": "MULI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gadhad ",
   "PINCODE": "363510",
   "TALUKA": "MULI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gautamgadh ",
   "PINCODE": "363510",
   "TALUKA": "MULI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jasapar ",
   "PINCODE": "363510",
   "TALUKA": "MULI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kalmad ",
   "PINCODE": "363510",
   "TALUKA": "MULI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khatdi ",
   "PINCODE": "363510",
   "TALUKA": "MULI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kukda ",
   "PINCODE": "363510",
   "TALUKA": "MULI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kuntalpur ",
   "PINCODE": "363510",
   "TALUKA": "MULI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Liya ",
   "PINCODE": "363510",
   "TALUKA": "MULI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Muli ",
   "PINCODE": "363510",
   "TALUKA": "MULI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pandavara ",
   "PINCODE": "363510",
   "TALUKA": "MULI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sarla ",
   "PINCODE": "363510",
   "TALUKA": "MULI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shekhpar ",
   "PINCODE": "363510",
   "TALUKA": "MULI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Somasar ",
   "PINCODE": "363510",
   "TALUKA": "MULI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tikar Parmar ",
   "PINCODE": "363510",
   "TALUKA": "MULI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umarda ",
   "PINCODE": "363510",
   "TALUKA": "MULI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Malanpur ",
   "PINCODE": "382130",
   "TALUKA": "PATDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vaghada ",
   "PINCODE": "382130",
   "TALUKA": "PATDI",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhajala ",
   "PINCODE": "363440",
   "TALUKA": "SAYLA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhandhalpur ",
   "PINCODE": "363440",
   "TALUKA": "SAYLA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Doliya ",
   "PINCODE": "363430",
   "TALUKA": "SAYLA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Garambhadi ",
   "PINCODE": "363440",
   "TALUKA": "SAYLA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Goraiya ",
   "PINCODE": "363440",
   "TALUKA": "SAYLA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gosal ",
   "PINCODE": "363430",
   "TALUKA": "SAYLA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Junajasapar ",
   "PINCODE": "363430",
   "TALUKA": "SAYLA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khintala ",
   "PINCODE": "363440",
   "TALUKA": "SAYLA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nadala ",
   "PINCODE": "363440",
   "TALUKA": "SAYLA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nana Matra ",
   "PINCODE": "363440",
   "TALUKA": "SAYLA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navagam (S) ",
   "PINCODE": "363440",
   "TALUKA": "SAYLA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navaniya ",
   "PINCODE": "363430",
   "TALUKA": "SAYLA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ninama ",
   "PINCODE": "363440",
   "TALUKA": "SAYLA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Noli ",
   "PINCODE": "363440",
   "TALUKA": "SAYLA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ori ",
   "PINCODE": "360055",
   "TALUKA": "Sayla",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Piprali ",
   "PINCODE": "363440",
   "TALUKA": "SAYLA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Samadhiyala ",
   "PINCODE": "363440",
   "TALUKA": "SAYLA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sayla ",
   "PINCODE": "363430",
   "TALUKA": "SAYLA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sejakpar ",
   "PINCODE": "363440",
   "TALUKA": "SAYLA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sidhsar ",
   "PINCODE": "363430",
   "TALUKA": "SAYLA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sudamada ",
   "PINCODE": "363440",
   "TALUKA": "SAYLA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Thoriyali ",
   "PINCODE": "363430",
   "TALUKA": "SAYLA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadia ",
   "PINCODE": "363430",
   "TALUKA": "SAYLA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vakhatpar ",
   "PINCODE": "363430",
   "TALUKA": "SAYLA",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bakarthali ",
   "PINCODE": "363040",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bala ",
   "PINCODE": "363030",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhadreshi ",
   "PINCODE": "363040",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chamaraj ",
   "PINCODE": "363040",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dedadra ",
   "PINCODE": "363030",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dudhrej ",
   "PINCODE": "363040",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Fulgram ",
   "PINCODE": "363435",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gujarvadi ",
   "PINCODE": "363040",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gundiyala ",
   "PINCODE": "363435",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Katuda ",
   "PINCODE": "363040",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kharva ",
   "PINCODE": "363030",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kherali ",
   "PINCODE": "363020",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khodu ",
   "PINCODE": "363040",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kholadiyad ",
   "PINCODE": "363020",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kothariya ",
   "PINCODE": "363030",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Limli ",
   "PINCODE": "363020",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Malod ",
   "PINCODE": "363020",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Memka ",
   "PINCODE": "363030",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mota Ankevaliya ",
   "PINCODE": "363040",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Motamadhad ",
   "PINCODE": "363435",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Munjpar ",
   "PINCODE": "363020",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nagra ",
   "PINCODE": "363040",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajpar ",
   "PINCODE": "363030",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rampara ",
   "PINCODE": "363435",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ratanpar ",
   "PINCODE": "363020",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ravaliyavadar ",
   "PINCODE": "363040",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sankali ",
   "PINCODE": "363030",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Surendranaagr M.P.S.C. ",
   "PINCODE": "363002",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Surendranaagr Udyognagar ",
   "PINCODE": "363002",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Surendranaagr Vadipara ",
   "PINCODE": "363001",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Surendranagar Station Road ",
   "PINCODE": "363002",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Timba ",
   "PINCODE": "363030",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadla ",
   "PINCODE": "363030",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vaghela ",
   "PINCODE": "363030",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Velavadar ",
   "PINCODE": "363040",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Wadhwancity Bazatr ",
   "PINCODE": "363030",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Wadhwancity Ind. Estate ",
   "PINCODE": "363035",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Wadhwancity ",
   "PINCODE": "363030",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zampodad ",
   "PINCODE": "363030",
   "TALUKA": "WADHWANCITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Surendranagar H.O",
   "PINCODE": "363001",
   "TALUKA": "WADHWANICITY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Joravarnagar ",
   "PINCODE": "363020",
   "TALUKA": "WADHWANIVTY",
   "DISTRICT": "SURENDRA NAGAR",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ahwadangs ",
   "PINCODE": "394710",
   "TALUKA": "AHWA",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pimpri ",
   "PINCODE": "394715",
   "TALUKA": "AHWA",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Saputara ",
   "PINCODE": "394720",
   "TALUKA": "AHWA",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Subir ",
   "PINCODE": "394716",
   "TALUKA": "AHWA",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Waghai ",
   "PINCODE": "394720",
   "TALUKA": "AHWA",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Barkhandhia ",
   "PINCODE": "394720",
   "TALUKA": "DANG",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chankhal ",
   "PINCODE": "394710",
   "TALUKA": "DANG",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chikar ",
   "PINCODE": "394720",
   "TALUKA": "DANG",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chikhali Dangs ",
   "PINCODE": "394720",
   "TALUKA": "DANG",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dagadiamba ",
   "PINCODE": "394720",
   "TALUKA": "DANG",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dagunia ",
   "PINCODE": "394720",
   "TALUKA": "DANG",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gotiamal ",
   "PINCODE": "394720",
   "TALUKA": "DANG",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jhavda ",
   "PINCODE": "394720",
   "TALUKA": "DANG",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kadmal ",
   "PINCODE": "394716",
   "TALUKA": "DANG",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Keshbandh ",
   "PINCODE": "394716",
   "TALUKA": "DANG",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khambhala ",
   "PINCODE": "394716",
   "TALUKA": "DANG",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lavchali ",
   "PINCODE": "394716",
   "TALUKA": "DANG",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mahal ",
   "PINCODE": "394716",
   "TALUKA": "DANG",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Malegaon ",
   "PINCODE": "394720",
   "TALUKA": "DANG",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Manmodi ",
   "PINCODE": "394720",
   "TALUKA": "DANG",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nadagchond ",
   "PINCODE": "394720",
   "TALUKA": "DANG",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nakatia Hanvant ",
   "PINCODE": "394710",
   "TALUKA": "DANG",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nanapada ",
   "PINCODE": "394720",
   "TALUKA": "DANG",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nishana ",
   "PINCODE": "394716",
   "TALUKA": "DANG",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pandva ",
   "PINCODE": "394710",
   "TALUKA": "DANG",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Piplaidevi ",
   "PINCODE": "394716",
   "TALUKA": "DANG",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rambhas ",
   "PINCODE": "394720",
   "TALUKA": "DANG",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sakarpatal ",
   "PINCODE": "394720",
   "TALUKA": "DANG",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Samgahan ",
   "PINCODE": "394720",
   "TALUKA": "DANG",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Singana ",
   "PINCODE": "394716",
   "TALUKA": "DANG",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tanklipada ",
   "PINCODE": "394716",
   "TALUKA": "DANG",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasurna ",
   "PINCODE": "394720",
   "TALUKA": "DANG",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zaridungarda ",
   "PINCODE": "394720",
   "TALUKA": "DANG",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhavandgad ",
   "PINCODE": "394710",
   "TALUKA": "DANGS",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Borkhal ",
   "PINCODE": "394710",
   "TALUKA": "DANGS",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chikatia ",
   "PINCODE": "394710",
   "TALUKA": "DANGS",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chinchli ",
   "PINCODE": "394710",
   "TALUKA": "DANGS",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhavlidhod ",
   "PINCODE": "394710",
   "TALUKA": "DANGS",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Galkund ",
   "PINCODE": "394710",
   "TALUKA": "DANGS",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Garakhadi ",
   "PINCODE": "394710",
   "TALUKA": "DANGS",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghadvi ",
   "PINCODE": "394710",
   "TALUKA": "DANGS",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gondalvihir ",
   "PINCODE": "394710",
   "TALUKA": "DANGS",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jakhana ",
   "PINCODE": "394710",
   "TALUKA": "DANGS",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Linga ",
   "PINCODE": "394710",
   "TALUKA": "DANGS",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mahalpada ",
   "PINCODE": "394710",
   "TALUKA": "DANGS",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Morzira ",
   "PINCODE": "394710",
   "TALUKA": "DANGS",
   "DISTRICT": "THE DANGS",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dena ",
   "PINCODE": "390022",
   "TALUKA": ".",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhanora ",
   "PINCODE": "391346",
   "TALUKA": ".",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Harni ",
   "PINCODE": "390022",
   "TALUKA": ".",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sukal ",
   "PINCODE": "391155",
   "TALUKA": ".",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tejgadh ",
   "PINCODE": "391160",
   "TALUKA": ".",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasna Road ",
   "PINCODE": "390007",
   "TALUKA": ".",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bodeli ",
   "PINCODE": "391135",
   "TALUKA": "BODELI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Asar ",
   "PINCODE": "391168",
   "TALUKA": "CH.UDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kanalva ",
   "PINCODE": "391168",
   "TALUKA": "CH.UDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Manavant ",
   "PINCODE": "391168",
   "TALUKA": "CH.UDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Morangana ",
   "PINCODE": "391168",
   "TALUKA": "CH.UDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Raichha ",
   "PINCODE": "391168",
   "TALUKA": "CH.UDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sadhli ",
   "PINCODE": "391168",
   "TALUKA": "CH.UDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sanada ",
   "PINCODE": "391168",
   "TALUKA": "CH.UDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Singla ",
   "PINCODE": "391168",
   "TALUKA": "CH.UDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambala ",
   "PINCODE": "391165",
   "TALUKA": "CHHOTA UDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chhota-udepur ",
   "PINCODE": "391165",
   "TALUKA": "CHHOTAUDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chisadiya ",
   "PINCODE": "391165",
   "TALUKA": "CHHOTAUDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhandhoda ",
   "PINCODE": "391165",
   "TALUKA": "CHHOTAUDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dholi Simal ",
   "PINCODE": "391165",
   "TALUKA": "CHHOTAUDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dolaria ",
   "PINCODE": "391165",
   "TALUKA": "CHHOTAUDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dungargam ",
   "PINCODE": "391165",
   "TALUKA": "CHHOTAUDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ekalbara ",
   "PINCODE": "391165",
   "TALUKA": "CHHOTAUDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghelawant ",
   "PINCODE": "391165",
   "TALUKA": "CHHOTAUDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kadipani ",
   "PINCODE": "391175",
   "TALUKA": "CHHOTAUDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karanjwant ",
   "PINCODE": "391165",
   "TALUKA": "CHHOTAUDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kawant ",
   "PINCODE": "391170",
   "TALUKA": "CHHOTAUDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khadkhad ",
   "PINCODE": "391165",
   "TALUKA": "CHHOTAUDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kundal ",
   "PINCODE": "391165",
   "TALUKA": "CHHOTAUDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mandlava ",
   "PINCODE": "391165",
   "TALUKA": "CHHOTAUDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mithibor ",
   "PINCODE": "391165",
   "TALUKA": "CHHOTAUDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Motaghoda ",
   "PINCODE": "391165",
   "TALUKA": "CHHOTAUDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nani Tokri ",
   "PINCODE": "391165",
   "TALUKA": "CHHOTAUDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Padharwant ",
   "PINCODE": "391165",
   "TALUKA": "CHHOTAUDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panvad ",
   "PINCODE": "391168",
   "TALUKA": "CHHOTAUDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Puniavant ",
   "PINCODE": "391165",
   "TALUKA": "CHHOTAUDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rangpur(Z) ",
   "PINCODE": "391165",
   "TALUKA": "CHHOTAUDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rodadha ",
   "PINCODE": "391165",
   "TALUKA": "CHHOTAUDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rumadia ",
   "PINCODE": "391165",
   "TALUKA": "CHHOTAUDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sanada ",
   "PINCODE": "391165",
   "TALUKA": "CHHOTAUDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Surkheda ",
   "PINCODE": "391165",
   "TALUKA": "CHHOTAUDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Virpur ",
   "PINCODE": "391165",
   "TALUKA": "CHHOTAUDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zoz ",
   "PINCODE": "391165",
   "TALUKA": "CHHOTAUDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhorda ",
   "PINCODE": "391165",
   "TALUKA": "CHHOTA-UDEPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amreshwar ",
   "PINCODE": "391761",
   "TALUKA": "Dabhoi",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Anguthan ",
   "PINCODE": "391107",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhilapur ",
   "PINCODE": "391107",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhilodia ",
   "PINCODE": "391110",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Borbar ",
   "PINCODE": "391107",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chandod ",
   "PINCODE": "391105",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chanvada ",
   "PINCODE": "391110",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chhatral ",
   "PINCODE": "391210",
   "TALUKA": "Dabhoi",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dabhoi H.O",
   "PINCODE": "391110",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dabhoi R.S. ",
   "PINCODE": "391110",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dabhoi Vadodari Bhagol ",
   "PINCODE": "391110",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dharmpuri ",
   "PINCODE": "391110",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dholar ",
   "PINCODE": "391107",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Fartikui ",
   "PINCODE": "391107",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jiyatalavdi ",
   "PINCODE": "391220",
   "TALUKA": "Dabhoi",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kadadhara ",
   "PINCODE": "391107",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karalipura ",
   "PINCODE": "391110",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karmal ",
   "PINCODE": "391210",
   "TALUKA": "Dabhoi",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karnali ",
   "PINCODE": "391105",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karnet ",
   "PINCODE": "391110",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kukad ",
   "PINCODE": "391110",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kundhela ",
   "PINCODE": "391107",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kuvarpura ",
   "PINCODE": "391220",
   "TALUKA": "Dabhoi",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lingsthali ",
   "PINCODE": "391220",
   "TALUKA": "Dabhoi",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mandva ",
   "PINCODE": "391105",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Manjrol ",
   "PINCODE": "391110",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Meghakui ",
   "PINCODE": "391107",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moletha ",
   "PINCODE": "391105",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mota  Habipura ",
   "PINCODE": "391111",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nada ",
   "PINCODE": "391210",
   "TALUKA": "Dabhoi",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nana Fofalia ",
   "PINCODE": "391210",
   "TALUKA": "Dabhoi",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nanderia ",
   "PINCODE": "391105",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Naria ",
   "PINCODE": "391107",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Palaswada ",
   "PINCODE": "391107",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pansoli ",
   "PINCODE": "391110",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Parikha ",
   "PINCODE": "391210",
   "TALUKA": "Dabhoi",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pisai ",
   "PINCODE": "391111",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sathod ",
   "PINCODE": "391111",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Simalia ",
   "PINCODE": "391110",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Simli ",
   "PINCODE": "391105",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sitpur ",
   "PINCODE": "391110",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tentalav ",
   "PINCODE": "391105",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Thuwavi ",
   "PINCODE": "391107",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadaj ",
   "PINCODE": "391105",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vanadara ",
   "PINCODE": "391107",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasai ",
   "PINCODE": "391110",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Wadhwana ",
   "PINCODE": "391110",
   "TALUKA": "DABHOI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Anastu ",
   "PINCODE": "391240",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Atali ",
   "PINCODE": "391244",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bachar ",
   "PINCODE": "391244",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Baman Gam ",
   "PINCODE": "391210",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhalod ",
   "PINCODE": "393105",
   "TALUKA": "KARJAN",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bharthana ",
   "PINCODE": "391244",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bodka ",
   "PINCODE": "391240",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chhanchava ",
   "PINCODE": "391244",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Choranda ",
   "PINCODE": "391244",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chorbhuj ",
   "PINCODE": "391240",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhavat ",
   "PINCODE": "391210",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gandhara ",
   "PINCODE": "391210",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ganpatpura ",
   "PINCODE": "391210",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Handod ",
   "PINCODE": "391240",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Juni Jathardi ",
   "PINCODE": "391240",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kanbha ",
   "PINCODE": "391240",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kanbola ",
   "PINCODE": "391240",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kandari ",
   "PINCODE": "391210",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karamdi ",
   "PINCODE": "391240",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kayavahron ",
   "PINCODE": "391220",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kiya ",
   "PINCODE": "392310",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kurai ",
   "PINCODE": "391240",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kurali ",
   "PINCODE": "391240",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lakodara ",
   "PINCODE": "391244",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mandala ",
   "PINCODE": "391210",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Manglej ",
   "PINCODE": "391210",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Manpur ",
   "PINCODE": "391240",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Menpura ",
   "PINCODE": "391220",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Methi ",
   "PINCODE": "391240",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Miyagam Karjan ",
   "PINCODE": "391240",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Miyagam ",
   "PINCODE": "391240",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Oslam ",
   "PINCODE": "391244",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pingalvada ",
   "PINCODE": "391240",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sadhli ",
   "PINCODE": "391250",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sambhoi ",
   "PINCODE": "391240",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sampa ",
   "PINCODE": "391240",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Samra ",
   "PINCODE": "391244",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Saniad ",
   "PINCODE": "391244",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Simri ",
   "PINCODE": "391244",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Urad ",
   "PINCODE": "391244",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Valan ",
   "PINCODE": "392310",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vemar ",
   "PINCODE": "391240",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vemardi ",
   "PINCODE": "391210",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Virjai ",
   "PINCODE": "391240",
   "TALUKA": "Karjan",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambadungar ",
   "PINCODE": "391175",
   "TALUKA": "KAWANT",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Athadungri ",
   "PINCODE": "391170",
   "TALUKA": "KAWANT",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bedia ",
   "PINCODE": "391165",
   "TALUKA": "KAWANT",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhumaswada ",
   "PINCODE": "391165",
   "TALUKA": "KAWANT",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khatiawant ",
   "PINCODE": "391135",
   "TALUKA": "KAWANT",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Manka ",
   "PINCODE": "391170",
   "TALUKA": "KAWANT",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mankodi ",
   "PINCODE": "391170",
   "TALUKA": "KAWANT",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Motavanta ",
   "PINCODE": "391170",
   "TALUKA": "KAWANT",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mundamore ",
   "PINCODE": "391135",
   "TALUKA": "KAWANT",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navalja ",
   "PINCODE": "391170",
   "TALUKA": "KAWANT",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pipaldi ",
   "PINCODE": "391170",
   "TALUKA": "KAWANT",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Raisingpura ",
   "PINCODE": "391170",
   "TALUKA": "KAWANT",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rangpur (K) ",
   "PINCODE": "391135",
   "TALUKA": "KAWANT",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Saidivasana ",
   "PINCODE": "391170",
   "TALUKA": "KAWANT",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Thadgam ",
   "PINCODE": "391170",
   "TALUKA": "KAWANT",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umathi ",
   "PINCODE": "391170",
   "TALUKA": "KAWANT",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vijli ",
   "PINCODE": "391170",
   "TALUKA": "KAWANT",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Akona ",
   "PINCODE": "391150",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amroli ",
   "PINCODE": "391150",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Baroli ",
   "PINCODE": "391150",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhaka ",
   "PINCODE": "391152",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bharvada ",
   "PINCODE": "391150",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chametha ",
   "PINCODE": "391150",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dani ",
   "PINCODE": "391152",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhamasiya ",
   "PINCODE": "391150",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dugdha ",
   "PINCODE": "391150",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gadhboriad ",
   "PINCODE": "391152",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Goyawant ",
   "PINCODE": "391150",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Haripura ",
   "PINCODE": "391150",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jakshi ",
   "PINCODE": "391150",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jamli ",
   "PINCODE": "391152",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jemalgadh ",
   "PINCODE": "391150",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kaliyapura ",
   "PINCODE": "391150",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khapariya ",
   "PINCODE": "391150",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kharmada ",
   "PINCODE": "391152",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kolamba ",
   "PINCODE": "391152",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kukarda ",
   "PINCODE": "391150",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lavakui ",
   "PINCODE": "391150",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moghela ",
   "PINCODE": "391152",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nalvant ",
   "PINCODE": "391152",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Naswadi ",
   "PINCODE": "391150",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navagam ",
   "PINCODE": "391152",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pala ",
   "PINCODE": "391150",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Palasani ",
   "PINCODE": "391152",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Parvata ",
   "PINCODE": "391150",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pochamba ",
   "PINCODE": "391150",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Raipur ",
   "PINCODE": "391150",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Savli ",
   "PINCODE": "391150",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sengpur ",
   "PINCODE": "391152",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shira ",
   "PINCODE": "391150",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sindhikuva ",
   "PINCODE": "391150",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sodhaliya ",
   "PINCODE": "391152",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tanakhala ",
   "PINCODE": "391151",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vaguma ",
   "PINCODE": "391152",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vankla ",
   "PINCODE": "391152",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Wagach ",
   "PINCODE": "391152",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zer ",
   "PINCODE": "391152",
   "TALUKA": "NASWADI",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Husepura ",
   "PINCODE": "391445",
   "TALUKA": "Padara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Abhol ",
   "PINCODE": "391421",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambada ",
   "PINCODE": "391445",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amla ",
   "PINCODE": "391445",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Anti ",
   "PINCODE": "391445",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhadara ",
   "PINCODE": "391445",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhoj ",
   "PINCODE": "391445",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chansad ",
   "PINCODE": "391440",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chitral ",
   "PINCODE": "391430",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chokari ",
   "PINCODE": "391450",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dabhasa ",
   "PINCODE": "391440",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dabka ",
   "PINCODE": "391440",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Darapura ",
   "PINCODE": "391440",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dudhwada ",
   "PINCODE": "391450",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ekelbara ",
   "PINCODE": "391440",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gametha ",
   "PINCODE": "391430",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gavasad ",
   "PINCODE": "391430",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghayaj ",
   "PINCODE": "391440",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Goriyad ",
   "PINCODE": "391440",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jalalpura ",
   "PINCODE": "391430",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jaspura ",
   "PINCODE": "391440",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kanda ",
   "PINCODE": "391430",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karkhadi ",
   "PINCODE": "391450",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kural ",
   "PINCODE": "391430",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Latipura ",
   "PINCODE": "391440",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Luna ",
   "PINCODE": "391440",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mahmadpura ",
   "PINCODE": "391440",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mahuvad ",
   "PINCODE": "391440",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Majatan ",
   "PINCODE": "391450",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Masar ",
   "PINCODE": "391421",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Masar Road ",
   "PINCODE": "391421",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mobha ",
   "PINCODE": "391430",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mobha Road ",
   "PINCODE": "391430",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mujpur ",
   "PINCODE": "391440",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Muval ",
   "PINCODE": "391430",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Narshihpura ",
   "PINCODE": "391440",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Padra ",
   "PINCODE": "391440",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pindappa ",
   "PINCODE": "391430",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pipli ",
   "PINCODE": "391445",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajupura ",
   "PINCODE": "391445",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ranu ",
   "PINCODE": "391445",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sadra ",
   "PINCODE": "391430",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sampla ",
   "PINCODE": "391421",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sandha ",
   "PINCODE": "391440",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sangma ",
   "PINCODE": "391440",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sanpur ",
   "PINCODE": "391430",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sarasavani ",
   "PINCODE": "391445",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sejakuva ",
   "PINCODE": "391440",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sihora ",
   "PINCODE": "391440",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sokhdaradhu ",
   "PINCODE": "391240",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tajpura ",
   "PINCODE": "391440",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tithor ",
   "PINCODE": "391450",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umaraya ",
   "PINCODE": "391440",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadadla ",
   "PINCODE": "391445",
   "TALUKA": "padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadu ",
   "PINCODE": "391460",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vanchhara ",
   "PINCODE": "391430",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Virpur ",
   "PINCODE": "391445",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vistar ",
   "PINCODE": "391440",
   "TALUKA": "Padra",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Aniyadri ",
   "PINCODE": "391160",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Athavali ",
   "PINCODE": "391140",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bar ",
   "PINCODE": "391160",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Baravad ",
   "PINCODE": "391160",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhanpur ",
   "PINCODE": "391160",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhensavali ",
   "PINCODE": "391160",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhikhapur ",
   "PINCODE": "391160",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhilpur ",
   "PINCODE": "391160",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhindol ",
   "PINCODE": "391135",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bordha ",
   "PINCODE": "391135",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chalamali ",
   "PINCODE": "391140",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chhatrali ",
   "PINCODE": "391135",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chudel ",
   "PINCODE": "391160",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Devalia ",
   "PINCODE": "391160",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dumali ",
   "PINCODE": "391160",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dungarvant ",
   "PINCODE": "391160",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ferkuva ",
   "PINCODE": "391135",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Harakhapur ",
   "PINCODE": "391160",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jabugam ",
   "PINCODE": "391155",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jaloda ",
   "PINCODE": "391160",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jamba ",
   "PINCODE": "391160",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kadachhala ",
   "PINCODE": "391140",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kadvad ",
   "PINCODE": "391160",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kalarani ",
   "PINCODE": "391135",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kalidoli ",
   "PINCODE": "391140",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kanda ",
   "PINCODE": "391160",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karali ",
   "PINCODE": "391135",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kikavada ",
   "PINCODE": "391160",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kohivav ",
   "PINCODE": "391160",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moradungari ",
   "PINCODE": "391140",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moti  Amroli ",
   "PINCODE": "391160",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moti  Beg ",
   "PINCODE": "391160",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moti  Rasli ",
   "PINCODE": "391160",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Motibumadi ",
   "PINCODE": "391155",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Muldhar ",
   "PINCODE": "391155",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Muvada ",
   "PINCODE": "391160",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nana Amadara ",
   "PINCODE": "391135",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Palsanda ",
   "PINCODE": "391160",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pandhara ",
   "PINCODE": "391155",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panej ",
   "PINCODE": "391140",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pani ",
   "PINCODE": "391160",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pavijetpur ",
   "PINCODE": "391160",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajbodeli ",
   "PINCODE": "391140",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ratanpur ",
   "PINCODE": "391160",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Saloj ",
   "PINCODE": "391135",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sankhandra ",
   "PINCODE": "391135",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sargi ",
   "PINCODE": "391140",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Segwa Simli ",
   "PINCODE": "391155",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sejwa ",
   "PINCODE": "391135",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tadkachhla ",
   "PINCODE": "391135",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Uchapan ",
   "PINCODE": "391160",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umarva ",
   "PINCODE": "391160",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Valothi ",
   "PINCODE": "391160",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vanta ",
   "PINCODE": "391135",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasna ",
   "PINCODE": "391140",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Waghva ",
   "PINCODE": "391160",
   "TALUKA": "PAVIJETPUR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Raisingpura ",
   "PINCODE": "391160",
   "TALUKA": "PAVIJETPURA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Akakheda ",
   "PINCODE": "391145",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Alhadpura ",
   "PINCODE": "391135",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambapura ",
   "PINCODE": "391145",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Anandpura ",
   "PINCODE": "391761",
   "TALUKA": "Sankheda",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bahadarpur ",
   "PINCODE": "391125",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bamroli ",
   "PINCODE": "391125",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bangapura ",
   "PINCODE": "391145",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhatpur ",
   "PINCODE": "391130",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bortalav ",
   "PINCODE": "391145",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chhuchhapura ",
   "PINCODE": "391125",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chorngala ",
   "PINCODE": "391130",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Deroli ",
   "PINCODE": "391130",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dormar ",
   "PINCODE": "391125",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Fanta ",
   "PINCODE": "391125",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Garda ",
   "PINCODE": "391145",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghantoli ",
   "PINCODE": "391150",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gola Gamdi ",
   "PINCODE": "391125",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gundicha ",
   "PINCODE": "391145",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Handod ",
   "PINCODE": "391145",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hareshwar ",
   "PINCODE": "391125",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Indral ",
   "PINCODE": "391130",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jojwa  R.S. ",
   "PINCODE": "391125",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kahndia ",
   "PINCODE": "391761",
   "TALUKA": "Sankheda",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kaledia ",
   "PINCODE": "391150",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kanteshwar ",
   "PINCODE": "391125",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kasumbia ",
   "PINCODE": "391761",
   "TALUKA": "Sankheda",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kavitha ",
   "PINCODE": "391125",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khunvad ",
   "PINCODE": "391130",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kosindra ",
   "PINCODE": "391140",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kuvarpura ",
   "PINCODE": "391761",
   "TALUKA": "Sankheda",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lachharas ",
   "PINCODE": "391130",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ladod ",
   "PINCODE": "391135",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lotia ",
   "PINCODE": "391125",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Makni ",
   "PINCODE": "391145",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Malpur ",
   "PINCODE": "391145",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Malu ",
   "PINCODE": "391761",
   "TALUKA": "Sankheda",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Modasar ",
   "PINCODE": "391135",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Morakhala ",
   "PINCODE": "391125",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nandpur ",
   "PINCODE": "391145",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navapura ",
   "PINCODE": "391125",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Picchuwada ",
   "PINCODE": "391145",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pipalsat ",
   "PINCODE": "391145",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rampura ",
   "PINCODE": "391145",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ratanpura ",
   "PINCODE": "391145",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sankheda ",
   "PINCODE": "391145",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sarsinda ",
   "PINCODE": "391130",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sunderpura ",
   "PINCODE": "391145",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tandalja ",
   "PINCODE": "391135",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Targol ",
   "PINCODE": "391125",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Timba ",
   "PINCODE": "391130",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Totarmata ",
   "PINCODE": "391125",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadeli ",
   "PINCODE": "391145",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vaniadri ",
   "PINCODE": "391135",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasan Sevada ",
   "PINCODE": "391145",
   "TALUKA": "SANKHEDA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Wandarda ",
   "PINCODE": "391761",
   "TALUKA": "Sankheda",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Anjesar ",
   "PINCODE": "391775",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bahutha ",
   "PINCODE": "391775",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhadarwa ",
   "PINCODE": "391780",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Champaner Road ",
   "PINCODE": "391510",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chandranagar ",
   "PINCODE": "391520",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chhaliar ",
   "PINCODE": "391530",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dajipura ",
   "PINCODE": "391774",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Desar ",
   "PINCODE": "391774",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhanora ",
   "PINCODE": "391510",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhantej ",
   "PINCODE": "391530",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gangadia ",
   "PINCODE": "391520",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gardhia ",
   "PINCODE": "391520",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghantiyal ",
   "PINCODE": "391510",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gothda ",
   "PINCODE": "391770",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Himmatpura ",
   "PINCODE": "391774",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Indrad ",
   "PINCODE": "391510",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Itwad ",
   "PINCODE": "391774",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jambugoral ",
   "PINCODE": "391774",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Juna Samlaya ",
   "PINCODE": "391520",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kadchhala ",
   "PINCODE": "391774",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kamalpura ",
   "PINCODE": "391520",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karchia ",
   "PINCODE": "391520",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khakharia ",
   "PINCODE": "391510",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lamdapura ",
   "PINCODE": "391775",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lanchanpura ",
   "PINCODE": "391770",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Latwa ",
   "PINCODE": "391530",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Limdi ",
   "PINCODE": "391530",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Manjusar ",
   "PINCODE": "391775",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Merakuva ",
   "PINCODE": "391774",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mevli ",
   "PINCODE": "391770",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mokshi ",
   "PINCODE": "391780",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Motipura ",
   "PINCODE": "391520",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Motivarnoli ",
   "PINCODE": "391774",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mudhela ",
   "PINCODE": "391510",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Muval ",
   "PINCODE": "391770",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nahra ",
   "PINCODE": "391770",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Namisara ",
   "PINCODE": "391775",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nani Bhadol ",
   "PINCODE": "391520",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Narpura ",
   "PINCODE": "391530",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Natwar Nagar ",
   "PINCODE": "391780",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pandu ",
   "PINCODE": "391530",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pasva ",
   "PINCODE": "391520",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pilol ",
   "PINCODE": "391745",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pipalchhat ",
   "PINCODE": "391530",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Poicha ",
   "PINCODE": "391770",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Poicha ",
   "PINCODE": "391780",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pratappura ",
   "PINCODE": "391774",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Prathampura ",
   "PINCODE": "391780",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Prathampura ",
   "PINCODE": "391770",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajupura ",
   "PINCODE": "391530",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rania ",
   "PINCODE": "391780",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Raniapura ",
   "PINCODE": "391520",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ranjit Nagar ",
   "PINCODE": "391780",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rasulpur ",
   "PINCODE": "391770",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sadra ",
   "PINCODE": "391510",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Samlaya R S ",
   "PINCODE": "391520",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sandasal ",
   "PINCODE": "391530",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Savli ",
   "PINCODE": "391770",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sihora ",
   "PINCODE": "391530",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Subhelav ",
   "PINCODE": "391775",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tulsipura ",
   "PINCODE": "391510",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tundav ",
   "PINCODE": "391775",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vachhesar ",
   "PINCODE": "388710",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadia ",
   "PINCODE": "391520",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vakaner ",
   "PINCODE": "391780",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vaktapura ",
   "PINCODE": "391530",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Valavav ",
   "PINCODE": "391774",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vankaneda ",
   "PINCODE": "391774",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Varsada ",
   "PINCODE": "391774",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasanpura ",
   "PINCODE": "391770",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasia ",
   "PINCODE": "391530",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vejpur ",
   "PINCODE": "391535",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vemar ",
   "PINCODE": "391520",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vintoz ",
   "PINCODE": "391770",
   "TALUKA": "Savli",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sevasi ",
   "PINCODE": "391101",
   "TALUKA": "Sevasi",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Achisara ",
   "PINCODE": "391111",
   "TALUKA": "SINOR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Anandi ",
   "PINCODE": "391111",
   "TALUKA": "SINOR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Barkal ",
   "PINCODE": "391105",
   "TALUKA": "SINOR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bithli ",
   "PINCODE": "391105",
   "TALUKA": "SINOR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chhanbhoi ",
   "PINCODE": "391111",
   "TALUKA": "SINOR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mota Karala ",
   "PINCODE": "391105",
   "TALUKA": "SINOR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nana Karala ",
   "PINCODE": "391105",
   "TALUKA": "SINOR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Puniad ",
   "PINCODE": "391111",
   "TALUKA": "SINOR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sagwa ",
   "PINCODE": "391105",
   "TALUKA": "SINOR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sanor ",
   "PINCODE": "391105",
   "TALUKA": "SINOR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sinor ",
   "PINCODE": "391115",
   "TALUKA": "Sinor",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vaniad ",
   "PINCODE": "391105",
   "TALUKA": "SINOR",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zanzad ",
   "PINCODE": "391115",
   "TALUKA": "Sinor",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Agar ",
   "PINCODE": "391150",
   "TALUKA": "TILAKWADA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ajod ",
   "PINCODE": "391740",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ajwa Road ",
   "PINCODE": "390019",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Akota ",
   "PINCODE": "390020",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Alkapuri ",
   "PINCODE": "390007",
   "TALUKA": "vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amaliyara ",
   "PINCODE": "390022",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amodar ",
   "PINCODE": "390019",
   "TALUKA": "vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ampad ",
   "PINCODE": "391101",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Angadh ",
   "PINCODE": "391330",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ankhol ",
   "PINCODE": "390019",
   "TALUKA": "vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ankodia ",
   "PINCODE": "391330",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Asoj ",
   "PINCODE": "391745",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Atladara ",
   "PINCODE": "390012",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bajwa ",
   "PINCODE": "391310",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bakrol ",
   "PINCODE": "390019",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Baranpura ",
   "PINCODE": "390001",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhaily ",
   "PINCODE": "391410",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bill ",
   "PINCODE": "391410",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Brahamanvashi ",
   "PINCODE": "391421",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chapad ",
   "PINCODE": "391410",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chemical Industries ",
   "PINCODE": "390003",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chhani Rd ",
   "PINCODE": "390002",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chhani ",
   "PINCODE": "391740",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chikhodara ",
   "PINCODE": "390009",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Danteshwar ",
   "PINCODE": "390004",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dashrath ",
   "PINCODE": "391740",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhaniavi ",
   "PINCODE": "390014",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dodka ",
   "PINCODE": "391340",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dumad ",
   "PINCODE": "391740",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Eme ",
   "PINCODE": "390008",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Fartilizer Nagar ",
   "PINCODE": "391750",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Fateganj H.O",
   "PINCODE": "390002",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Fatepura ",
   "PINCODE": "390006",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Fazalpur ",
   "PINCODE": "391340",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Geb ",
   "PINCODE": "390007",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gorwa ",
   "PINCODE": "390003",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gosindra ",
   "PINCODE": "391240",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gotri ",
   "PINCODE": "390021",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Harni Colony ",
   "PINCODE": "390022",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Industrial Estate ",
   "PINCODE": "390016",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Itola ",
   "PINCODE": "391240",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Itola R.S. ",
   "PINCODE": "391240",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jambuva ",
   "PINCODE": "390014",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jawahar Nagar ",
   "PINCODE": "391320",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kalali ",
   "PINCODE": "390012",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kapurai ",
   "PINCODE": "390004",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karelibaug ",
   "PINCODE": "390018",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karodia ",
   "PINCODE": "391310",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kelanpur ",
   "PINCODE": "390004",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khanderao Market ",
   "PINCODE": "390001",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kotna ",
   "PINCODE": "391330",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Koyali ",
   "PINCODE": "391330",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kumetha ",
   "PINCODE": "390019",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "M.I. Estate ",
   "PINCODE": "390010",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Madanzampa ",
   "PINCODE": "390001",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Makarpura ",
   "PINCODE": "390014",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mandvi ",
   "PINCODE": "390001",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Maneja ",
   "PINCODE": "390013",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Manjalpur ",
   "PINCODE": "390011",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nandesari ",
   "PINCODE": "391340",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nandesari Ind. Estate ",
   "PINCODE": "391340",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nimetha ",
   "PINCODE": "390019",
   "TALUKA": "vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ongc Col ",
   "PINCODE": "390009",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Padmala ",
   "PINCODE": "391350",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Patarveni ",
   "PINCODE": "391220",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Petrochemical  T Ship ",
   "PINCODE": "391345",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Petrochemical ",
   "PINCODE": "391346",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Por ",
   "PINCODE": "391243",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pratapganj ",
   "PINCODE": "390002",
   "TALUKA": "vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pratapnagar R.S. ",
   "PINCODE": "390004",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pratapnagar ",
   "PINCODE": "390004",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Racecourse ",
   "PINCODE": "390007",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Raika ",
   "PINCODE": "391340",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Raipura ",
   "PINCODE": "391410",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ramnath ",
   "PINCODE": "391220",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ranoli ",
   "PINCODE": "391350",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ruvand ",
   "PINCODE": "391220",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Saiyed Vasna ",
   "PINCODE": "390007",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sama ",
   "PINCODE": "390008",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Samiyala ",
   "PINCODE": "391410",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Samsabad ",
   "PINCODE": "391107",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sankarda ",
   "PINCODE": "391350",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Santkawnar Colony ",
   "PINCODE": "390006",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sarar ",
   "PINCODE": "391240",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sayajiganj ",
   "PINCODE": "390020",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sayajipura ",
   "PINCODE": "390019",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shahpura ",
   "PINCODE": "391220",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sharadnagar ",
   "PINCODE": "390009",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sherkhi ",
   "PINCODE": "391330",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sindhrot ",
   "PINCODE": "391330",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sisva ",
   "PINCODE": "391740",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sokhda ",
   "PINCODE": "391745",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "SRP Group I ",
   "PINCODE": "390001",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Subhanpura ",
   "PINCODE": "390023",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sundarpura ",
   "PINCODE": "391240",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "T B Sanatorium ",
   "PINCODE": "390021",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tandalja ",
   "PINCODE": "390012",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tarsali ",
   "PINCODE": "390009",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tatarpura ",
   "PINCODE": "390004",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Undera ",
   "PINCODE": "391330",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadodara H.O",
   "PINCODE": "390001",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadsala ",
   "PINCODE": "391240",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadsar ",
   "PINCODE": "390010",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Varnama ",
   "PINCODE": "391240",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasna Kotaria ",
   "PINCODE": "391745",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vidhyut Nagar Colony ",
   "PINCODE": "390007",
   "TALUKA": "Vadodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Virod ",
   "PINCODE": "390022",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Wadi S.N. Road ",
   "PINCODE": "390017",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Waghodia Road ",
   "PINCODE": "390019",
   "TALUKA": "VADODARA",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Adiran ",
   "PINCODE": "391510",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ajwa Compound ",
   "PINCODE": "391510",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Alva ",
   "PINCODE": "391760",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambali ",
   "PINCODE": "391760",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Antoli ",
   "PINCODE": "391761",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Asoj ",
   "PINCODE": "391510",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhaniara ",
   "PINCODE": "391510",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chipad ",
   "PINCODE": "391760",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gabhirpura ",
   "PINCODE": "391761",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ganeshpura ",
   "PINCODE": "391510",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ganpatpura ",
   "PINCODE": "391760",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghodadara ",
   "PINCODE": "391760",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Goraj ",
   "PINCODE": "391761",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gutal ",
   "PINCODE": "391760",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jarod ",
   "PINCODE": "391510",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kamrol ",
   "PINCODE": "391510",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karmaliyapura ",
   "PINCODE": "391761",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khanda ",
   "PINCODE": "391760",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kheda Karmasiya ",
   "PINCODE": "391510",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khervadi ",
   "PINCODE": "391761",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kotambi ",
   "PINCODE": "391510",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kuvarvada ",
   "PINCODE": "391760",
   "TALUKA": "vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lilora ",
   "PINCODE": "391510",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Limda ",
   "PINCODE": "391760",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Madheli ",
   "PINCODE": "391760",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Motimanekpur ",
   "PINCODE": "391761",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navagam ",
   "PINCODE": "391510",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panchdevla ",
   "PINCODE": "391510",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pipalia ",
   "PINCODE": "391760",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rahkui ",
   "PINCODE": "391510",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajpura ",
   "PINCODE": "391510",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rasulabad ",
   "PINCODE": "391510",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Raval ",
   "PINCODE": "391760",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Remeshwarpura ",
   "PINCODE": "391761",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rustampura ",
   "PINCODE": "391761",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Saidal ",
   "PINCODE": "391761",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sangadol ",
   "PINCODE": "391760",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sarnej ",
   "PINCODE": "391510",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vaghodia ",
   "PINCODE": "391760",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasvel ",
   "PINCODE": "391760",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vedpur ",
   "PINCODE": "391761",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vejalpura ",
   "PINCODE": "391760",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vesania ",
   "PINCODE": "391760",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vyankatpura ",
   "PINCODE": "391510",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vyara Antoli ",
   "PINCODE": "391760",
   "TALUKA": "Vaghodia",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Valva ",
   "PINCODE": "391761",
   "TALUKA": "Vaghodida",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Falod ",
   "PINCODE": "391760",
   "TALUKA": "Vaghoida",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Junarampura ",
   "PINCODE": "391760",
   "TALUKA": "Vaghoida",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karchiya ",
   "PINCODE": "391310",
   "TALUKA": "Vasdodara",
   "DISTRICT": "VADODARA",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhodipada ",
   "PINCODE": "396130",
   "TALUKA": ".",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Fanaswada ",
   "PINCODE": "396045",
   "TALUKA": ".",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sarai ",
   "PINCODE": "396130",
   "TALUKA": ".",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Saronda ",
   "PINCODE": "396135",
   "TALUKA": ".",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tadgam ",
   "PINCODE": "396135",
   "TALUKA": ".",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Athal ",
   "PINCODE": "396235",
   "TALUKA": "DADRA & NAGAR HAVELI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kachigam ",
   "PINCODE": "396235",
   "TALUKA": "DADRA & NAGAR HAVELI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kharadpada ",
   "PINCODE": "396235",
   "TALUKA": "DADRA & NAGAR HAVELI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lavachha ",
   "PINCODE": "396193",
   "TALUKA": "DADRA & NAGAR HAVELI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moti Tambadi ",
   "PINCODE": "396193",
   "TALUKA": "DADRA & NAGAR HAVELI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nani Tambadi ",
   "PINCODE": "396193",
   "TALUKA": "DADRA & NAGAR HAVELI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amba Talat ",
   "PINCODE": "396051",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Asura ",
   "PINCODE": "396050",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Avdha ",
   "PINCODE": "396050",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bamti ",
   "PINCODE": "396050",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Baroliya ",
   "PINCODE": "396050",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Barsol ",
   "PINCODE": "396050",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Barumal ",
   "PINCODE": "396050",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhambha ",
   "PINCODE": "396050",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhavthan Ambosi ",
   "PINCODE": "396051",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhensdara ",
   "PINCODE": "396050",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bildha ",
   "PINCODE": "396051",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bilpudi ",
   "PINCODE": "396050",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bopi ",
   "PINCODE": "396051",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chichozar ",
   "PINCODE": "396050",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Deli ",
   "PINCODE": "396126",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhamani ",
   "PINCODE": "396050",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dharampur ",
   "PINCODE": "396050",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gadi ",
   "PINCODE": "396051",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gundia ",
   "PINCODE": "396050",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hanumatmal ",
   "PINCODE": "396051",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jamalia ",
   "PINCODE": "396051",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kakadkuva ",
   "PINCODE": "396065",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kangvi ",
   "PINCODE": "396051",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kaprada ",
   "PINCODE": "396065",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karanjveri ",
   "PINCODE": "396051",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khanda ",
   "PINCODE": "396051",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kharvel ",
   "PINCODE": "396050",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khatana ",
   "PINCODE": "396051",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kosamkuwa ",
   "PINCODE": "396050",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kurgam ",
   "PINCODE": "396007",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Manaichondi ",
   "PINCODE": "396051",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Meghval ",
   "PINCODE": "396240",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mohpada ",
   "PINCODE": "396065",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Murdad ",
   "PINCODE": "396051",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nadagdhari ",
   "PINCODE": "396051",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nanapondha ",
   "PINCODE": "396126",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nani Dholdungri ",
   "PINCODE": "396051",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nanivahiyal ",
   "PINCODE": "396065",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pindval ",
   "PINCODE": "396050",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rajpur Talat ",
   "PINCODE": "396051",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sidumber ",
   "PINCODE": "396050",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tiskari ",
   "PINCODE": "396050",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ukta ",
   "PINCODE": "396050",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Veribhavada ",
   "PINCODE": "396050",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Virval ",
   "PINCODE": "396051",
   "TALUKA": "DHARAMPUR",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Makadban ",
   "PINCODE": "396050",
   "TALUKA": "DHARAMPUR'",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dungri ",
   "PINCODE": "396375",
   "TALUKA": "DUNGRI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Hanuman Bhagda ",
   "PINCODE": "396030",
   "TALUKA": "HANUMAN BHAGDA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amba Jungle ",
   "PINCODE": "396065",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amdha ",
   "PINCODE": "396126",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Arnai ",
   "PINCODE": "396065",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Aslona ",
   "PINCODE": "396065",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Astol ",
   "PINCODE": "396065",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Babarkhadak ",
   "PINCODE": "396126",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Balohondi ",
   "PINCODE": "396126",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Barpuda ",
   "PINCODE": "396065",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Burla ",
   "PINCODE": "396065",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chandvegan ",
   "PINCODE": "396065",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chavshala ",
   "PINCODE": "396065",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chepa ",
   "PINCODE": "396065",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dabkhal ",
   "PINCODE": "396065",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhodhadkuva ",
   "PINCODE": "396126",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Divsi ",
   "PINCODE": "396065",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghanveri ",
   "PINCODE": "396065",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ghotan ",
   "PINCODE": "396065",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Girnala ",
   "PINCODE": "396065",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jirval ",
   "PINCODE": "396065",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jogvel ",
   "PINCODE": "396126",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kakadkopar ",
   "PINCODE": "396126",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khadakwal ",
   "PINCODE": "396065",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mandva ",
   "PINCODE": "396065",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Moti Vahiyal ",
   "PINCODE": "396065",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ozarda ",
   "PINCODE": "396065",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Panas ",
   "PINCODE": "396126",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sahuda ",
   "PINCODE": "396065",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shildha ",
   "PINCODE": "396065",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sukhala ",
   "PINCODE": "396126",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vadoli ",
   "PINCODE": "396065",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Varna ",
   "PINCODE": "396126",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Varoli Talat ",
   "PINCODE": "396126",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Varvath ",
   "PINCODE": "396065",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Virakset ",
   "PINCODE": "396065",
   "TALUKA": "KAPRADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dholai Falia ",
   "PINCODE": "396385",
   "TALUKA": "NAVSARI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambach (Paria) ",
   "PINCODE": "396145",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ambheti ",
   "PINCODE": "396191",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Amli ",
   "PINCODE": "396125",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Asma ",
   "PINCODE": "396125",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bagwada ",
   "PINCODE": "396185",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Balda ",
   "PINCODE": "396125",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Balitha ",
   "PINCODE": "396191",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Barai ",
   "PINCODE": "396145",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chala ",
   "PINCODE": "396191",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chandor ",
   "PINCODE": "396191",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chanod Md ",
   "PINCODE": "396195",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chhiri ",
   "PINCODE": "396191",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chival ",
   "PINCODE": "396126",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dumlav ",
   "PINCODE": "396145",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dungri (Udava RS) ",
   "PINCODE": "396185",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Goima ",
   "PINCODE": "396145",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kalsar ",
   "PINCODE": "396185",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karaya ",
   "PINCODE": "396191",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khadki ",
   "PINCODE": "396185",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kherlav ",
   "PINCODE": "396145",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Killa Pardi ",
   "PINCODE": "396125",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kolak ",
   "PINCODE": "396115",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Koparli ",
   "PINCODE": "396191",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kumbharia ",
   "PINCODE": "396125",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Machhiwad ",
   "PINCODE": "396125",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Morai ",
   "PINCODE": "396191",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mota Pondha ",
   "PINCODE": "396191",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Namdha ",
   "PINCODE": "396191",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nevri ",
   "PINCODE": "396126",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ozar ",
   "PINCODE": "396191",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pachlai ",
   "PINCODE": "396125",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Palsana Pardi ",
   "PINCODE": "396185",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pandor ",
   "PINCODE": "396191",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pardi Paria ",
   "PINCODE": "396145",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pardi R.S. ",
   "PINCODE": "396125",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Parwasa ",
   "PINCODE": "396125",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Patel Faliya ",
   "PINCODE": "396145",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rata ",
   "PINCODE": "396191",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rohina ",
   "PINCODE": "396145",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Salvav ",
   "PINCODE": "396191",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Samarpada ",
   "PINCODE": "396126",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sarodhi ",
   "PINCODE": "396185",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sondhal Wada ",
   "PINCODE": "396125",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sonwada ",
   "PINCODE": "396125",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sukesh ",
   "PINCODE": "396125",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sukhlav ",
   "PINCODE": "396125",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tarmalia ",
   "PINCODE": "396145",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tukwada ",
   "PINCODE": "396185",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Udvada R.S. ",
   "PINCODE": "396185",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Udvada ",
   "PINCODE": "396180",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umarsadi ",
   "PINCODE": "396175",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vaghchhipa ",
   "PINCODE": "396125",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vapi I.E. ",
   "PINCODE": "396195",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vapi ",
   "PINCODE": "396191",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vatar ",
   "PINCODE": "396191",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Velparwa ",
   "PINCODE": "396125",
   "TALUKA": "PARDI",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Achhari ",
   "PINCODE": "396105",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Angam ",
   "PINCODE": "396155",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Anklash ",
   "PINCODE": "396235",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhathi Karmbeli ",
   "PINCODE": "396165",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhilad ",
   "PINCODE": "396105",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Borigam ",
   "PINCODE": "396235",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Borlai ",
   "PINCODE": "396105",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dehli ",
   "PINCODE": "396105",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dehri ",
   "PINCODE": "396170",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhanoli ",
   "PINCODE": "396105",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gowada ",
   "PINCODE": "396170",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jamburi ",
   "PINCODE": "396105",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kalai ",
   "PINCODE": "396105",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kalgam ",
   "PINCODE": "396140",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kanadu ",
   "PINCODE": "396105",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karajgam ",
   "PINCODE": "396155",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karambeli ",
   "PINCODE": "396105",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Karambeli R.S. ",
   "PINCODE": "396105",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khatalwada ",
   "PINCODE": "396120",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Malav ",
   "PINCODE": "396105",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Manda ",
   "PINCODE": "396155",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Maroli Sanjan ",
   "PINCODE": "396130",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Mohan ",
   "PINCODE": "396105",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nagvas ",
   "PINCODE": "396235",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nahuli ",
   "PINCODE": "396105",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nandigam ",
   "PINCODE": "396105",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Nargol ",
   "PINCODE": "396135",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Palgam ",
   "PINCODE": "396170",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pali ",
   "PINCODE": "396105",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Punat ",
   "PINCODE": "396155",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sanjan ",
   "PINCODE": "396150",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sarigam ",
   "PINCODE": "396155",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Solsumba ",
   "PINCODE": "396165",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tembhi ",
   "PINCODE": "396150",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tumb ",
   "PINCODE": "396150",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umargam I.E. ",
   "PINCODE": "396171",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Umargam ",
   "PINCODE": "396170",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Valvada ",
   "PINCODE": "396105",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vankas ",
   "PINCODE": "396150",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Zaroli ",
   "PINCODE": "396105",
   "TALUKA": "UMARGAM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Phansa ",
   "PINCODE": "396140",
   "TALUKA": "UMARGARM",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Anjlav ",
   "PINCODE": "396055",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Atak Pardi ",
   "PINCODE": "396007",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Atgam ",
   "PINCODE": "396045",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Atul ",
   "PINCODE": "396020",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhadeli ",
   "PINCODE": "396030",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhadeli Jagalala ",
   "PINCODE": "396030",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhagal ",
   "PINCODE": "396385",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhagod ",
   "PINCODE": "396020",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bhutsar ",
   "PINCODE": "396055",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Binwada ",
   "PINCODE": "396020",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bodlai ",
   "PINCODE": "396055",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chanvai ",
   "PINCODE": "396020",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Chharwada ",
   "PINCODE": "396030",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dhanori ",
   "PINCODE": "396045",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dharasana ",
   "PINCODE": "396375",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dived ",
   "PINCODE": "396020",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Dulsad ",
   "PINCODE": "396007",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Endergota ",
   "PINCODE": "396375",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Faldhara ",
   "PINCODE": "396007",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gadaria ",
   "PINCODE": "396055",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Gorgam ",
   "PINCODE": "396375",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Haria ",
   "PINCODE": "396020",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jesia ",
   "PINCODE": "396375",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jespore ",
   "PINCODE": "396375",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Jujwa ",
   "PINCODE": "396007",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kachigam ",
   "PINCODE": "396007",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kakadmati ",
   "PINCODE": "396007",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kakwadi ",
   "PINCODE": "396385",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kalwada ",
   "PINCODE": "396045",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kamparia ",
   "PINCODE": "396055",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kanjan Hari ",
   "PINCODE": "396055",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kanjan Ranchhod ",
   "PINCODE": "396055",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kosamba (Valsad) ",
   "PINCODE": "396007",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Kundi ",
   "PINCODE": "396375",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lilapore ",
   "PINCODE": "396030",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Magod ",
   "PINCODE": "396020",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Magod Dungri ",
   "PINCODE": "396020",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Malvan ",
   "PINCODE": "396385",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Manekpore ",
   "PINCODE": "396120",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Marla ",
   "PINCODE": "396055",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Meh ",
   "PINCODE": "396020",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Muli ",
   "PINCODE": "396045",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Navera ",
   "PINCODE": "396055",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ozar ",
   "PINCODE": "396055",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Parnera (Urban) ",
   "PINCODE": "396020",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Parnera Pardi ",
   "PINCODE": "396007",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Pitha ",
   "PINCODE": "396045",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rabda ",
   "PINCODE": "396055",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Rola ",
   "PINCODE": "396375",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Ronvel ",
   "PINCODE": "396055",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sanjan Bandar ",
   "PINCODE": "396150",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Segva ",
   "PINCODE": "396045",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Segvi ",
   "PINCODE": "396007",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Shankar Talav ",
   "PINCODE": "396375",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Sonwada ",
   "PINCODE": "396375",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Surwada ",
   "PINCODE": "396007",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Tighasa ",
   "PINCODE": "396375",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Untdi ",
   "PINCODE": "396385",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vaghaldhara ",
   "PINCODE": "396375",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Valsad - Vankal ",
   "PINCODE": "396007",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Valsad Abrama ",
   "PINCODE": "396002",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Valsad Chhipwad ",
   "PINCODE": "396001",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Valsad H.O",
   "PINCODE": "396001",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Valsad I.E. ",
   "PINCODE": "396035",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Valsad Mograwadi ",
   "PINCODE": "396001",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Valsad Mota Bazar ",
   "PINCODE": "396001",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Valsad Sugar Factory ",
   "PINCODE": "396007",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Vasan ",
   "PINCODE": "396375",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Velvach ",
   "PINCODE": "396007",
   "TALUKA": "VALSAD",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Khanpur ",
   "PINCODE": "396051",
   "TALUKA": "VANSADA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Anklash ",
   "PINCODE": "396051",
   "TALUKA": "VANSDA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Bartad ",
   "PINCODE": "396051",
   "TALUKA": "VANSDA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Lakadbari ",
   "PINCODE": "396051",
   "TALUKA": "VANSDA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 },
 {
   "AreaName": "Satimal ",
   "PINCODE": "396051",
   "TALUKA": "VANSDA",
   "DISTRICT": "VALSAD",
   "STATE": "GUJARAT"
 }
];

        });
