function flt_btn() {
  for (var t = window.innerHeight, e = (window.scrollY, document.querySelectorAll(
        ".floating-btn")), n = document.querySelector(".footer").getBoundingClientRect(),
      o = 0; o < e.length; o++) n.top - t <= 0 ? (e[o].style.position = "", e[o]
    .style.bottom = "", e[o].style.transform = "translateY(-150%)") : (e[o].style
    .position = "fixed", e[o].style.bottom = "30", e[o].style.transform = "")
}
window.addEventListener("load", flt_btn), window.addEventListener("scroll",
  flt_btn), window.addEventListener("resize", flt_btn);
