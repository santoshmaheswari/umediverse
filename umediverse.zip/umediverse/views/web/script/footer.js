function flt_btn(t) {
  document.body.scrollHeight == document.body.scrollTop + window.innerHeight ?
    document.querySelector(".footer").style.bottom = "0" : document.querySelector(
      ".footer").style.bottom = "-100px"
}
flt_btn(), document.addEventListener("scroll", flt_btn, !1), window.addEventListener(
  "resize", flt_btn, !1);
