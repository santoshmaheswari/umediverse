function modal(o, e) {
  document.getElementById(o).onclick = function() {
    document.querySelector("." + e).style.display = "block", document.body.style
      .overflow = "hidden"
  }, document.querySelector("#" + o).onclick = function() {
    document.querySelector("." + e).style.display = "block", document.body.style
      .overflow = "hidden"
  }, document.querySelector("." + e + " .close").onclick = function() {
    document.querySelector("." + e).style.display = "none", document.body.style
      .overflow = ""
  }
}
modal("profile_modal_btn", "profile_modal"), modal("prev_modal_btn",
  "prev_modal"), modal("submit_modal_btn", "submit_modal");
