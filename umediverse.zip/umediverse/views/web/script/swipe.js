function swipedetect(t, e) {
  var a, n, i, s, c, l, r, v = t,
    o = 100,
    d = 100,
    h = 300,
    f = e || function(t) {};
  v && (v.addEventListener("touchstart", function(t) {
    var e = t.changedTouches[0];
    a = "none", dist = 0, n = e.pageX, i = e.pageY, r = (new Date).getTime()
  }, !1), v.addEventListener("touchmove", function(t) {}, !1), v.addEventListener(
    "touchend",
    function(t) {
      var e = t.changedTouches[0];
      s = e.pageX - n, c = e.pageY - i, l = (new Date).getTime() - r, h >=
        l && Math.abs(s) >= o && Math.abs(c) <= d && (a = 0 > s ? "left" :
          "right"), f(a)
    }, !1))
}
var el = document.getElementById("touchsurface");
swipedetect(el, function(t) {
  if ("left" == t) {
    for (var e = 0; e < tablinks.length; e++) {
      var a = tablinks[e].className,
        n = a.search("active");
      if (n >= 0)
        if (e >= tablinks.length - 1) var i = 0;
        else var i = e + 1
    }
    tablinks[i] && (tablinks[i].onclick(), tablinks[i].classList.add(
      "active"))
  }
  if ("right" == t) {
    for (var e = 0; e < tablinks.length; e++) {
      var a = tablinks[e].className,
        n = a.search("active");
      if (n >= 0) {
        var i = e - 1;
        if (0 >= e) var i = tablinks.length - 1
      }
    }
    tablinks[i] && (tablinks[i].onclick(), tablinks[i].classList.add(
      "active"))
  }
});
