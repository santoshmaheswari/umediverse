function openCity(e, t) {
  for (i = 0; i < tabcontent.length; i++) tabcontent[i].style.display = "none",
    tabcontent[i].classList.remove("active");
  for (i = 0; i < tablinks.length; i++) tablinks[i].className = tablinks[i].className
    .replace(" active", "");
  document.getElementById(t).style.display = "block", e && (e.currentTarget.className +=
    " active")
}

function mopenCity(e, t) {
  for (j = 0; j < mtabcontent.length; j++) mtabcontent[j].style.display =
    "none", mtabcontent[j].classList.remove("active");
  for (j = 0; j < mtablinks.length; j++) mtablinks[j].className = mtablinks[j].className
    .replace(" active", "");
  document.getElementById(t).style.display = "block", e && (e.currentTarget.className +=
    " active")
}

var i, tabcontent, tablinks;

for (tablinks = document.getElementsByClassName("tablinks"), tabcontent =
  document.getElementsByClassName("tabcontent"), i = 0; i < tabcontent.length; i++) tabcontent[i].style.display = "none";
var active_ele = document.querySelector(".tablinks.active").getAttribute("onclick").replace("openCity(event, '", "").replace("')", "");
document.getElementById(active_ele).classList.add("active"), document.getElementById(active_ele).style.display = "block";


var j, mtabcontent, mtablinks;
for (mtablinks = document.getElementsByClassName("mtablinks"), mtabcontent =
  document.getElementsByClassName("mtabcontent"), j = 0; j < mtabcontent.length; j++) mtabcontent[j].style.display = "none";
var mactive_ele = document.querySelector(".mtablinks.active").getAttribute("onclick").replace("mopenCity(event, '", "").replace("')", "");
document.getElementById(mactive_ele).classList.add("active"), document.getElementById(mactive_ele).style.display = "block";
