function convertHex(e, t) {
  return e = e.replace("#", ""), r = parseInt(e.substring(0, 2), 16), g =
    parseInt(e.substring(2, 4), 16), b = parseInt(e.substring(4, 6), 16),
    result = "rgba(" + r + "," + g + "," + b + "," + t / 100 + ")", result
}

function apply_color(e, t) {
  if (document.querySelector(".theme-header").style.background =
    "linear-gradient(60deg, " + e + ", " + t + ")", input = document.querySelectorAll(
      '.style-4 input[type="text"]'), input)
    for (var l = 0; l < input.length; l++) input[l].addEventListener("focus",
      function(t) {
        t.target.style.borderBottom = "solid 2px " + e
      }), input[l].addEventListener("focusout", function(e) {
      e.target.style.borderBottom = ""
    });
  if (p_cl = document.querySelectorAll(".style-4 p"), p_cl)
    for (var l = 0; l < p_cl.length; l++) p_cl[l].addEventListener("mouseover",
      function(t) {
        t.target.style.borderBottom = "solid 2px " + e
      }), p_cl[l].addEventListener("mouseout", function(e) {
      e.target.style.borderBottom = ""
    });
  if (document.querySelector(".profile_card") && (document.querySelector(
        ".profile_card").style.background = "linear-gradient(60deg, " +
      convertHex(e, "24") + ", " + convertHex(t, "24") + ")"), h3_cl = document
    .querySelectorAll("h3"), h3_cl)
    for (var l = 0; l < h3_cl.length; l++) h3_cl[l].style.color = convertHex(e,
      "90");
  if (h4_cl = document.querySelectorAll("h4"), h4_cl)
    for (var l = 0; l < h4_cl.length; l++) h4_cl[l].style.color = convertHex(e,
      "55");
  if (btn_cl = document.querySelectorAll(".btn.lightblue"), btn_cl)
    for (var l = 0; l < btn_cl.length; l++) btn_cl[l].style.background = "#fff",
      btn_cl[l].style.background = "linear-gradient(60deg, " + e + ", " + t +
      ")";
  if (document.querySelector(".footer span") && (document.querySelector(
      ".footer span").style.color = e), tb_link = document.querySelectorAll(
      ".tablinks"), tb_link)
    for (var l = 0; l < tb_link.length; l++) "tablinks active" == tb_link[l].className ?
      tb_link[l].style.background = "linear-gradient(60deg, " + e + ", " + t +
      ")" : tb_link[l].style.background = "", tb_link[l].addEventListener(
        "click",
        function(l) {
          for (var r = 0; r < tb_link.length; r++) tb_link[r].style.background =
            "";
          (l.target.className = "tablinks active") && (l.target.style.background =
            "linear-gradient(60deg, " + e + ", " + t + ")")
        });
  if (mtb_link = document.querySelectorAll(".mtablinks"), mtb_link)
    for (var l = 0; l < mtb_link.length; l++) "mtablinks active" == mtb_link[l]
      .className ? (mtb_link[l].style.borderColor = e, mtb_link[l].style.color =
        e) : (mtb_link[l].style.borderColor = "", mtb_link[l].style.color = ""),
      mtb_link[l].addEventListener("click", function(t) {
        for (var l = 0; l < mtb_link.length; l++) mtb_link[l].style.borderColor =
          "", mtb_link[l].style.color = "";
        (t.target.className = "mtablinks active") && (console.log(t.target),
          t.target.style.borderColor = e, t.target.style.color = e)
      });
  if (select_cl = document.querySelectorAll("select"), select_cl)
    for (var l = 0; l < select_cl.length; l++) select_cl[l].addEventListener(
      "focus",
      function(t) {
        t.target.style.borderBottom = "solid 2px " + e
      }), select_cl[l].addEventListener("focusout", function(e) {
      e.target.style.borderBottom = ""
    });
  if (label_cl = document.querySelectorAll(".label-count"), label_cl)
    for (var l = 0; l < label_cl.length; l++) label_cl[l].style.background =
      "linear-gradient(60deg, " + e + ", " + t + ")";
  if (document.querySelector(".profile_card span") && (document.querySelector(
      ".profile_card span").style.background = e), modal_h_cl = document.querySelectorAll(
      ".modal-header"), modal_h_cl)
    for (var l = 0; l < modal_h_cl.length; l++) modal_h_cl[l].style.background =
      "linear-gradient(60deg, " + e + ", " + t + ")";
  if (modal_f_cl = document.querySelectorAll(".modal-footer"), modal_f_cl)
    for (var l = 0; l < modal_f_cl.length; l++) modal_f_cl[l].style.background =
      "linear-gradient(60deg, " + e + ", " + t + ")"
}

function readURL() {
  var e = document.getElementById("getval").files[0],
    t = new FileReader;
  t.onloadend = function() {
      document.querySelector(".profile_card") && (document.querySelector(
          ".profile_card").style.background = "rgba(255,255,255, 0.3)"),
        document.querySelector(".theme-header").style.backgroundSize = "cover",
        document.querySelector(".theme-header").style.backgroundPosition =
        "center", document.querySelector(".theme-header").style.backgroundImage =
        "url(" + t.result + ")"
    }, e ? t.readAsDataURL(e) : document.querySelector("section.content").style
    .backgroundColor = "background: rgba(255,255,255, 1)"
}
window.onclick = function(e) {
  e.target == document.querySelector(".menu_toggle a i") || e.target ==
    document.querySelector(".menu_toggle a") ? (document.querySelector(
      ".right-sidebar").style.right = "0px", document.querySelector(
      ".menu_overlay").style.display = "block") : e.target == document.querySelector(
      ".menu_overlay") && (document.querySelector(".right-sidebar").style.right =
      "-300px", document.querySelector(".menu_overlay").style.display =
      "none", document.querySelector("body").style.overflow = "")
}
document.getElementById("getval").addEventListener(
    "change", readURL, !0);
